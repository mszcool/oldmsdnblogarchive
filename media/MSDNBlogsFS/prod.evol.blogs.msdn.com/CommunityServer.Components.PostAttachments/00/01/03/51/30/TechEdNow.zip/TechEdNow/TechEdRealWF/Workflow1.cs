using System;
using System.ComponentModel;
using System.ComponentModel.Design;
using System.Collections;
using System.Drawing;
using System.Workflow.ComponentModel.Compiler;
using System.Workflow.ComponentModel.Serialization;
using System.Workflow.ComponentModel;
using System.Workflow.ComponentModel.Design;
using System.Workflow.Runtime;
using System.Workflow.Activities;
using System.Workflow.Activities.Rules;
using System.Xml.Serialization;
using System.Xml;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WorkflowActions;
using Microsoft.Office.Workflow.Utility;
using Microsoft.SharePoint.Workflow;
using System.IO;

namespace TechEdRealWF
{
	public sealed partial class Workflow1: SequentialWorkflowActivity
	{
		public Workflow1()
		{
			InitializeComponent();
		}

        public Guid workflowId = default(System.Guid);
        public Microsoft.SharePoint.Workflow.SPWorkflowActivationProperties workflowProperties = new Microsoft.SharePoint.Workflow.SPWorkflowActivationProperties();

        //
        // Workflow Config Members
        //
        public string ApprovalUser = string.Empty;
        public string ApprovalComments = string.Empty;
        public string DbConnection = string.Empty;


        //
        // Task specific members
        //
        public Guid taskId = default(System.Guid);
        public SPWorkflowTaskProperties taskProps = new SPWorkflowTaskProperties();
        public SPWorkflowTaskProperties taskBeforeProps = new SPWorkflowTaskProperties();
        public SPWorkflowTaskProperties taskAfterProps = new SPWorkflowTaskProperties();

        public string taskStatus = string.Empty;

        private void onWorkflowActivated1_Invoked(object sender, ExternalDataEventArgs e)
        {
            XmlTextReader xtr;

            // Reading the association data
            xtr = new XmlTextReader(new StringReader(workflowProperties.AssociationData));
            while (xtr.Read())
            {
                if (xtr.LocalName.Equals("Approver") && ApprovalUser.Equals(string.Empty))
                {
                    xtr.Read();
                    ApprovalUser = xtr.Value;
                }

                if (xtr.LocalName.Equals("DbConnection") && DbConnection.Equals(string.Empty))
                {
                    xtr.Read();
                    DbConnection = xtr.Value;
                }
            }
            xtr.Close();
        }

        private void createTask1_MethodInvoking(object sender, EventArgs e)
        {
            taskId = Guid.NewGuid();

            taskProps.AssignedTo = ApprovalUser;
            taskProps.Title = "Please approve new Order";
            taskProps.Description = "Approve order submitted to " + workflowProperties.ItemUrl;
            taskProps.StartDate = DateTime.Now;
            taskProps.DueDate = DateTime.Now.AddDays(5);
            taskProps.TaskType = 0;
            taskProps.ExtendedProperties["Comments"] = ApprovalComments;
        }

        private void onTaskChanged1_Invoked(object sender, ExternalDataEventArgs e)
        {
            taskStatus = taskAfterProps.ExtendedProperties["TaskStatus"].ToString();
        }

        public ProductOrder CurrentOrder = null;

        private void LoadDocumentFromLib_ExecuteCode(object sender, EventArgs e)
        {
            XmlSerializer ser = new XmlSerializer(typeof(ProductOrder));

            SPWeb web = workflowProperties.Site.OpenWeb(workflowProperties.WebId);
            SPFile file = web.GetFile(workflowProperties.ItemUrl);

            using (Stream s = file.OpenBinaryStream())
            {
                CurrentOrder = (ProductOrder)ser.Deserialize(s);
            }
        }
	}

}
