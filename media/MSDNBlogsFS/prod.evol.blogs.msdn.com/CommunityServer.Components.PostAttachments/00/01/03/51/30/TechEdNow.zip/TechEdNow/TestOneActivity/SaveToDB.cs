using System;
using System.ComponentModel;
using System.ComponentModel.Design;
using System.Collections;
using System.Drawing;
using System.Workflow.ComponentModel.Compiler;
using System.Workflow.ComponentModel.Serialization;
using System.Workflow.ComponentModel;
using System.Workflow.ComponentModel.Design;
using System.Workflow.Runtime;
using System.Workflow.Activities;
using System.Workflow.Activities.Rules;

namespace TestOneActivity
{
    public partial class SaveToDB : System.Workflow.ComponentModel.Activity
	{
		public SaveToDB()
		{
			InitializeComponent();
        }

        #region Activity Properties

        public static DependencyProperty CurrentOrderProperty =
            DependencyProperty.Register("CurrentOrder", typeof(ProductOrder), typeof(SaveToDB));

        public ProductOrder CurrentOrder
        {
            get { return GetValue(CurrentOrderProperty) as ProductOrder; }
            set { SetValue(CurrentOrderProperty, value); }
        }

        public static DependencyProperty DBConnectionStringProperty =
            DependencyProperty.Register("DBConnectionString", typeof(string), typeof(SaveToDB));

        public string DBConnectionString
        {
            get { return GetValue(DBConnectionStringProperty) as string; }
            set { SetValue(DBConnectionStringProperty, value); }
        }

        #endregion

        protected override ActivityExecutionStatus Execute(ActivityExecutionContext executionContext)
        {
            try
            {
                // Create the table adapters
                TechEdOrdersDataSetTableAdapters.SupplierOrderTableAdapter OrderAdapter
                    = new TestOneActivity.TechEdOrdersDataSetTableAdapters.SupplierOrderTableAdapter();
                TechEdOrdersDataSetTableAdapters.SupplierOrderItemTableAdapter ItemAdapter
                    = new TestOneActivity.TechEdOrdersDataSetTableAdapters.SupplierOrderItemTableAdapter();

                OrderAdapter.Connection.ConnectionString = this.DBConnectionString;
                ItemAdapter.Connection.ConnectionString = this.DBConnectionString;

                // Now we can start adding the current order of this activity
                OrderAdapter.Insert(CurrentOrder.OrderNumber,
                                    CurrentOrder.OrderDate, CurrentOrder.Employee,
                                    CurrentOrder.Totals);

                foreach (ProductItemType item in CurrentOrder.ProductItems)
                {
                    ItemAdapter.Insert(item.ProductID,
                                       item.ProductName,
                                       item.OrderUnitPrice,
                                       item.Amount,
                                       CurrentOrder.OrderNumber);
                }
            }
            catch 
            {
                return ActivityExecutionStatus.Faulting;
            }

            // Return the base return value
            return base.Execute(executionContext);
        }
    }
}
