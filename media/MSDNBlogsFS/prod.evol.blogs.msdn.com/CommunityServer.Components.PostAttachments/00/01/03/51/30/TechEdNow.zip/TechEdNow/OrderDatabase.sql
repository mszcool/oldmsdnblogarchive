USE master

GO

IF EXISTS(SELECT * FROM sys.databases WHERE name='TechEdOrders')
   DROP DATABASE TechEdOrders

GO

CREATE DATABASE TechEdOrders

GO

USE TechEdOrders

GO

CREATE TABLE SupplierOrder
(
  OrderNumber nvarchar(120) NOT NULL PRIMARY KEY,
  OrderDate datetime NOT NULL,
  EmployeeId int NOT NULL,
  Totals decimal NOT NULL
)

CREATE TABLE SupplierOrderItem
(
  ProductId int NOT NULL,
  ProductName nvarchar(120) NOT NULL,
  OrderUnitPrice decimal NOT NULL,
  Amount decimal NOT NULL,
  OrderNumber nvarchar(120) NOT NULL,

  CONSTRAINT FK_SupplierOrderItem_SupplierOrder FOREIGN KEY(OrderNumber) REFERENCES SupplierOrder(OrderNumber)
)