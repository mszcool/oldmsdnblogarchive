using Microsoft.Practices.CompositeUI.EventBroker;
using MtsPoland.Infrastructure.Interface;
using MtsPoland.Infrastructure.Interface.Constants;
using System.Windows.Forms;
using Microsoft.Practices.CompositeUI.SmartParts;

namespace MtsPoland.Infrastructure.Layout
{
    public class ShellLayoutViewPresenter 
        : Presenter<ShellLayoutView>, IShellExtensionService
    {
        protected override void OnViewSet()
        {
            WorkItem.UIExtensionSites.RegisterSite(UIExtensionSiteNames.MainMenu, View.MainMenuStrip);
            WorkItem.UIExtensionSites.RegisterSite(UIExtensionSiteNames.MainStatus, View.MainStatusStrip);
            WorkItem.UIExtensionSites.RegisterSite(UIExtensionSiteNames.MainToolbar, View.MainToolbarStrip);

            // Add the presenter as shell extension service
            WorkItem.Services.Add<IShellExtensionService>(this);
        }

        /// <summary>
        /// Status update handler. Updates the status strip on the main form.
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="e">The e.</param>
        [EventSubscription(EventTopicNames.StatusUpdate, ThreadOption.UserInterface)]
        public void StatusUpdateHandler(object sender, EventArgs<string> e)
        {
            View.SetStatusLabel(e.Data);
        }

        /// <summary>
        /// Called when the user asks to exit the application.
        /// </summary>
        public void OnFileExit()
        {
            View.ParentForm.Close();
        }

        #region IShellExtensionService Members

        public void AddNavigationEntry(string caption, Microsoft.Practices.CompositeUI.Commands.Command cmd)
        {
            ToolStripButton button = new ToolStripButton();
            button.Text = caption;
            button.DisplayStyle = ToolStripItemDisplayStyle.Text;

            View.MainToolbarStrip.Items.Add(button);

            cmd.AddInvoker(button, "Click");
        }

        public void ShowHelp(System.Uri helpUrl)
        {
            MessageBox.Show(helpUrl.ToString());
        }

        public void ShowInWorkspace(object smartPart, ShellWorkspaces workspace)
        {
            // Part I: Determine the workspace
            string workspaceName = WorkspaceNames.ModalWindows;

            switch (workspace)
            {
                case ShellWorkspaces.Navigation:
                    workspaceName = WorkspaceNames.LeftWorkspace;
                    break;
                case ShellWorkspaces.Details:
                    workspaceName = WorkspaceNames.RightWorkspace;
                    break;
            }

            // Part II: Add the smart part
            if (smartPart is ISmartPartInfo)
            {
                WorkItem.Workspaces[workspaceName].Show(
                        smartPart, (ISmartPartInfo)smartPart);
            }
            else
            {
                WorkItem.Workspaces[workspaceName].Show(smartPart);
            }
        }

        #endregion

        [EventSubscription(EventTopicNames.CustomerSelected, ThreadOption.UserInterface)]
        public void OnCustomerSelected(object sender, StatusEventArgs eventArgs)
        {//TODO: Add your code here
            View.SetStatusLabel(
                string.Format("Customer selected: {0}",
                    eventArgs.Data)
            );
        }
    }
}
