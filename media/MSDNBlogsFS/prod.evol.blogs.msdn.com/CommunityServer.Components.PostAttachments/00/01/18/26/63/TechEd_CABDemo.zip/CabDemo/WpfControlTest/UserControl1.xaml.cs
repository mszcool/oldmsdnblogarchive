using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Reflection;

namespace WpfControlTest
{
    /// <summary>
    /// Interaction logic for UserControl1.xaml
    /// </summary>

    public partial class UserControl1 : System.Windows.Controls.UserControl
    {

        public UserControl1()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Just for making the demo easier
        /// here we use reflection to display the properties
        /// </summary>
        /// <param name="o"></param>
        public void InitializeBusinessObject(object o)
        {
            Type t = o.GetType();

            PropertyList.Items.Clear();
            foreach (PropertyInfo pi in t.GetProperties())
            {
                PropertyBusinessObject pbo = new PropertyBusinessObject();
                pbo.PropertyName = pi.Name;
                pbo.PropertyValue = pi.GetValue(o, null).ToString();

                PropertyList.Items.Add(pbo);
            }
        }
    }

    public class PropertyBusinessObject
    {
        private string _PropName;

        public string PropertyName
        {
            get { return _PropName; }
            set { _PropName = value; }
        }

        private string _PropValue;

        public string PropertyValue
        {
            get { return _PropValue; }
            set { _PropValue = value; }
        }
    }
}