using System;
using System.Windows.Forms;
using MtsPoland.Infrastructure.Interface;
using Microsoft.Practices.CompositeUI;
using Microsoft.Practices.CompositeUI.Commands;
using Microsoft.Practices.CompositeUI.SmartParts;

namespace MtsPoland.CrmModule
{
    public class CustomerDetailsWorkItem : WorkItemController
    {
        private IShellExtensionService ShellService;
        private CustomerDetailsView _CustomerDetailsView;

        public void Initialize(CrmProxy.Customer customer)
        {
            ShellService = WorkItem.Services.Get<IShellExtensionService>();

            WorkItem.State["CurrentCustomer"] = customer;
            _CustomerDetailsView = WorkItem.Items.AddNew<CustomerDetailsView>();
            Show();
        }

        public void Show()
        {
            ShellService.ShowInWorkspace
            (
                _CustomerDetailsView,
                ShellWorkspaces.Details
            );
        }
    }
}
