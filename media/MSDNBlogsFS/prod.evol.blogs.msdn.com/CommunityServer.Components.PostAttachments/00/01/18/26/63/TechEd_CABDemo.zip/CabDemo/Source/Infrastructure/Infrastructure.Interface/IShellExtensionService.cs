using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Practices.CompositeUI.Commands;

namespace MtsPoland.Infrastructure.Interface
{
    public enum ShellWorkspaces 
    {
        Navigation,
        Details,
        Context
    }

    public interface IShellExtensionService
    {
        void AddNavigationEntry(
                    string caption, 
                    Command cmd);

        void ShowInWorkspace(
                    object smartPart, 
                    ShellWorkspaces workspace);

        void ShowHelp(Uri helpUrl);
    }
}
