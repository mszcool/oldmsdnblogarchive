using System;
using System.Windows.Forms;
using MtsPoland.Infrastructure.Interface;
using Microsoft.Practices.CompositeUI;
using Microsoft.Practices.CompositeUI.Commands;

namespace MtsPoland.ProductModule
{
    public class ProductsWorkItem : WorkItemController
    {
        private ProductsView _ProductsView = null;

        public void Initialize(int categoryId)
        {
            // Save the current category-id as state
            WorkItem.State["CurrentCategoryId"] = categoryId;

            // Next create the view for this workitem
            _ProductsView = WorkItem.Items.AddNew<ProductsView>();

            // Show the WorkItem
            Show();
        }

        public void Show()
        {
            WorkItem.Workspaces[
                Constants.WorkspaceNames.RightWorkspace
            ].Show(_ProductsView);
        }
    }
}
