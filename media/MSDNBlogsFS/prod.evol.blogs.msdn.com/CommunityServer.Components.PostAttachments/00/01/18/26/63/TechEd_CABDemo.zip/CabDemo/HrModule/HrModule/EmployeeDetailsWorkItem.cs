using System;
using System.Collections.Generic;
using Microsoft.Practices.CompositeUI;
using MtsPoland.Infrastructure.Interface;
using MtsPoland.HrModule.HrProxy;
using MtsPoland.HrModule.Constants;
using Microsoft.Practices.CompositeUI.SmartParts;

namespace MtsPoland.HrModule
{
    public class EmployeeDetailsWorkItem : WorkItemController
    {
        private IShellExtensionService ShellService;
        private EmployeeDetailsView _DetailsView = null;

        public void InitWithDetailsEmployee(Employee employee)
        {
            ShellService = WorkItem.Services.Get<IShellExtensionService>();

            WorkItem.State["CurrentEmployee"] = employee;
            _DetailsView = WorkItem.Items.AddNew<EmployeeDetailsView>();
        }

        public void ShowDetails()
        {
            ShellService.ShowInWorkspace
            (
                _DetailsView,
                ShellWorkspaces.Details
            );
        }
    }
}
