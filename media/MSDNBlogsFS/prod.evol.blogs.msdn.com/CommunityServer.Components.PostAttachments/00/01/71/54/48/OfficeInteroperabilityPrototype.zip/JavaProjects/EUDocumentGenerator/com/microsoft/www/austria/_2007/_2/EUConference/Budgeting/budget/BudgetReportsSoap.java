/**
 * BudgetReportsSoap.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.3 Oct 05, 2005 (05:23:37 EDT) WSDL2Java emitter.
 */

package com.microsoft.www.austria._2007._2.EUConference.Budgeting.budget;

public interface BudgetReportsSoap extends java.rmi.Remote {
    public com.microsoft.www.austria._2007._2.EUConference.Budgeting.budget.BudgetReportResponseMessage getReports(com.microsoft.www.austria._2007._2.EUConference.Budgeting.budget.BudgetReportRequestMessage request) throws java.rmi.RemoteException;
}
