package org.openxmldeveloper.samples.demo;

import java.io.File;
import java.io.IOException;
import java.util.zip.ZipFile;

import org.openxmldeveloper.samples.document.word.Paragraph;
import org.openxmldeveloper.samples.document.word.ParagraphAlignment;
import org.openxmldeveloper.samples.document.word.ParagraphBuilder;
import org.openxmldeveloper.samples.document.word.Run;
import org.openxmldeveloper.samples.document.word.UnderlineStyle;
import org.openxmldeveloper.samples.document.word.VerticalAlignment;
import org.openxmldeveloper.samples.document.word.WordDocument;
import org.openxmldeveloper.samples.opc.Package;
import org.openxmldeveloper.samples.opc.PackageAccess;

/**
 * Add content to a Word document.
 * 
 * @author Julien Chable
 */
public class DemoListing8 {

	public static void main(String[] args) {
		final String APP_ROOT = System.getProperty("user.dir") + File.separator;
		ZipFile zipFile = null; // Le fichier source
		try {
			zipFile = new ZipFile(APP_ROOT + "Blank.docx");
		} catch (IOException e) {
			e.printStackTrace();
		}

		File destFile = new File(APP_ROOT + "sample_out.docx");

		Package pack = Package.open(zipFile, PackageAccess.ReadWrite);
		WordDocument docx = new WordDocument(pack);

		// Creation of a paragraph builder
		ParagraphBuilder paraBuilder = new ParagraphBuilder();
		paraBuilder.setAlignment(ParagraphAlignment.CENTER);

		// We create the first paragraph
		Paragraph par1 = paraBuilder.newParagraph();

		// Add runs to modify the style
		Run r1 = new Run("Hello");
		r1.setBold(true);
		Run r2 = new Run(" Office");
		r2.setItalic(true);
		Run r3 = new Run(" Open");
		r3.setUnderline(UnderlineStyle.SINGLE);
		Run r4 = new Run(" XML");
		r4.setVerticalAlignement(VerticalAlignment.SUPERSCRIPT);

		// Add previous runs to the first paragraph
		par1.addRun(r1);
		par1.addRun(r2);
		par1.addRun(r3);
		par1.addRun(r4);

		// Add the first paragraph in the document�s content
		docx.appendParagraph(par1);

		// Creation of a second paragraph
		paraBuilder.setBold(true);
		Paragraph par2 = paraBuilder.newParagraph();

		Run r21 = new Run("www.openxmldeveloper.org");
		r21.setFontSize(55);
		par2.addRun(r21);

		// Append the second paragraph to content
		docx.appendParagraph(par2);

		// Save the document
		docx.save(destFile);
	}
}