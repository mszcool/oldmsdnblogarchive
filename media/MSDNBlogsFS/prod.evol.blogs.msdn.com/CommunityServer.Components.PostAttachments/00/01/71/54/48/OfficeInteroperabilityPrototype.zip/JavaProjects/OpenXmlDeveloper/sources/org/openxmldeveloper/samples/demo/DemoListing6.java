package org.openxmldeveloper.samples.demo;

import java.io.File;
import java.io.IOException;
import java.util.zip.ZipFile;

import org.openxmldeveloper.samples.document.OpenXMLDocument;
import org.openxmldeveloper.samples.opc.PackageAccess;


/**
 * Extract thumbnails.
 * 
 * @author Julien Chable
 */
public class DemoListing6 {

	public static void main(String[] args) {
		final String APP_ROOT = System.getProperty("user.dir") + File.separator;
		ZipFile zipFile = null;
		try {
			zipFile = new ZipFile(APP_ROOT + "sample.pptx");
		} catch (IOException e) {
			e.printStackTrace();
		}

		// Destination folder
		File destFile = new File(APP_ROOT + "export");

		// Open the package
		OpenXMLDocument docx = OpenXMLDocument.open(zipFile, PackageAccess.Read);
		
		// Extract thumbnails
		docx.extractParts(docx.getThumbnails(), destFile);
	}
}
