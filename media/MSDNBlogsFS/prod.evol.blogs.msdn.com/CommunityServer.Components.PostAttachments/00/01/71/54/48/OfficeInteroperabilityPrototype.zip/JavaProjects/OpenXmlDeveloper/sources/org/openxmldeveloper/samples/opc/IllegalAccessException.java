package org.openxmldeveloper.samples.opc;

@SuppressWarnings("serial")
public class IllegalAccessException extends RuntimeException{

	public IllegalAccessException(String message){
		super(message);
	}
}