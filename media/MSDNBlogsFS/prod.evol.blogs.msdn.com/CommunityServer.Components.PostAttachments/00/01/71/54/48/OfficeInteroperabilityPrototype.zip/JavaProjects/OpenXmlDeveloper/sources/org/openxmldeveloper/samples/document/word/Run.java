package org.openxmldeveloper.samples.document.word;

/**
 * Repr�sente un Run d'un paragraphe, c'est � dire un ensemble de caract�res
 * poss�dant les m�mes propri�t�s.
 * 
 * @author Julien Chable
 */
public class Run {
	protected boolean bold;

	protected boolean italic;

	protected UnderlineStyle underline = UnderlineStyle.NONE;

	protected StringBuffer text = new StringBuffer();

	protected int fontSize = 22;

	protected VerticalAlignment verticalAlignement = VerticalAlignment.NONE;

	/**
	 * Constructeur.
	 * 
	 * @param text
	 *            Le texte initial.
	 */
	public Run(String text) {
		this.text.append(text);
	}

	/**
	 * Ajouter le texte sp�cifi�.
	 * 
	 * @param text
	 *            Le texte � ajouter.
	 */
	public void appendText(String text) {
		this.text.append(text);
	}

	/**
	 * Supprimer l'int�gralit� du texte.
	 */
	public void clearText() {
		this.text.delete(0, this.text.length());
	}

	/* Accesseurs */

	public boolean isBold() {
		return bold;
	}

	public void setBold(boolean bold) {
		this.bold = bold;
	}

	public boolean isItalic() {
		return italic;
	}

	public void setItalic(boolean italic) {
		this.italic = italic;
	}

	public UnderlineStyle getUnderline() {
		return underline;
	}

	public void setUnderline(UnderlineStyle underline) {
		this.underline = underline;
	}

	public int getFontSize() {
		return fontSize;
	}

	public void setFontSize(int fontSize) {
		this.fontSize = fontSize;
	}

	public String getText() {
		return text.toString();
	}

	public VerticalAlignment getVerticalAlignement() {
		return verticalAlignement;
	}

	public void setVerticalAlignement(VerticalAlignment verticalAlignement) {
		this.verticalAlignement = verticalAlignement;
	}
}