using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Xml.Serialization;

using EUServices.NamespaceNames;

/// <summary>
/// Summary description for GeneralEntities
/// </summary>
namespace GeneralEntities
{
    [XmlType(Namespace=Constants.EntitiesNamespace)]
    public class Employee
    {
        public Employee() { }
        
        public Employee(int id, string firstname, string lastname)
        {
            EmployeeID = id;
            Firstname = firstname;
            Lastname = lastname;
        }

        private int _EmployeeID;
        public int EmployeeID
        {
            get { return _EmployeeID; }
            set { _EmployeeID = value; }
        }

        private string _Firstname;
        public string Firstname
        {
            get { return _Firstname; }
            set { _Firstname = value; }
        }

        private string _Lastname;
        public string Lastname
        {
            get { return _Lastname; }
            set { _Lastname = value; }
        }
    }
}
