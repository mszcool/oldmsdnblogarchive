package com.microsoft.www.austria._2007._2.EUConference.Budgeting.budget;

public class BudgetReportsSoapProxy implements com.microsoft.www.austria._2007._2.EUConference.Budgeting.budget.BudgetReportsSoap {
  private String _endpoint = null;
  private com.microsoft.www.austria._2007._2.EUConference.Budgeting.budget.BudgetReportsSoap budgetReportsSoap = null;
  
  public BudgetReportsSoapProxy() {
    _initBudgetReportsSoapProxy();
  }
  
  private void _initBudgetReportsSoapProxy() {
    try {
      budgetReportsSoap = (new com.microsoft.www.austria._2007._2.EUConference.Budgeting.budget.BudgetReportsLocator()).getBudgetReportsSoap();
      if (budgetReportsSoap != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)budgetReportsSoap)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)budgetReportsSoap)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (budgetReportsSoap != null)
      ((javax.xml.rpc.Stub)budgetReportsSoap)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public com.microsoft.www.austria._2007._2.EUConference.Budgeting.budget.BudgetReportsSoap getBudgetReportsSoap() {
    if (budgetReportsSoap == null)
      _initBudgetReportsSoapProxy();
    return budgetReportsSoap;
  }
  
  public com.microsoft.www.austria._2007._2.EUConference.Budgeting.budget.BudgetReportResponseMessage getReports(com.microsoft.www.austria._2007._2.EUConference.Budgeting.budget.BudgetReportRequestMessage request) throws java.rmi.RemoteException{
    if (budgetReportsSoap == null)
      _initBudgetReportsSoapProxy();
    return budgetReportsSoap.getReports(request);
  }
  
  
}