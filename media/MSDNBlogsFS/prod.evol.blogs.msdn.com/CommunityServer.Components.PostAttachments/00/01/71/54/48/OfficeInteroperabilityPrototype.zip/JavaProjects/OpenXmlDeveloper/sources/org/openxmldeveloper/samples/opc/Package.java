package org.openxmldeveloper.samples.opc;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.TreeMap;
import java.util.Map.Entry;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.util.zip.ZipOutputStream;

import javax.xml.XMLConstants;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;

import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

/**
 * Repr�sente un paquet suivant les sp�cifications de l'Open packaging
 * Convention.
 * 
 * @author Julien Chable
 * @version 0.1
 */
public class Package implements PartMarshaller {

	/**
	 * Mode d'acc�s au package.
	 */
	private PackageAccess packageAccess;

	/**
	 * Partie contenant les types de contenu de ce package.
	 */
	private final ContentTypeHelper contentTypeHelper;

	/**
	 * La liste des parties de ce package.
	 */
	private TreeMap<URI, PackagePart> partList;

	/**
	 * Partie contenant les relations de ce package.
	 */
	private PackageRelationshipCollection relationships;

	/**
	 * R�f�rence vers l'archive ZIP du document.
	 */
	private ZipFile archive;

	/**
	 * Les PartMarshaller en fonction du type de contenu.
	 */
	protected Hashtable<String, PartMarshaller> partMarshallers;

	/**
	 * Le PartMarshaller par d�faut.
	 */
	protected PartMarshaller defaultPartMarshaller;

	/**
	 * Constructeur appel� par la m�thode <i>open</i>. Initialise le
	 * ContentTypeHelper.
	 * 
	 * @param archive
	 *            L'archive ZIP du document.
	 * @param access
	 *            Mode d'acc�s au document (lecture seule, �criture seule,
	 *            lecture/�criture)
	 */
	private Package(ZipFile archive, PackageAccess access) {
		init();
		this.archive = archive;
		this.contentTypeHelper = new ContentTypeHelper(archive);
		this.packageAccess = access;
	}

	/**
	 * Initialisation des variables de classe.
	 */
	private void init() {
		defaultPartMarshaller = this;
		partMarshallers = new Hashtable<String, PartMarshaller>(5);
	}

	/**
	 * Ouvre ou cr�e une archive OPC
	 * 
	 * @param archive
	 *            L'archive ZIP du document.
	 * @param access
	 *            Mode d'acc�s au document (lecture seule, �criture seule,
	 *            lecture/�criture)
	 * @return Le document r�sultant de l'ouverture ou de la cr�ation.
	 */
	public static Package open(ZipFile archive, PackageAccess access) {
		Package pack = new Package(archive, access);
		if (pack.partList == null && access != PackageAccess.Write)
			pack.getParts();
		return pack;
	}

	/**
	 * Liste l'ensemble des parties contenues dans un package. Le fichier de
	 * type de contenu [Content_Types].xml n'est pas list�.
	 * 
	 * @param zipfile
	 *            Le fichier de paquet compress� � l'aide de l'algorithme ZIP.
	 * @return La liste des URIs de l'ensemble des parties du paquet.
	 */
	public static ArrayList<URI> listPackageParts(ZipFile zipfile) {
		ArrayList<URI> retArr = new ArrayList<URI>();
		Enumeration entries = zipfile.entries();

		// On parcourt toutes les entr�es du fichier ZIP
		while (entries.hasMoreElements()) {
			ZipEntry entry = (ZipEntry) entries.nextElement();
			// On transforme le nom de l'entr�e en URI
			URI entryURI = null;
			try {
				entryURI = new URI(entry.getName());
			} catch (URISyntaxException e) {
				continue;
			}
			// On ajoute l'URI de l'entr�e � la liste des noms des parties
			retArr.add(entryURI);
		}
		return retArr;
	}

	/**
	 * Lance une exception si le mode d'acc�s est ouvert/cr�� en lecture
	 * seulement (PackageAccess.Read).
	 */
	public void throwExceptionIfReadOnly() {
		if (packageAccess == PackageAccess.Read)
			throw new InvalidOperationException(
					"L'op�ration n'est pas permise, le document est ouvert en lecture seulement !");
	}

	/**
	 * Lance une exception si le mode d'acc�s est en �criture seule
	 * (PackageAccess.Write). Cette m�thode est appell�e par les m�thodes
	 * n�cessitant un droit d'�criture sur le document.
	 */
	public void throwExceptionIfWriteOnly() {
		if (packageAccess == PackageAccess.Write)
			throw new InvalidOperationException(
					"L'op�ration n'est pas permise, le document est ouvert en �criture seulement !");
	}

	/**
	 * R�cup�rer une partie sp�cifique de ce package.
	 * 
	 * @param parturi
	 *            L'URI de la partie
	 * @return La partie correspondant � l'URI sp�cifi�
	 */
	public PackagePart getPart(URI partUri) {
		if (partUri == null)
			throw new IllegalArgumentException("partUri ne doit pas �tre nul !");

		if (partList == null)
			getParts();
		return partList.get(partUri);
	}

	/**
	 * R�cup�rer les parties dont le type de contenu est celui sp�cifi� en
	 * argument.
	 * 
	 * @param contentType
	 *            Le type de contenu � chercher.
	 * @return Toutes le sparties dont le type de contenu est celui sp�cifi�.
	 */
	public ArrayList<PackagePart> getPartByContentType(String contentType) {
		ArrayList<PackagePart> retArr = new ArrayList<PackagePart>();
		for (PackagePart part : partList.values())
			if (part.getContentType().equals(contentType))
				retArr.add(part);
		return retArr;
	}

	/**
	 * R�cup�rer les parties en fontion du type de relation.
	 * 
	 * @param relationshipType
	 *            Le type de relation.
	 * @return Toutes les parties ayant le type de relation sp�cifi�.
	 */
	public ArrayList<PackagePart> getPartByRelationshipType(
			String relationshipType) {
		if (relationshipType == null)
			throw new IllegalArgumentException(
					"Le type de la relation ne peut �tre null.");

		ArrayList<PackagePart> retArr = new ArrayList<PackagePart>();
		for (PackageRelationship rel : getRelationshipsByType(relationshipType))
			retArr.add(getPart(rel));

		return retArr;
	}

	/**
	 * Obtenir la partie r�f�renc�e par la relation sp�cifi�e.
	 * 
	 * @param partRel
	 *            La relation de partie
	 */
	public PackagePart getPart(PackageRelationship partRel) {
		PackagePart retPart = null;
		for (PackageRelationship rel : relationships)
			if (rel.getRelationshipType().equals(partRel.getRelationshipType())) {
				retPart = getPart(rel.getTargetUri());
				break;
			}
		return retPart;
	}

	/**
	 * Obtenir les parties de l'archive. Si celles-ci n'ont pas encore �t�
	 * charg� depuis le document, alors cela est r�alis� par cette m�thode.
	 * 
	 * @return Les parties de ce package.
	 */
	public ArrayList<PackagePart> getParts() {
		throwExceptionIfWriteOnly();
		if (partList != null)
			return new ArrayList<PackagePart>(partList.values());
		else {
			partList = new TreeMap<URI, PackagePart>();
			Enumeration entries = archive.entries();
			while (entries.hasMoreElements()) {
				ZipEntry entry = (ZipEntry) entries.nextElement();
				URI entryUri = null;
				try {
					entryUri = new URI(entry.getName()).normalize();
				} catch (URISyntaxException e) {
					continue;
				}
				String contentType = contentTypeHelper.getContentType(entryUri);
				if (contentType != null)
					partList.put(entryUri, new ZipPackagePart(this, entry,
							entryUri, contentType));
			}
			return new ArrayList<PackagePart>(partList.values());
		}
	}

	/**
	 * Ajouter une partie � ce package.
	 * 
	 * @param partUri
	 *            L'URI de la partie
	 * @param contentType
	 *            Le type de contenu de la partie.
	 * @return L'objet PackagePart repr�sentant la partie nouvellement ajout�e.
	 */
	public PackagePart addPart(URI partUri, String contentType) {
		throwExceptionIfReadOnly();
		if (partUri == null)
			throw new IllegalArgumentException("partUri est null");

		if (contentType == null)
			throw new IllegalArgumentException("contentType est null");

		URI normUri = partUri.normalize();
		if (partList.containsKey(normUri) && !partList.get(normUri).isDeleted())
			throw new InvalidOperationException("La parties existe d�j�");

		// On ajoute le type de contenu (si n�cessaire)
		contentTypeHelper.addContentType(partUri, contentType);
		MemoryPackagePart retPart = new MemoryPackagePart(this, partUri,
				contentType);
		this.partList.put(normUri, retPart);
		return retPart;
	}

	/**
	 * Ajouter une partie � ce package � partir du contenu d'un fichier.
	 * 
	 * @param partUri
	 *            L'URI de destination de la partie dans le paquet
	 * @param contentType
	 *            Le type de contenu du paquet
	 * @param content
	 *            Le fichier d'origine dont le contenu sera lu et ajout� dans la
	 *            partie ajout�e
	 * @return La partie nouvellement ajout�e.
	 */
	public PackagePart addPart(URI partUri, String contentType, File content)
			throws IOException {
		PackagePart addedPart = addPart(partUri, contentType);

		// On extrait le contenu du fichier et l'injecte dans la partie
		if (content != null) {
			try {
				OutputStream partOutput = addedPart.getOutputStream();
				FileInputStream fis = new FileInputStream(content);
				byte[] buff = new byte[512];
				int c = 0;
				while (fis.available() > 0) {
					c = fis.read(buff);
					partOutput.write(buff, 0, c);
				}
				partOutput.close();
				fis.close();
			} catch (IOException ioe) {
				System.err
						.println("Le contenu de la partie ajout�e peut �tre alt�r� ... :(");
			}
		}
		return addedPart;
	}

	public void removePart(URI partUri) {
		throwExceptionIfReadOnly();
		if (partUri == null)
			throw new IllegalArgumentException("partUri ne doit pas �tre nul");

		// Suppression de la partie dans le paquet
		if (partList.containsKey(partUri)) {
			partList.get(partUri).setDeleted(true);
			partList.remove(partUri);
		}

		// Suppression du type de contenu si n�cessaire
		contentTypeHelper.deleteContentType(partUri);

		if (PackageURIHelper.isRelationshipPartURI(partUri)) {
			// Suppression des relations d�pendants de la partie source
			URI sourceUri = PackageURIHelper
					.getSourcePartUriFromRelationshipPartUri(partUri);
			if (sourceUri.equals(PackageURIHelper.PACKAGE_ROOT_URI))
				clearRelationships();
			else if (partExists(sourceUri))
				getPart(sourceUri).clearRelationships();
		} else {
			removePart(PackageURIHelper.getRelationshipPartUri(partUri));
		}
	}

	/**
	 * Savoir si une partie est bien pr�sente dans le paquet.
	 * 
	 * @param partUri
	 *            L'URI de la partie � v�rifier.
	 * @return <i>true</i> si la partie existe logiquement dans le paquet sinon
	 *         <i>false</i>.
	 */
	public boolean partExists(URI partUri) {
		return (this.getPart(partUri) != null);
	}

	/**
	 * Ajouter une relation au niveau du package.
	 * 
	 * @param targetUri
	 *            L'URI de la partie cible.
	 * @param targetMode
	 *            La m�thode de ciblage (Internal|External).
	 * @param relationshipType
	 *            Le type de la relation.
	 */
	public void addRelationship(URI targetUri, TargetMode targetMode,
			String relationshipType) {
		relationships.addRelationship(targetUri, targetMode, relationshipType,
				null);
	}

	/**
	 * Supprimer une relation du package.
	 * 
	 * @param id
	 *            L'identifiant de la relation � supprimer.
	 */
	public void removeRelationship(String id) {
		if (relationships != null)
			relationships.removeRelationship(id);
	}

	/**
	 * R�cup�rer toutes les relations de ce package.
	 * 
	 * @return Les relations de niveau paquet de ce package.
	 */
	public PackageRelationshipCollection getRelationships() {
		return getRelationshipsHelper(null);
	}

	/**
	 * R�cup�rer les relations poss�dant le type sp�cifi�
	 * 
	 * @param relationshipType
	 *            Le filtre sp�cifiant le type de relation des relations �
	 *            retourner.
	 * @return Les relations dont le type correspond au filtre.
	 */
	public PackageRelationshipCollection getRelationshipsByType(
			String relationshipType) {
		throwExceptionIfWriteOnly();
		if (relationshipType == null)
			throw new IllegalArgumentException(
					"relationshipType ne doit pas �tre null !");
		return getRelationshipsHelper(relationshipType);
	}

	/**
	 * R�cup�rer les relations poss�dant le type sp�cifi�.
	 * 
	 * @param id
	 *            Le type des relations d�sir�es.
	 */
	private PackageRelationshipCollection getRelationshipsHelper(String id) {
		throwExceptionIfWriteOnly();
		if (relationships == null)
			relationships = new PackageRelationshipCollection(this);
		return relationships.getRelationships(id);
	}

	/**
	 * Supprime toutes les relations de package.
	 */
	private void clearRelationships() {
		if (relationships != null)
			relationships.clear();
	}

	/**
	 * Enregistre le document dans le fichier sp�cifi�.
	 * 
	 * @param destFile
	 *            Le fichier de destination
	 */
	public void save(File destFile) {
		// On v�rifie que le document a �t� ouvert en �criture
		throwExceptionIfReadOnly();

		try {
			// Cr�ation d'un fichier de destination temporaire pour le document
			ZipOutputStream zos = new ZipOutputStream(new FileOutputStream(
					destFile));

			System.out.println("Save content type part");
			// Enregistrement du fichier de type de contenu
			contentTypeHelper.save(zos);

			System.out.println("Save package relationships part");
			// Enregistrement des relations du package
			ZipPackageMarshaller packageMarshaller = new ZipPackageMarshaller(
					this);
			packageMarshaller.marshall(null, zos);

			// Enregistrement des parties
			for (PackagePart part : getParts()) {
				if (part.isDeleted())
					throw new InvalidOperationException(
							"Erreur, la partie ne devrait pas exister !");

				// Si la partie est une relation, on ne l'enregistre pas, c'est
				// la partie source qui le fera.
				if (part.isRelationshipPart())
					continue;

				System.out.println("Save " + part.getUri().getPath() + " part");
				PartMarshaller marshaller = partMarshallers
						.get(part.contentType);
				if (marshaller != null)
					marshaller.marshall(part, zos);
				else
					defaultPartMarshaller.marshall(part, zos);
			}
			zos.close();
		} catch (IOException e) {
			System.err
					.println("Echec de l'enregistrement : une erreur est survenue pendant l'enregistrement !");
		}
	}

	/**
	 * Ajoute un marshaller.
	 * 
	 * @param contentType
	 *            Le type de contenu associ� � ce marshaller.
	 * @param marshaller
	 *            Le marshaller � utilsier pour enregistrer les parties du type
	 *            de contenu sp�cifi�.
	 */
	public void addMarshaller(String contentType, PartMarshaller marshaller) {
		partMarshallers.put(contentType, marshaller);
	}

	/**
	 * Supprimer un marshaller en fonction de son type de contenu.
	 * 
	 * @param contentType
	 *            Le type de contenu de la partie � supprimer.
	 */
	public void removeMarshaller(String contentType) {
		partMarshallers.remove(contentType);
	}

	/**
	 * Enregistre les parties dans le flux compress� Zip
	 */
	public void marshall(PackagePart part, OutputStream out) {
		ZipOutputStream zos = (ZipOutputStream) out;
		part.save(zos);
	}

	/* Accesseurs */

	public ZipFile getArchive() {
		return archive;
	}

	public ContentTypeHelper getContentTypeHelper() {
		return contentTypeHelper;
	}

	public PackageAccess getPackageAccess() {
		return packageAccess;
	}

	/**
	 * Classe d'aide qui g�re les types de contenu des parties.
	 * 
	 * @author Julien Chable
	 */
	final class ContentTypeHelper {

		/**
		 * Le nom du fichier de contenu
		 */
		public static final String CONTENT_TYPES_FILENAME = "[Content_Types].xml";

		public static final String TYPES_NAMESPACE_URI = "http://schemas.openxmlformats.org/package/2006/content-types";

		private static final String TYPES_TAG_NAME = "Types";

		private static final String DEFAULT_TAG_NAME = "Default";

		private static final String EXTENSION_ATTRIBUTE_NAME = "Extension";

		private static final String CONTENT_TYPE_ATTRIBUTE_NAME = "ContentType";

		private static final String OVERRIDE_TAG_NAME = "Override";

		private static final String PART_NAME_ATTRIBUTE_NAME = "PartName";

		private ZipEntry contentTypeZipEntry;

		private TreeMap<String, String> defaultContentType;

		private TreeMap<URI, String> overrideContentType;

		private ZipFile zipArchive;

		/**
		 * Constructeur.
		 * 
		 * @param archive
		 *            L'archive du document, si diff�rent de <i>null</i> alors
		 *            le fichier de types de contenu de l'archive est pars�.
		 */
		public ContentTypeHelper(ZipFile archive) {
			this.zipArchive = archive;
			this.defaultContentType = new TreeMap<String, String>();
			if (archive != null)
				parseContentTypesFile();
		}

		/**
		 * Parse le contenu du fichier de types de l'archive.
		 */
		private void parseContentTypesFile() {
			contentTypeZipEntry = getContentTypeZipEntry();
			InputStream inStream = null;
			try {
				inStream = zipArchive.getInputStream(contentTypeZipEntry);
			} catch (IOException e) {
				throw new InvalidFormatException(
						"Impossible de lire le fichier "
								+ CONTENT_TYPES_FILENAME);
			}

			// Cr�ation du parser DOM
			DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory
					.newInstance();
			documentBuilderFactory.setNamespaceAware(true);
			documentBuilderFactory.setIgnoringElementContentWhitespace(true);
			DocumentBuilder documentBuilder;
			try {
				documentBuilder = documentBuilderFactory.newDocumentBuilder();

				// On parse le document XML en arbre DOM
				Document xmlContentTypetDoc = documentBuilder.parse(inStream);

				// On parcourt les types par d�faut
				NodeList defaultTypes = xmlContentTypetDoc
						.getElementsByTagName(DEFAULT_TAG_NAME);
				for (int i = 0; i < defaultTypes.getLength(); ++i) {
					// On ajoute l'�l�ment du type par d�faut dans sa collection
					Node type = defaultTypes.item(i);
					String extension = type.getAttributes().getNamedItem(
							EXTENSION_ATTRIBUTE_NAME).getNodeValue();
					String contentType = type.getAttributes().getNamedItem(
							CONTENT_TYPE_ATTRIBUTE_NAME).getNodeValue();
					addDefaultContentType(extension, contentType);
				}

				// On parcourt les types surd�finis
				NodeList overrideTypes = xmlContentTypetDoc
						.getElementsByTagName(OVERRIDE_TAG_NAME);
				for (int i = 0; i < overrideTypes.getLength(); ++i) {
					// On ajoute l'�l�ment du type par d�faut dans sa collection
					Node type = overrideTypes.item(i);
					URI uri = new URI(type.getAttributes().getNamedItem(
							PART_NAME_ATTRIBUTE_NAME).getNodeValue());
					String contentType = type.getAttributes().getNamedItem(
							CONTENT_TYPE_ATTRIBUTE_NAME).getNodeValue();
					addOverrideContentType(uri, contentType);
				}
			} catch (ParserConfigurationException e) {

			} catch (IOException ioe) {

			} catch (SAXException saxe) {

			} catch (URISyntaxException urie) {

			}
		}

		public void addContentType(URI partUri, String contentType) {
			boolean defaultCTExists = false;
			String extension = PackageURIHelper.getExtensionForPartURI(partUri);
			if ((extension.length() == 0)
					|| (this.defaultContentType.containsKey(extension) && !(defaultCTExists = this.defaultContentType
							.containsValue(contentType))))
				this.addOverrideContentType(partUri, contentType);
			else if (!defaultCTExists)
				this.addDefaultContentType(extension, contentType);
		}

		private void addOverrideContentType(URI partUri, String contentType) {
			if (overrideContentType == null)
				overrideContentType = new TreeMap<URI, String>();
			overrideContentType.put(partUri.normalize(), contentType);
		}

		private void addDefaultContentType(String extension, String contentType) {
			defaultContentType.put(extension, contentType);
		}

		public void deleteContentType(URI partUri) {
			if (this.overrideContentType != null) {
				this.overrideContentType.remove(partUri.normalize());
			}
		}

		public String getContentType(URI partUri) {
			URI normPartUri;
			try {
				normPartUri = new URI(PackageURIHelper.FORWARD_SLASH_CHAR
						+ partUri.normalize().getPath());
			} catch (URISyntaxException e) {
				return null;
			}

			if ((this.overrideContentType != null)
					&& this.overrideContentType.containsKey(normPartUri))
				return this.overrideContentType.get(normPartUri);

			String extension = PackageURIHelper.getExtensionForPartURI(partUri);
			if (this.defaultContentType.containsKey(extension))
				return this.defaultContentType.get(extension);

			return null;
		}

		/**
		 * On r�cup�rer l'entr�e du fichier Zip qui contient le contenu du
		 * fichier de type de contenu.
		 */
		private ZipEntry getContentTypeZipEntry() {
			Enumeration entries = zipArchive.entries();
			// On �num�re toutes les entr�es de l'archive Zip jusqu'� trouver
			// celle du fichier [Content_Types].xml
			while (entries.hasMoreElements()) {
				ZipEntry entry = (ZipEntry) entries.nextElement();
				if (entry.getName().equals(CONTENT_TYPES_FILENAME))
					return entry;
			}
			return null;
		}

		public void save(ZipOutputStream outStream) {
			DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
			dbf.setNamespaceAware(true);

			// Schema
			try {
				SchemaFactory sf = SchemaFactory
						.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
				Schema schema = sf.newSchema(new File(System
						.getProperty("user.dir")
						+ File.separator
						+ "schemas"
						+ File.separator
						+ "opc-contenttypes.xsd"));
				dbf.setSchema(schema);
				dbf.setValidating(true);
			} catch (SAXException e) {
				System.err.println("Le fichier XML " + CONTENT_TYPES_FILENAME
						+ " ne comportera pas de namespace !");
			}

			// Cr�ation de la sortie XML
			DocumentBuilder db = null;
			try {
				db = dbf.newDocumentBuilder();
			} catch (ParserConfigurationException e) {
				System.err
						.println("Echec de l'enregistrement : impossibilit� de cr�er le fichier XML !");
			}

			Document xmlOutDoc = db.newDocument();
			// L'�l�ment racine Types
			Element typesElem = xmlOutDoc.createElement(TYPES_TAG_NAME);
			// Ajout du namespace
			typesElem.setAttribute("xmlns", TYPES_NAMESPACE_URI);

			// On ajoute tous les types par d�faut
			for (Entry<String, String> entry : defaultContentType.entrySet()) {
				// L'�l�ment du type par d�faut
				Element defaultElem = xmlOutDoc.createElement(DEFAULT_TAG_NAME);
				// L'attribut Extension
				Attr extAttr = xmlOutDoc
						.createAttribute(EXTENSION_ATTRIBUTE_NAME);
				extAttr.setNodeValue(entry.getKey());
				// L'attribut ContentType
				Attr ctAttr = xmlOutDoc
						.createAttribute(CONTENT_TYPE_ATTRIBUTE_NAME);
				ctAttr.setNodeValue(entry.getValue());
				defaultElem.setAttributeNode(ctAttr);
				defaultElem.setAttributeNode(extAttr);
				typesElem.appendChild(defaultElem);
			}

			// On ajoute tous les types sp�cifiques
			for (Entry<URI, String> entry : overrideContentType.entrySet()) {
				// L'�l�ment du type par d�faut
				Element overrideElem = xmlOutDoc
						.createElement(OVERRIDE_TAG_NAME);
				// L'attribut Extension
				Attr partNameAttr = xmlOutDoc
						.createAttribute(PART_NAME_ATTRIBUTE_NAME);
				partNameAttr.setNodeValue(entry.getKey().getPath());
				// L'attribut ContentType
				Attr ctAttr = xmlOutDoc
						.createAttribute(CONTENT_TYPE_ATTRIBUTE_NAME);
				ctAttr.setNodeValue(entry.getValue());
				overrideElem.setAttributeNode(ctAttr);
				overrideElem.setAttributeNode(partNameAttr);
				typesElem.appendChild(overrideElem);
			}

			xmlOutDoc.appendChild(typesElem);
			xmlOutDoc.normalize();

			// Enregistrement de la partie dans le zip
			ZipEntry ctEntry = new ZipEntry(CONTENT_TYPES_FILENAME);
			try {
				// Cr�ation de l'entr�e dans le fichier ZIP
				outStream.putNextEntry(ctEntry);
				DOMSource source = new DOMSource(xmlOutDoc);
				StreamResult result = new StreamResult(outStream);
				TransformerFactory transFactory = TransformerFactory
						.newInstance();
				try {
					Transformer transformer = transFactory.newTransformer();
					transformer.setOutputProperty("indent", "yes");
					transformer.transform(source, result);
				} catch (TransformerException e) {
					System.err
							.println("Echec de l'enregistrement : impossible de cr�er le fichier "
									+ CONTENT_TYPES_FILENAME);
				}
				// Fermeture de l'entr�e du fichier ZIP
				outStream.closeEntry();
			} catch (IOException e1) {
				System.err.println("");
			}
		}
	}
}