using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Xml.Serialization;

using Budget.Entities;
using Budget.Contract;
using Microsoft.SharePoint;
using System.IO;
using Microsoft.VisualStudio.Tools.Applications.Runtime;
using System.Xml;

namespace Budget
{
    public class BudgetServiceImplementation : IBudgetService
    {
        private XmlSerializer BudgetSerializer = new XmlSerializer(typeof(BudgetReportEntity));

        #region IBudgetService Members

        public BudgetReportResponseMessage GetReports(BudgetReportRequestMessage request)
        {
            BudgetReportResponseMessage response = new BudgetReportResponseMessage();

            #region Dummy Implementation
            /*
            Random rnd = new Random();

            for (int i = 0; i < 12; i++)
            {
                BudgetReportEntity report = new BudgetReportEntity();

                // General report data
                report.ReportId = Guid.NewGuid().ToString();
                report.ReportDate = DateTime.Now;
                // Project data;
                report.Project.ProjectID = i;
                report.Project.ProjectName = string.Format("Project {0}", i);
                report.Project.Description = "This is a test project " + i.ToString();
                // Department data
                report.Department.DepartmentID = i.ToString();
                report.Department.Name = string.Format("Department {0}", i);
                report.Department.Description = "Some Department " + i.ToString();
                report.Department.Manager.EmployeeID = i;
                report.Department.Manager.Firstname = "First " + i.ToString();
                report.Department.Manager.Lastname = "Last " + i.ToString();
                
                // Report items data
                for (int j = 0; j < rnd.Next(3, 7); j++)
                {
                    BudgetReportItemEntity item = new BudgetReportItemEntity();
                    item.Amount = (j + 1) * rnd.Next(10, 100);
                    item.Category = "Category " + j.ToString();
                    item.Description = string.Format("{0} spendings {1}", report.Department.Name, j); 
                    item.ItemDate = DateTime.Now.Subtract(TimeSpan.FromDays(j));
                    report.Items.Add(item);
                }

                response.Reports.Add(report);
            }
            */
            #endregion

            // Connect to the SharePoint site
            SPSite site = new SPSite(ConfigurationManager.AppSettings["SPSite"]);
            SPWeb web = site.OpenWeb();
            SPList docLibrary = web.GetList(ConfigurationManager.AppSettings["BudgetLibrary"]);

            // Run through the library's entries and get data from the document
            foreach (SPListItem report in docLibrary.Items)
            {
                // Budget report for deserialization
                Budget.Entities.BudgetReportEntity reportEntity = null;

                // Get the file and open a stream
                byte[] fileBytes = report.File.OpenBinary();
                ServerDocument document = new ServerDocument(fileBytes, report.File.Name);
                foreach (CachedDataHostItem host in document.CachedData.HostItems)
                {
                    // A host item is a sheet hosting data in case of excel
                    foreach (CachedDataItem item in host.CachedData)
                    {
                        // There is one report in our item
                        StringReader sr = new StringReader(item.Xml);
                        XmlTextReader xtr = new XmlTextReader(sr);
                        reportEntity = BudgetSerializer.Deserialize(xtr) as BudgetReportEntity;
                        response.Reports.Add(reportEntity);
                    }
                }
            }

            return response;
        }

        #endregion
    }
}
