import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import org.dom4j.Document;
import org.dom4j.io.XMLWriter;
import org.openxmldeveloper.samples.opc.PackagePart;
import org.openxmldeveloper.samples.opc.PackageURIHelper;
import org.openxmldeveloper.samples.opc.ZipPartMarshaller;


public class WordDocumentMarshaller extends ZipPartMarshaller {

	private Document wordDocument;
	
	public WordDocumentMarshaller(Document domDocument)
	{
		wordDocument = domDocument;
	}
	
	public void marshall(PackagePart part, OutputStream os) 
	{
		if(!(os instanceof ZipOutputStream))
		{
			throw new IllegalArgumentException("OutputStream os must be ZipOutputStream");
		}
		ZipOutputStream ZipStream = (ZipOutputStream)os;
		
		ZipEntry wordDocumentZipEntry = new ZipEntry("word/document.xml");
		try {
			// Write the file back to the hard disk
			File tempFile = File.createTempFile("TestDocGenerator", ".xml");
			FileWriter tempFileWriter = new FileWriter(tempFile);
			XMLWriter xmlW = new XMLWriter(tempFileWriter);
			xmlW.write(wordDocument);
			xmlW.flush();
			xmlW.close();
			
			// Now read the file and write it to the Zip-Stream
			ZipStream.putNextEntry(wordDocumentZipEntry);
			
			int c;
			byte[] buff = new byte[512];
			FileInputStream fis = new FileInputStream(tempFile);
			while (fis.available() > 0) {
				c = fis.read(buff);
				ZipStream.write(buff, 0, c);
			}
			
			ZipStream.closeEntry();
		} catch (IOException e1) {
			System.err.println("");
		}
		
		// Enregistrement des relations
		if (part.hasRelationships())
			marshallRelationshipPart(part.getRelationships(), PackageURIHelper
					.getRelationshipPartUri(part.getUri()), ZipStream);
	}
}
