/**
 * ProjectService.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.3 Oct 05, 2005 (05:23:37 EDT) WSDL2Java emitter.
 */

package com.microsoft.www.austria._2007._2.EUConference.Budgeting.projects;

public interface ProjectService extends javax.xml.rpc.Service {
    public java.lang.String getProjectServiceSoapAddress();

    public com.microsoft.www.austria._2007._2.EUConference.Budgeting.projects.ProjectServiceSoap getProjectServiceSoap() throws javax.xml.rpc.ServiceException;

    public com.microsoft.www.austria._2007._2.EUConference.Budgeting.projects.ProjectServiceSoap getProjectServiceSoap(java.net.URL portAddress) throws javax.xml.rpc.ServiceException;
}
