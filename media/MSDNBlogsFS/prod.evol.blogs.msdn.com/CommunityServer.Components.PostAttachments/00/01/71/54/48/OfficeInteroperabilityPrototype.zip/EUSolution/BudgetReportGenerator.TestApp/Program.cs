using System;
using System.IO;
using System.Xml;

namespace BudgetReportGenerator.TestApp
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                Console.WriteLine("Starting document generation...");

                Console.WriteLine("Please specify template-file: ");
                string templateFile = Console.ReadLine();
                Console.WriteLine("Please specify target-file: ");
                string targetFile = Console.ReadLine();

                Console.WriteLine(">> Copy template...");
                File.Copy(templateFile, targetFile);

                Console.WriteLine(">> Create generator...");
                using (FileStream fs = new FileStream(targetFile, FileMode.Open, FileAccess.ReadWrite))
                {
                    ReportGenerator Generator = new ReportGenerator();
                    Generator.GenerateDocument(fs, DateTime.Now, DateTime.Now);
                }
                Console.WriteLine(">> Generation completed!");

                Console.WriteLine("Document genrated!");
            }
            catch (Exception ex)
            {
                Console.WriteLine("Generation failed!");
                Console.WriteLine(ex.Message);
            }

            Console.WriteLine("Press <ENTER> to quit!");
            Console.ReadLine();
        }
    }
}
