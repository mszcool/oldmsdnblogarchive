package org.openxmldeveloper.samples.document.word;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.InputStream;

import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;

import org.openxmldeveloper.samples.document.DocumentTransformer;
import org.openxmldeveloper.samples.document.OpenXMLDocument;


/**
 * Transforme un document Word en document HTML.
 * 
 * @author Julien Chable
 */
public class WordToHTMLTransformer implements DocumentTransformer {

	public InputStream transform(OpenXMLDocument doc) {
		if (!(doc instanceof WordDocument))
			throw new IllegalArgumentException(
					"Le document doit �tre de type Word !");

		WordDocument docx = (WordDocument) doc;

		ByteArrayOutputStream retStream = new ByteArrayOutputStream();
		DOMSource source = new DOMSource(docx.getCoreDocument());
		StreamResult result = new StreamResult(retStream);
		TransformerFactory transFactory = TransformerFactory.newInstance();
		try {
			Transformer transformer = transFactory
					.newTransformer(new StreamSource(new File(System
							.getProperty("user.dir")
							+ File.separator
							+ "xslt"
							+ File.separator
							+ "DocxToHTML.xslt")));
			// Si d�sactiv� permet de gagner de r�duire la taille du fichier
			transformer.setOutputProperty(OutputKeys.INDENT, "yes");
			transformer.setOutputProperty(OutputKeys.STANDALONE, "yes");
			transformer.transform(source, result);
			return new ByteArrayInputStream(retStream.toByteArray());
		} catch (TransformerException e) {
			System.err
					.println("Echec de la transformation : " + e.getMessage());
			return null;
		}
	}
}