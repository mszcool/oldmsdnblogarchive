using System;
using System.Collections.Generic;
using System.Text;

namespace BudgetReportGenerator
{
    public class ReportGeneratorConstants
    {
        public const string WordNamespace = "http://schemas.openxmlformats.org/wordprocessingml/2006/main";
        public const string OfficeNamespace = "urn:schemas-microsoft-com:office:office";

        public const string BudgetNamespace = "http://www.microsoft.com/austria/samples/euconference/2007/02/budgetreport";

        public const string WordText = "<w:t xml:space=\"preserve\">{0}</w:t>";
        public const string WordRun = "<w:r>{0}</w:r>";
        public const string WordBreak = "<w:br />";

        public const string WordDocumentPartUri = "/word/document.xml";
        public const string WordDocumentPartContentType = "application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml";
    }
}
