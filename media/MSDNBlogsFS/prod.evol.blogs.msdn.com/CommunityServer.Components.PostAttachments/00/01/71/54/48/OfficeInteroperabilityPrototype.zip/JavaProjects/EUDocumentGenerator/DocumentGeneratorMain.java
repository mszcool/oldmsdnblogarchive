public class DocumentGeneratorMain {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		try 
		{
	        javax.swing.SwingUtilities.invokeLater(new Runnable() {
	            public void run() {
	                createAndShowGUI();
	            }
	        });
		}
		catch(Exception ex)
		{
			System.out.println("Document generation failed: " + ex);
			ex.printStackTrace();
		}
	}
	
    private static void createAndShowGUI() {
        //Create and set up the window.
        DocumentGeneratorUI ui = new DocumentGeneratorUI();
        //Display the window.
        ui.pack();
        ui.setVisible(true);
    }
}
