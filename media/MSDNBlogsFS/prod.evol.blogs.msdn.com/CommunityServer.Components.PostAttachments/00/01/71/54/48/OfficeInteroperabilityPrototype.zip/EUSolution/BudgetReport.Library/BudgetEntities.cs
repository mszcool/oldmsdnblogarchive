using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Xml.Serialization;

using Department.Entities;
using Project.Entities;
using EUServices.NamespaceNames;
using System.Collections.Generic;

namespace Budget.Entities
{
    [XmlType(Namespace=Constants.BudgetServiceEntityNamespace)]
    public class BudgetReportEntity
    {
        private string _ReportId;
        public string ReportId
        {
            get { return _ReportId; }
            set { _ReportId = value; }
        }

        private DateTime _ReportDate;
        public DateTime ReportDate
        {
            get { return _ReportDate; }
            set { _ReportDate = value; }
        }

        private DepartmentEntity _Department;
        public DepartmentEntity Department
        {
            get { return _Department; }
            set { _Department = value; }
        }

        private ProjectEntity _Project;
        public ProjectEntity Project
        {
            get { return _Project; }
            set { _Project = value; }
        }

        private List<BudgetReportItemEntity> _Items;
        public List<BudgetReportItemEntity> Items
        {
            get { return _Items; }
            set { _Items = value; }
        }

        public BudgetReportEntity() 
        {
            Project = new ProjectEntity();
            Department = new DepartmentEntity();
            Department.Manager = new GeneralEntities.Employee();
            Items = new List<BudgetReportItemEntity>();
        }
    }

    [XmlType(Namespace=Constants.BudgetServiceEntityNamespace)]
    public class BudgetReportItemEntity
    {
        private DateTime _ItemDate;

        public DateTime ItemDate
        {
            get { return _ItemDate; }
            set { _ItemDate = value; }
        }

        private string _Description;

        public string Description
        {
            get { return _Description; }
            set { _Description = value; }
        }

        private string _CategoryName;

        public string Category
        {
            get { return _CategoryName; }
            set { _CategoryName = value; }
        }

        private decimal _Amount;

        public decimal Amount
        {
            get { return _Amount; }
            set { _Amount = value; }
        }
    }
}