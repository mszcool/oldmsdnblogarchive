package org.openxmldeveloper.samples.opc;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URI;

public final class MemoryPackagePart extends PackagePart {

	/**
	 * Les donn�es de la partie.
	 */
	protected byte[] data;

	/**
	 * La longueur des donn�es.
	 */
	protected int length;

	public MemoryPackagePart(Package pack, URI partURI, String contentType) {
		super(pack, partURI, contentType);
	}

	@Override
	protected InputStream getInputStreamImpl() {
		if(data != null)
			return new ByteArrayInputStream(data);
		else
			return null;
	}

	@Override
	protected OutputStream getOutputStreamImpl() {
		return new MemoryPackagePartOutputStream(this);
	}

	public void clear() {
		data = null;
		length = 0;
	}

	@Override
	public void save(OutputStream os) {
		new ZipPartMarshaller().marshall(this, os);
	}
}