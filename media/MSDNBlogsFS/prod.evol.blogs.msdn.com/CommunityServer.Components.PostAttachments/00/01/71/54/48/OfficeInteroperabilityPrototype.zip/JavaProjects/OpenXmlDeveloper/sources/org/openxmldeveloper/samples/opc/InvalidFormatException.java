package org.openxmldeveloper.samples.opc;

@SuppressWarnings("serial")
public class InvalidFormatException extends RuntimeException{

	public InvalidFormatException(String message){
		super(message);
	}
}