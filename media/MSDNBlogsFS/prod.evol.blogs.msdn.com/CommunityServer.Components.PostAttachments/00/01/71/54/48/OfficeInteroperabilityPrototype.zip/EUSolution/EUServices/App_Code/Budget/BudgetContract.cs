using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Xml.Serialization;

using Budget.Entities;
using EUServices.NamespaceNames;
using System.Collections.Generic;

namespace Budget.Contract
{
    [XmlType(Namespace=Constants.BudgetServiceNamespace)]
    public class BudgetReportRequestMessage
    {
        public DateTime StartDate;
        public DateTime EndDate;
    }

    [XmlType(Namespace = Constants.BudgetServiceNamespace)]
    public class BudgetReportResponseMessage
    {
        public List<BudgetReportEntity> Reports;

        public BudgetReportResponseMessage()
        {
            Reports = new List<BudgetReportEntity>();
        }
    }

    [XmlType(Namespace = Constants.BudgetServiceNamespace)]
    public interface IBudgetService
    {
        BudgetReportResponseMessage GetReports(BudgetReportRequestMessage request);
    }
}
