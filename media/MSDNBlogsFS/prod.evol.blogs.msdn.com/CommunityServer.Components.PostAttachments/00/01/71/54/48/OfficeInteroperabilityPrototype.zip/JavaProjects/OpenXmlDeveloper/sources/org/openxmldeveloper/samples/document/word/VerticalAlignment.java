package org.openxmldeveloper.samples.document.word;

/**
 * Alignement verticale de niveau caract�re.
 * 
 * @author Julien Chable
 */
public enum VerticalAlignment {
	NONE, SUBSCRIPT, SUPERSCRIPT;

	@Override
	public String toString() {
		return name().toLowerCase();
	}
}