/**
 * ProjectServiceSoap.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.3 Oct 05, 2005 (05:23:37 EDT) WSDL2Java emitter.
 */

package com.microsoft.www.austria._2007._2.EUConference.Budgeting.projects;

public interface ProjectServiceSoap extends java.rmi.Remote {
    public com.microsoft.www.austria._2007._2.EUConference.Budgeting.projects.CategoriesResponseMessage getCategories() throws java.rmi.RemoteException;
    public com.microsoft.www.austria._2007._2.EUConference.Budgeting.projects.ProjectsResponseMessage getProjects(com.microsoft.www.austria._2007._2.EUConference.Budgeting.projects.ProjectsRequestMessage request) throws java.rmi.RemoteException;
}
