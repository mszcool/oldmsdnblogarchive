using System;
using System.Xml;
using System.Collections.Generic;
using System.IO;
using System.IO.Packaging;

namespace BudgetReportGenerator
{
    public class ReportGenerator
    {
        private XmlDocument doc;
        private XmlNamespaceManager nsMgr;

        public void GenerateDocument(Stream package, DateTime start, DateTime end)
        {
            // Open the package and find the word-part
            Package p = Package.Open(package, FileMode.Open, FileAccess.ReadWrite);
            Uri documentPartUri = new Uri(
                ReportGeneratorConstants.WordDocumentPartUri, UriKind.Relative);
            PackagePart documentPart = p.GetPart(documentPartUri);

            // Open a stream to the document and load it into an XmlDocument
            Stream documentStream = documentPart.GetStream(FileMode.Open, FileAccess.Read);
            doc = new XmlDocument();
            doc.Load(documentStream);
            nsMgr = new XmlNamespaceManager(doc.NameTable);
            nsMgr.AddNamespace("w", ReportGeneratorConstants.WordNamespace);
            ProcessDocument(start, end);
            
            // Now save the part back to the package
            documentStream = documentPart.GetStream(FileMode.Open, FileAccess.Write);
            doc.Save(documentStream);
        }

        private void ProcessDocument(DateTime start, DateTime end)
        {
            BudgetProxy.BudgetReportEntity[] reports;

            // Get the budget-data from the web service
            reports = GetReportsFromWebService(ref start, ref end);

            // Define root elements
            XmlNode departmentDetails = GetElement(doc.DocumentElement, "departmentDetails", "//");
            XmlNode departmentOverviews = GetElement(doc.DocumentElement, "departmentOverviews", "//");
            XmlNode departmentOverviewsTable = departmentOverviews.SelectSingleNode(".//w:tbl", nsMgr);

            // Go through the reports and create summary lines
            decimal gains, losses, results = 0;
            XmlNode departmentDetailNode = null;
            XmlNode departmentDetailOriginalNode = null;
            XmlNode departmentDetailNodeTbl = null;
            XmlNode departmentOverviewNode = null;
            foreach (BudgetProxy.BudgetReportEntity report in reports)
            {
                gains = losses = 0;
                string departmentName = string.Format("{0} ({1})",
                                            report.Department.Name,
                                            report.Project.ProjectName);

                #region Department Details

                if (departmentDetailOriginalNode == null)
                {
                    departmentDetailNode = GetElement(departmentDetails, "departmentDetail", ".//");
                    departmentDetailOriginalNode = departmentDetailNode.CloneNode(true);
                }
                else
                {
                    departmentDetailNode = departmentDetailOriginalNode.CloneNode(true);
                    departmentDetails.AppendChild(departmentDetailNode);
                }
                UpdateElement(departmentDetailNode, "departmentName", departmentName);
                departmentDetailNodeTbl = departmentDetailNode.SelectSingleNode(".//w:tbl", nsMgr);

                #endregion

                // Calculate totals
                XmlNode budgetItemNode = null;
                XmlNode budgetItemOriginalNode = null;
                foreach (BudgetProxy.BudgetReportItemEntity item in report.Items)
                {
                    if (item.Amount > 0)
                        gains += item.Amount;
                    else
                        losses += (-1) * item.Amount;

                    #region Department Details

                    if (budgetItemOriginalNode == null)
                    {
                        budgetItemNode = GetElement(departmentDetailNode, "budgetItem", ".//");
                        budgetItemOriginalNode = budgetItemNode.CloneNode(true);
                    }
                    else
                    {
                        budgetItemNode = budgetItemOriginalNode.CloneNode(true);
                        departmentDetailNodeTbl.AppendChild(budgetItemNode);
                    }
                    UpdateElement(budgetItemNode, "description", item.Description);
                    UpdateElement(budgetItemNode, "amount", item.Amount.ToString());

                    #endregion
                }

                // Each department has one line in the summary-table
                #region Department Overview
                if (departmentOverviewNode == null)
                {
                    departmentOverviewNode = GetElement(departmentOverviews, "overviewItem", ".//");
                }
                else
                {
                    departmentOverviewNode = departmentOverviewNode.CloneNode(true);
                    departmentOverviewsTable.AppendChild(departmentOverviewNode);
                }

                // Update the fields 
                UpdateElement(departmentOverviewNode, "departmentName", departmentName);
                UpdateElement(departmentOverviewNode, "gains", gains.ToString());
                UpdateElement(departmentOverviewNode, "losses", losses.ToString());
                UpdateElement(departmentOverviewNode, "results", (gains - losses).ToString());
                #endregion

                // Overall results
                results += (gains - losses);
            }

            // Fill in the header-data
            UpdateElement(doc.DocumentElement, "reportID", Guid.NewGuid().ToString());
            UpdateElement(doc.DocumentElement, "reportDate", DateTime.Today.ToString("yyyy-MM-dd"));
            UpdateElement(doc.DocumentElement, "resultsValue", results.ToString());
            UpdateElement(doc.DocumentElement, "fromPeriod", start.ToString("yyyy-MM-dd"));
            UpdateElement(doc.DocumentElement, "toPeriod", end.ToString("yyyy-MM-dd"));
        }

        private void UpdateElement(XmlNode departmentOverviewNode, string elementName, string elementValue)
        {
            XmlNode customXmlNode = GetElement(departmentOverviewNode, elementName, ".//");
            XmlNode wordTextRun = customXmlNode.SelectSingleNode(".//w:t", nsMgr);
            wordTextRun.InnerText = elementValue;
        }

        private XmlNode GetElement(XmlNode parent, string elementName, string queryPrefix)
        {
            return parent.SelectSingleNode(
                        string.Format("{0}w:customXml[@w:element='{1}']",
                                      queryPrefix, elementName),
                        nsMgr
                   );
        }

        private static BudgetProxy.BudgetReportEntity[] GetReportsFromWebService(ref DateTime start, ref DateTime end)
        {
            BudgetProxy.BudgetReportEntity[] reports;
            BudgetProxy.BudgetReportRequestMessage request =
                new BudgetReportGenerator.BudgetProxy.BudgetReportRequestMessage();
            request.StartDate = start;
            request.EndDate = end;

            BudgetProxy.BudgetReportResponseMessage response;
            BudgetProxy.BudgetReports service = new BudgetReportGenerator.BudgetProxy.BudgetReports();
            service.Credentials = System.Net.CredentialCache.DefaultCredentials;
            response = service.GetReports(request);
            reports = response.Reports;
            return reports;
        }
    }
}
