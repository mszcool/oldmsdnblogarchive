package org.openxmldeveloper.samples.opc;

@SuppressWarnings("serial")
public class InvalidOperationException extends RuntimeException{

	public InvalidOperationException(String message){
		super(message);
	}
}