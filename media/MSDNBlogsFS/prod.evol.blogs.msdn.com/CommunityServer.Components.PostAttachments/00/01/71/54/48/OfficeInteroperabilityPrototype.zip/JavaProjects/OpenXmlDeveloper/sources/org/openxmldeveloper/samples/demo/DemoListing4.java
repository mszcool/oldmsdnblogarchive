package org.openxmldeveloper.samples.demo;

import java.io.File;
import java.io.IOException;
import java.util.zip.ZipFile;

import org.openxmldeveloper.samples.document.CoreProperties;
import org.openxmldeveloper.samples.document.OpenXMLDocument;
import org.openxmldeveloper.samples.opc.Package;
import org.openxmldeveloper.samples.opc.PackageAccess;

/**
 * Modify the core properties of a document.
 * 
 * @author Julien Chable
 */
public class DemoListing4 {

	public static void main(String[] args) {
		final String APP_ROOT = System.getProperty("user.dir") + File.separator;
		ZipFile zipFile = null;
		try {
			zipFile = new ZipFile(APP_ROOT + "sample.docx");
		} catch (IOException e) {
			e.printStackTrace();
		}

		// Destination file
		File destFile = new File(APP_ROOT + "sample_out.docx");

		// Open the document
		Package pack = Package.open(zipFile, PackageAccess.ReadWrite);
		OpenXMLDocument docx = new OpenXMLDocument(pack);
		
		CoreProperties coreProps = docx.getCoreProperties();
		coreProps.setCreator("OpenXMLDeveloer.org powa !");
		coreProps.setDescription("A new description");
		coreProps.setTitle("SampleListing4");
		
		// Save document
		docx.save(destFile);
	}
}
