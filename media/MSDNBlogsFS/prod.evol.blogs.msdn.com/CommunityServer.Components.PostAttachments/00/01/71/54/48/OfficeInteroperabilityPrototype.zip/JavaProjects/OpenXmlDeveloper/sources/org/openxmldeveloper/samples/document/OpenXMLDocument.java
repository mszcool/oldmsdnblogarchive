package org.openxmldeveloper.samples.document;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.util.zip.ZipOutputStream;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.openxmldeveloper.samples.opc.ContentTypeConstant;
import org.openxmldeveloper.samples.opc.InvalidFormatException;
import org.openxmldeveloper.samples.opc.Package;
import org.openxmldeveloper.samples.opc.PackageAccess;
import org.openxmldeveloper.samples.opc.PackagePart;
import org.openxmldeveloper.samples.opc.PackageRelationship;
import org.openxmldeveloper.samples.opc.PackageRelationshipConstants;
import org.openxmldeveloper.samples.opc.PackageURIHelper;
import org.openxmldeveloper.samples.opc.PartMarshaller;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;


/**
 * Repr�sente un document OpenXML en g�n�ral. Cette classe encapsule toutes les
 * m�thodes qui permettent de manipuler un package de mani�re transparente.
 * 
 * @author Julien Chable
 * @version 0.2
 * 
 */
public class OpenXMLDocument {

	protected Package container;

	protected CorePropertiesHelper corePropertiesHelper;

	/**
	 * Constructeur.
	 * 
	 * @param docPackage
	 *            R�f�rence vers le package du document.
	 */
	public OpenXMLDocument(Package docPackage) {
		container = docPackage;
		corePropertiesHelper = new CorePropertiesHelper(container);
		// On associe le CorePropertiesHelper de cette classe comme �tant
		// l'enregistreur des parties de type propri�t� du document.
		container.addMarshaller(ContentTypeConstant.CORE_PROPERTIES,
				corePropertiesHelper);
	}

	/**
	 * Extrait toutes les ressources du type sp�cifi� et les place dans le
	 * r�pertoire cible.
	 * 
	 * @param contentType
	 *            Le type de contenu.
	 * @param destFolder
	 *            Le r�pertoire cible.
	 */
	public void extractFiles(String contentType, File destFolder) {
		if (!destFolder.isDirectory())
			throw new IllegalArgumentException(
					"Le param�tre desFolder doit �tre un r�pertoire !");

		ArrayList<PackagePart> parts = new ArrayList<PackagePart>();
		for (PackagePart part : container.getPartByContentType(contentType))
			parts.add(part);
		extractParts(parts, destFolder);
	}

	/**
	 * Extrait le contenu des parties sp�cifi�es dans le r�pertoire cible.
	 * 
	 * @param parts
	 *            Les parties � extraire.
	 * @param destFolder
	 *            Le r�pertoire de destination.
	 */
	public void extractParts(ArrayList<PackagePart> parts, File destFolder) {
		for (PackagePart part : parts) {
			String filename = PackageURIHelper.getFilename(part.getUri());
			try {
				InputStream ins = part.getInputStream();
				FileOutputStream fw = new FileOutputStream(destFolder
						.getAbsolutePath()
						+ File.separator + filename);
				byte[] buff = new byte[512];
				while (ins.available() > 0) {
					ins.read(buff);
					fw.write(buff);
				}
				fw.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

	/**
	 * Obtenir toutes les parties �tant des images d'aper�us du document.
	 */
	public ArrayList<PackagePart> getThumbnails() {
		return container
				.getPartByRelationshipType(PackageRelationshipConstants.NS_THUMBNAIL_PART);
	}

	/**
	 * Ouvre un document.
	 * 
	 * @param zipFile
	 *            Le fichier Zip du document OpenXML.
	 * @param access
	 *            Le mode d'acc�s au document.
	 */
	public static OpenXMLDocument open(ZipFile zipFile, PackageAccess access) {
		return new OpenXMLDocument(Package.open(zipFile, access));
	}

	/**
	 * Sauvegarder l'int�gralit� du document dans le fichier de destination.
	 */
	public void save(File destFile) {
		container.save(destFile);
	}

	public CoreProperties getCoreProperties() {
		return corePropertiesHelper.getCoreProperties();
	}

	final class CorePropertiesHelper implements PartMarshaller {

		private final static String NAMESPACE_DC_URI = "http://purl.org/dc/elements/1.1/";

		private final static String NAMESPACE_CP_URI = "http://schemas.openxmlformats.org/package/2006/metadata/core-properties";

		private final static String NAMESPACE_DCTERMS_URI = "http://purl.org/dc/terms/";

		/**
		 * R�f�rence vers le package.
		 */
		private Package container;

		/**
		 * L'entr�e Zip du fichier de propri�t�s du doccuments.
		 */
		private ZipEntry corePropertiesZipEntry;

		/**
		 * Le bean des propri�t�s du document.
		 */
		private CoreProperties coreProperties;

		/**
		 * L'arbre DOM des propri�t�s du document (sert � l'enregistrement)
		 */
		private Document xmlDoc;

		public CorePropertiesHelper(Package container) {
			this.container = container;
			coreProperties = parseCorePropertiesFile();
		}

		/**
		 * Parse le fichier de propri�t�s du document.
		 * 
		 * @return
		 */
		private CoreProperties parseCorePropertiesFile() {
			CoreProperties coreProps = new CoreProperties();
			corePropertiesZipEntry = getCorePropertiesZipEntry();

			InputStream inStream = null;
			try {
				inStream = container.getArchive().getInputStream(
						corePropertiesZipEntry);
			} catch (IOException e) {
				throw new InvalidFormatException(
						"Impossible de lire le fichier de properi�t�s "
								+ corePropertiesZipEntry.getName());
			}

			// Cr�ation du parser DOM
			DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory
					.newInstance();
			documentBuilderFactory.setNamespaceAware(true);
			documentBuilderFactory.setIgnoringElementContentWhitespace(true);
			DocumentBuilder documentBuilder;
			try {
				documentBuilder = documentBuilderFactory.newDocumentBuilder();

				// On parse le document XML en arbre DOM
				xmlDoc = documentBuilder.parse(inStream);

				// Cr�ateur
				NodeList creators = xmlDoc.getElementsByTagNameNS(
						NAMESPACE_DC_URI, "creator");
				if (creators != null && creators.item(0) != null)
					coreProps.setCreator(creators.item(0).getTextContent());

				// Titre
				NodeList titles = xmlDoc.getElementsByTagNameNS(
						NAMESPACE_DC_URI, "title");
				if (titles != null && titles.item(0) != null)
					coreProps.setTitle(titles.item(0).getTextContent());

				// Sujet
				NodeList subjects = xmlDoc.getElementsByTagNameNS(
						NAMESPACE_DC_URI, "subject");
				if (subjects != null && subjects.item(0) != null)
					coreProps.setSubject(subjects.item(0).getTextContent());

				// Mots cl�
				NodeList keywords = xmlDoc.getElementsByTagNameNS(
						NAMESPACE_CP_URI, "keywords");
				if (keywords != null & keywords.item(0) != null)
					coreProps.setKeywords(keywords.item(0).getTextContent());

				// Description
				NodeList descriptions = xmlDoc.getElementsByTagNameNS(
						NAMESPACE_DC_URI, "description");
				if (descriptions != null && descriptions.item(0) != null)
					coreProps.setDescription(descriptions.item(0)
							.getTextContent());

				// Dernier personne � avoir modifi� le document
				NodeList lastModicationPersons = xmlDoc.getElementsByTagNameNS(
						NAMESPACE_CP_URI, "lastModifiedBy");
				if (lastModicationPersons != null
						&& lastModicationPersons.item(0) != null)
					coreProps.setLastModifiedBy(lastModicationPersons.item(0)
							.getTextContent());

				// Revision
				NodeList revisions = xmlDoc.getElementsByTagNameNS(
						NAMESPACE_CP_URI, "revision");
				if (revisions != null && revisions.item(0) != null)
					coreProps.setRevision(revisions.item(0).getTextContent());

				// Date de cr�ation
				NodeList created = xmlDoc.getElementsByTagNameNS(
						NAMESPACE_DCTERMS_URI, "created");
				if (created != null && created.item(0) != null)
					coreProps.setCreated(created.item(0).getTextContent());

				// Date de modification
				NodeList modifies = xmlDoc.getElementsByTagNameNS(
						NAMESPACE_DCTERMS_URI, "modified");
				if (modifies != null && modifies.item(0) != null)
					coreProps.setModified(modifies.item(0).getTextContent());

			} catch (Exception e) {
				e.printStackTrace();
				return null;
			}
			return coreProps;
		}

		/**
		 * Sauvegarde le fichier de propri�t�s du document dans le flux
		 * sp�cifi�.
		 * 
		 * @param out
		 *            Flux de sortie.
		 */
		public void marshall(PackagePart part, OutputStream os) {
			if (!(os instanceof ZipOutputStream))
				throw new IllegalArgumentException(
						"Le flux doit �tre un ZipOutputSTream !");

			ZipOutputStream out = (ZipOutputStream) os;

			// Cr�ateur
			xmlDoc.getElementsByTagNameNS(NAMESPACE_DC_URI, "creator").item(0)
					.setTextContent(coreProperties.getCreator());
			// Titre
			xmlDoc.getElementsByTagNameNS(NAMESPACE_DC_URI, "title").item(0)
					.setTextContent(coreProperties.getTitle());
			// Sujet
			xmlDoc.getElementsByTagNameNS(NAMESPACE_DC_URI, "subject").item(0)
					.setTextContent(coreProperties.getSubject());
			// Mots cl�
			xmlDoc.getElementsByTagNameNS(NAMESPACE_CP_URI, "keywords").item(0)
					.setTextContent(coreProperties.getKeywords());
			// Description
			xmlDoc.getElementsByTagNameNS(NAMESPACE_DC_URI, "description")
					.item(0).setTextContent(coreProperties.getDescription());
			// Dernier personne � avoir modifi� le document
			xmlDoc.getElementsByTagNameNS(NAMESPACE_CP_URI, "lastModifiedBy")
					.item(0).setTextContent(coreProperties.getLastModifiedBy());
			// Revision
			xmlDoc.getElementsByTagNameNS(NAMESPACE_CP_URI, "revision").item(0)
					.setTextContent(coreProperties.getRevision());
			// Date de cr�ation
			xmlDoc.getElementsByTagNameNS(NAMESPACE_DCTERMS_URI, "created")
					.item(0).setTextContent(coreProperties.getCreated());
			// Date de modification
			xmlDoc.getElementsByTagNameNS(NAMESPACE_DCTERMS_URI, "modified")
					.item(0).setTextContent(coreProperties.getModified());
			xmlDoc.normalize();

			// Enregistrement de la partie dans le zip
			ZipEntry ctEntry = new ZipEntry(corePropertiesZipEntry.getName());
			try {
				// Cr�ation de l'entr�e dans le fichier ZIP
				out.putNextEntry(ctEntry);
				DOMSource source = new DOMSource(xmlDoc);
				StreamResult result = new StreamResult(out);
				TransformerFactory transFactory = TransformerFactory
						.newInstance();
				try {
					Transformer transformer = transFactory.newTransformer();
					transformer.setOutputProperty("indent", "yes");
					transformer.transform(source, result);
				} catch (TransformerException e) {
					System.err
							.println("Echec de l'enregistrement : impossible de cr�er le fichier "
									+ corePropertiesZipEntry.getName());
				}
				// Fermeture de l'entr�e du fichier ZIP
				out.closeEntry();
			} catch (IOException e1) {
				System.err.println("");
			}
		}

		/* Accesseurs */

		public Package getContainer() {
			return container;
		}

		public CoreProperties getCoreProperties() {
			return coreProperties;
		}

		/**
		 * R�cup�rer l'entr�e Zip du fichier de propri�t� du document.
		 */
		private ZipEntry getCorePropertiesZipEntry() {
			PackageRelationship corePropsRel = container
					.getRelationshipsByType(
							PackageRelationshipConstants.NS_CORE_PROPERTIES)
					.getRelationship(0);

			if (corePropsRel == null)
				return null;

			return new ZipEntry(corePropsRel.getTargetUri().getPath());
		}
	}
}