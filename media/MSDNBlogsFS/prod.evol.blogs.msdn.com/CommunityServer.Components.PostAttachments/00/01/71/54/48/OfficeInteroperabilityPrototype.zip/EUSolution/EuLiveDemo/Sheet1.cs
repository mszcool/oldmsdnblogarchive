﻿using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using Microsoft.VisualStudio.Tools.Applications.Runtime;
using Excel = Microsoft.Office.Interop.Excel;
using Office = Microsoft.Office.Core;
using System.Collections.Generic;

namespace EuLiveDemo
{
    public partial class Sheet1
    {
        [Cached]
        public List<ProjectProxy.ProjectEntity> MyProjects 
            = new List<ProjectProxy.ProjectEntity>();

        private void Sheet1_Startup(object sender, System.EventArgs e)
        {
            ProjectsTaskPane pane = new ProjectsTaskPane();
            Globals.ThisWorkbook.ActionsPane.Controls.Add(
                pane);

            projectsBindingSource.DataSource = MyProjects;
            projectsBindingSource.ResetBindings(true);
        }

        private void Sheet1_Shutdown(object sender, System.EventArgs e)
        {
        }

        #region VSTO Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InternalStartup()
        {
            this.Startup += new System.EventHandler(Sheet1_Startup);
            this.Shutdown += new System.EventHandler(Sheet1_Shutdown);
        }

        #endregion


        internal void InsertProject(EuLiveDemo.ProjectProxy.ProjectEntity projectEntity)
        {
            MyProjects.Add(projectEntity);
            projectsBindingSource.ResetBindings(false);
        }
    }
}
