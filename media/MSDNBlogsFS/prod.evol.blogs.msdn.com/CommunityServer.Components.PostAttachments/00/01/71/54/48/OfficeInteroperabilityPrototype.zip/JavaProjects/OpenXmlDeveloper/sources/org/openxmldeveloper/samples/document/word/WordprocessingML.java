package org.openxmldeveloper.samples.document.word;

public class WordprocessingML {

	public final static String NS_MARKUP_COMPATIBILY = "http://schemas.openxmlformats.org/markup-compatibility/2006";

	public final static String NS_OFFICE = "urn:schemas-microsoft-com:office:office";

	public final static String NS_OFFICE_12 = "http://schemas.microsoft.com/office/2004/7/core";

	public final static String NS_RELATIONSHIPS = "http://schemas.openxmlformats.org/officeDocument/2006/relationships";

	public final static String NS_OMML = "http://schemas.microsoft.com/office/omml/2004/12/core";

	public final static String NS_VML = "urn:schemas-microsoft-com:vml";

	public final static String NS_DRAWINGML = "http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing";

	public final static String NS_WORD10 = "urn:schemas-microsoft-com:office:word";

	public final static String NS_WORD12 = "http://schemas.openxmlformats.org/wordprocessingml/2006/main";
}