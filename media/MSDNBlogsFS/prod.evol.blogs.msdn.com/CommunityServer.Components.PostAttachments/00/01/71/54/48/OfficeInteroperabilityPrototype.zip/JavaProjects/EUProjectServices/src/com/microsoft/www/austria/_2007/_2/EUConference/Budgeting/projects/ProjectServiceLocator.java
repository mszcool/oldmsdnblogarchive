/**
 * ProjectServiceLocator.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.3 Oct 05, 2005 (05:23:37 EDT) WSDL2Java emitter.
 */

package com.microsoft.www.austria._2007._2.EUConference.Budgeting.projects;

public class ProjectServiceLocator extends org.apache.axis.client.Service implements com.microsoft.www.austria._2007._2.EUConference.Budgeting.projects.ProjectService {

    public ProjectServiceLocator() {
    }


    public ProjectServiceLocator(org.apache.axis.EngineConfiguration config) {
        super(config);
    }

    public ProjectServiceLocator(java.lang.String wsdlLoc, javax.xml.namespace.QName sName) throws javax.xml.rpc.ServiceException {
        super(wsdlLoc, sName);
    }

    // Use to get a proxy class for ProjectServiceSoap
    private java.lang.String ProjectServiceSoap_address = "http://localhost:1076/EUServices/ProjectService.asmx";

    public java.lang.String getProjectServiceSoapAddress() {
        return ProjectServiceSoap_address;
    }

    // The WSDD service name defaults to the port name.
    private java.lang.String ProjectServiceSoapWSDDServiceName = "ProjectServiceSoap";

    public java.lang.String getProjectServiceSoapWSDDServiceName() {
        return ProjectServiceSoapWSDDServiceName;
    }

    public void setProjectServiceSoapWSDDServiceName(java.lang.String name) {
        ProjectServiceSoapWSDDServiceName = name;
    }

    public com.microsoft.www.austria._2007._2.EUConference.Budgeting.projects.ProjectServiceSoap getProjectServiceSoap() throws javax.xml.rpc.ServiceException {
       java.net.URL endpoint;
        try {
            endpoint = new java.net.URL(ProjectServiceSoap_address);
        }
        catch (java.net.MalformedURLException e) {
            throw new javax.xml.rpc.ServiceException(e);
        }
        return getProjectServiceSoap(endpoint);
    }

    public com.microsoft.www.austria._2007._2.EUConference.Budgeting.projects.ProjectServiceSoap getProjectServiceSoap(java.net.URL portAddress) throws javax.xml.rpc.ServiceException {
        try {
            com.microsoft.www.austria._2007._2.EUConference.Budgeting.projects.ProjectServiceSoapStub _stub = new com.microsoft.www.austria._2007._2.EUConference.Budgeting.projects.ProjectServiceSoapStub(portAddress, this);
            _stub.setPortName(getProjectServiceSoapWSDDServiceName());
            return _stub;
        }
        catch (org.apache.axis.AxisFault e) {
            return null;
        }
    }

    public void setProjectServiceSoapEndpointAddress(java.lang.String address) {
        ProjectServiceSoap_address = address;
    }

    /**
     * For the given interface, get the stub implementation.
     * If this service has no port for the given interface,
     * then ServiceException is thrown.
     */
    public java.rmi.Remote getPort(Class serviceEndpointInterface) throws javax.xml.rpc.ServiceException {
        try {
            if (com.microsoft.www.austria._2007._2.EUConference.Budgeting.projects.ProjectServiceSoap.class.isAssignableFrom(serviceEndpointInterface)) {
                com.microsoft.www.austria._2007._2.EUConference.Budgeting.projects.ProjectServiceSoapStub _stub = new com.microsoft.www.austria._2007._2.EUConference.Budgeting.projects.ProjectServiceSoapStub(new java.net.URL(ProjectServiceSoap_address), this);
                _stub.setPortName(getProjectServiceSoapWSDDServiceName());
                return _stub;
            }
        }
        catch (java.lang.Throwable t) {
            throw new javax.xml.rpc.ServiceException(t);
        }
        throw new javax.xml.rpc.ServiceException("There is no stub implementation for the interface:  " + (serviceEndpointInterface == null ? "null" : serviceEndpointInterface.getName()));
    }

    /**
     * For the given interface, get the stub implementation.
     * If this service has no port for the given interface,
     * then ServiceException is thrown.
     */
    public java.rmi.Remote getPort(javax.xml.namespace.QName portName, Class serviceEndpointInterface) throws javax.xml.rpc.ServiceException {
        if (portName == null) {
            return getPort(serviceEndpointInterface);
        }
        java.lang.String inputPortName = portName.getLocalPart();
        if ("ProjectServiceSoap".equals(inputPortName)) {
            return getProjectServiceSoap();
        }
        else  {
            java.rmi.Remote _stub = getPort(serviceEndpointInterface);
            ((org.apache.axis.client.Stub) _stub).setPortName(portName);
            return _stub;
        }
    }

    public javax.xml.namespace.QName getServiceName() {
        return new javax.xml.namespace.QName("http://www.microsoft.com/austria/2007/2/EUConference/Budgeting/projects", "ProjectService");
    }

    private java.util.HashSet ports = null;

    public java.util.Iterator getPorts() {
        if (ports == null) {
            ports = new java.util.HashSet();
            ports.add(new javax.xml.namespace.QName("http://www.microsoft.com/austria/2007/2/EUConference/Budgeting/projects", "ProjectServiceSoap"));
        }
        return ports.iterator();
    }

    /**
    * Set the endpoint address for the specified port name.
    */
    public void setEndpointAddress(java.lang.String portName, java.lang.String address) throws javax.xml.rpc.ServiceException {
        
if ("ProjectServiceSoap".equals(portName)) {
            setProjectServiceSoapEndpointAddress(address);
        }
        else 
{ // Unknown Port Name
            throw new javax.xml.rpc.ServiceException(" Cannot set Endpoint Address for Unknown Port" + portName);
        }
    }

    /**
    * Set the endpoint address for the specified port name.
    */
    public void setEndpointAddress(javax.xml.namespace.QName portName, java.lang.String address) throws javax.xml.rpc.ServiceException {
        setEndpointAddress(portName.getLocalPart(), address);
    }

}
