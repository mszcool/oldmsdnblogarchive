using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Xml.Serialization;

using EUServices.NamespaceNames;
using System.Collections.Generic;

/// <summary>
/// Summary description for DepartmentEntity
/// </summary>
namespace Department.Entities
{
    [XmlType(Namespace=Constants.DepartmentServiceEntityNamespace)]
    public class DepartmentEntity
    {
        public DepartmentEntity() 
        {
            Manager = new GeneralEntities.Employee();
        }

        public DepartmentEntity(string id, string name, string descr, GeneralEntities.Employee manager)
        {
            DepartmentID = id;
            Name = name;
            Description = descr;
            Manager = manager;
        }

        private string _DepartmentID;
        public string DepartmentID
        {
            get { return _DepartmentID; }
            set { _DepartmentID = value; }
        }

        private string _Name;
        public string Name
        {
            get { return _Name; }
            set { _Name = value; }
        }

        private string _Description;
        public string Description
        {
            get { return _Description; }
            set { _Description = value; }
        }

        private GeneralEntities.Employee _Manager;
        public GeneralEntities.Employee Manager
        {
            get { return _Manager; }
            set { _Manager = value; }
        }
    }

    [XmlType(Namespace=Constants.DepartmentServiceEntityNamespace)]
    public class DepartmentEntities : List<DepartmentEntity>
    {
    }
}