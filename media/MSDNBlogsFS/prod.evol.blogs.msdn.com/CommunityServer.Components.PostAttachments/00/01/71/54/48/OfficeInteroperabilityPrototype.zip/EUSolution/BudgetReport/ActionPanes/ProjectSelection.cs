#region Using directives

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;
using BudgetReport.ProjectProxy;

#endregion

namespace BudgetReport.ActionPanes
{
    partial class ProjectSelection : UserControl
    {
        public event EventHandler ProjectSelected;
        public event EventHandler InsertLineItemSelected;

        public ProjectSelection()
        {
            InitializeComponent();
        }

        public ProjectEntity CurrentProject
        {
            get 
            {
                if (projectsBindingSource.Position >= 0)
                    return projectsBindingSource.Current as ProjectEntity;
                else
                    return null;
            }
        }

        public string CurrentCategory
        {
            get
            {
                if (CategoryCombo.SelectedIndex >= 0)
                    return CategoryCombo.Text;
                else
                    return null;
            }
        }

        public decimal CurrentValue
        {
            get
            {
                return decimal.Parse(SpendingAmountText.Text);
            }
        }

        public void InitializePanel(ProjectEntity[] projects, CategoryEntity[] categories)
        {
            projectsBindingSource.DataSource = projects;
            categoriesBindingSource.DataSource = categories;
        }

        private void InsertProjectCommand_Click(object sender, EventArgs e)
        {
            if (ProjectSelected != null)
            {
                ProjectSelected(this, new EventArgs());
            }
        }

        private void InsertSpendingCommand_Click(object sender, EventArgs e)
        {
            decimal test;
            if (!decimal.TryParse(SpendingAmountText.Text, out test))
            {
                MessageBox.Show("Invalid value specified for amount!");
                return;
            }

            if (InsertLineItemSelected != null)
            {
                InsertLineItemSelected(this, new EventArgs());
            }
        }
    }
}
