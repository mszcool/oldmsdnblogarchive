using System;
using System.Web;
using System.Collections;
using System.Web.Services;
using System.Web.Services.Protocols;

using Budget;
using Budget.Entities;
using Budget.Contract;
using EUServices.NamespaceNames;

/// <summary>
/// Summary description for BudgetReports
/// </summary>
[WebService(Namespace = Constants.BudgetServiceNamespace)]
[WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
public class BudgetReports : System.Web.Services.WebService, IBudgetService {

    private BudgetServiceImplementation Implementation;

    public BudgetReports () {

        //Uncomment the following line if using designed components 
        //InitializeComponent(); 

        Implementation = new BudgetServiceImplementation();
    }

    #region IBudgetService Members

    [WebMethod]
    public BudgetReportResponseMessage GetReports(BudgetReportRequestMessage request)
    {
        return Implementation.GetReports(request);
    }

    #endregion
}

