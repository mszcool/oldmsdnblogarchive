package org.openxmldeveloper.samples.document.word;

/**
 * Le type d'alignement.
 * 
 * @author Julien Chable
 */
public enum ParagraphAlignment {
	LEFT, CENTER, RIGHT, DISTRIBUTE, HIGH_KASHIDA, MEDIUM_KASHIDA, LOW_KASHIDA, NUM_TAB, THAI_DISTRIBUTE;

	@Override
	public String toString() {
		return name().toLowerCase();
	}
}