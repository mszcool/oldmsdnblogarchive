package org.openxmldeveloper.samples.demo;

import java.io.File;
import java.io.IOException;
import java.util.zip.ZipFile;

import org.openxmldeveloper.samples.opc.Package;
import org.openxmldeveloper.samples.opc.PackageAccess;
import org.openxmldeveloper.samples.opc.PackagePart;
import org.openxmldeveloper.samples.opc.PackageRelationship;
import org.openxmldeveloper.samples.opc.PackageRelationshipConstants;

/**
 * Retrieve the core properties part of a document.
 * 
 * @author Julien Chable
 */
public class DemoListing2 {

	public static void main(String[] args) {
		final String APP_ROOT = System.getProperty("user.dir") + File.separator;
		ZipFile zipFile = null;
		try {
			zipFile = new ZipFile(APP_ROOT + "sample.docx");
		} catch (IOException e) {
			e.printStackTrace();
		}

		// Open the package
		Package p = Package.open(zipFile, PackageAccess.Read);

		// Get document�s core properties part relationship
		PackageRelationship corePropertiesRelationship = p
				.getRelationshipsByType(
						PackageRelationshipConstants.NS_CORE_PROPERTIES)
				.getRelationship(0);

		// Get core properties part from the previous relationship
		PackagePart coreDocument = p.getPart(corePropertiesRelationship);
		System.out.println(coreDocument.getUri() + " -> "
				+ coreDocument.getContentType());

	}
}