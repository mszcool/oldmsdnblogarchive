package org.openxmldeveloper.samples.opc;

public enum TargetMode {
	INTERNAL, EXTERNAL
}