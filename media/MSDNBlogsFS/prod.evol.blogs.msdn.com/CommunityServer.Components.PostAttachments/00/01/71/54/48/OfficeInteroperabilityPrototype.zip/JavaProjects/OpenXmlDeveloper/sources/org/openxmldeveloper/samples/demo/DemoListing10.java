package org.openxmldeveloper.samples.demo;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.zip.ZipFile;

import org.openxmldeveloper.samples.document.word.WordDocument;
import org.openxmldeveloper.samples.document.word.WordToHTMLTransformer;
import org.openxmldeveloper.samples.opc.Package;
import org.openxmldeveloper.samples.opc.PackageAccess;


/**
 * Convert Word document to HTML .
 * 
 * @author Julien Chable
 */
public class DemoListing10 {

	public static void main(String[] args) {
		final String APP_ROOT = System.getProperty("user.dir") + File.separator;
		ZipFile zipFile = null;
		try {
			zipFile = new ZipFile(APP_ROOT + "sample_out.docx");
		} catch (IOException e) {
			e.printStackTrace();
		}

		// Destination file
		File destFile = new File(APP_ROOT + "output.html");

		Package pack = Package.open(zipFile, PackageAccess.ReadWrite);
		WordDocument docx = new WordDocument(pack);

		WordToHTMLTransformer wt = new WordToHTMLTransformer();
		try {
			InputStream transformStream = wt.transform(docx);
			BufferedWriter outStream = new BufferedWriter(
					new OutputStreamWriter(new FileOutputStream(destFile)));

			BufferedReader br = new BufferedReader(new InputStreamReader(
					transformStream));
			String buff;
			while ((buff = br.readLine()) != null)
				outStream.write(buff);
			outStream.close();
			br.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}