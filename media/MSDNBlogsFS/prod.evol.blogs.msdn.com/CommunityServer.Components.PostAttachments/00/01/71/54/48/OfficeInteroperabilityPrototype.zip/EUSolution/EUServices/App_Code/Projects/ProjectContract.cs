using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Xml.Serialization;

using Project.Entities;
using EUServices.NamespaceNames;

namespace Project.Contract
{
    [XmlType(Namespace = Constants.ProjectServiceNamespace)]
    public class ProjectsRequestMessage
    {
        private string _DepartmentID;

        public string DepartmentID
        {
            get { return _DepartmentID; }
            set { _DepartmentID = value; }
        }
    }

    [XmlType(Namespace=Constants.ProjectServiceNamespace)]
    public class ProjectsResponseMessage
    {
        private ProjectEntities _Projects;

        public ProjectEntities Projects
        {
            get { return _Projects; }
            set { _Projects = value; }
        }

        public ProjectsResponseMessage()
        {
            _Projects = new ProjectEntities();
        }
    }

    [XmlType(Namespace=Constants.ProjectServiceNamespace)]
    public class CategoriesResponseMessage
    {
        private CategoryEntities _Categories;

        public CategoryEntities Categories
        {
            get { return _Categories; }
            set { _Categories = value; }
        }

        public CategoriesResponseMessage()
        {
            _Categories = new CategoryEntities();
        }
    }

    [XmlType(Namespace = Constants.ProjectServiceNamespace)]
    public interface IProjectService
    {
        CategoriesResponseMessage GetCategories();
        ProjectsResponseMessage GetProjects(ProjectsRequestMessage request);
    }
}