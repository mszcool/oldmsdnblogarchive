package org.openxmldeveloper.samples.demo;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.zip.ZipFile;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.openxmldeveloper.samples.opc.Package;
import org.openxmldeveloper.samples.opc.PackageAccess;
import org.openxmldeveloper.samples.opc.PackagePart;
import org.openxmldeveloper.samples.opc.PackageRelationship;
import org.openxmldeveloper.samples.opc.PackageRelationshipConstants;
import org.w3c.dom.Document;


/**
 * Read the extended properties of a document.
 * 
 * @author Julien Chable
 */
public class DemoListing5 {

	public static void main(String[] args) {
		final String APP_ROOT = System.getProperty("user.dir") + File.separator;
		ZipFile zipFile = null;
		try {
			zipFile = new ZipFile(APP_ROOT + "sample.docx");
		} catch (IOException e) {
			e.printStackTrace();
		}

		// Ouverture du package
		Package p = Package.open(zipFile, PackageAccess.Read);

		// Obtention de la relation de la partie � partir de son type
		PackageRelationship extendedPropertiesRelationship = p
				.getRelationshipsByType(
						PackageRelationshipConstants.NS_EXTENDED_PROPERTIES)
				.getRelationship(0);

		// Obtention de la partie � partir de cette
		// relation
		PackagePart extPropsPart = p.getPart(extendedPropertiesRelationship);
		System.out.println(extPropsPart.getUri() + " -> "
				+ extPropsPart.getContentType());

		// Extraction du contenu
		try {
			InputStream inStream = extPropsPart.getInputStream();

			// Cr�ation du parser DOM
			DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory
					.newInstance();
			documentBuilderFactory.setNamespaceAware(true);
			documentBuilderFactory.setIgnoringElementContentWhitespace(true);
			DocumentBuilder documentBuilder;

			documentBuilder = documentBuilderFactory.newDocumentBuilder();

			// On parse le document XML en arbre DOM
			Document extPropsDoc = documentBuilder.parse(inStream);

			// Extraction du nom et de la version de l'application qui a g�n�r�
			// ce fichier OpenXML
			System.out.println("Document generated with "
					+ extPropsDoc.getElementsByTagName("Application").item(0)
							.getTextContent()
					+ " vers. "
					+ extPropsDoc.getElementsByTagName("AppVersion").item(0)
							.getTextContent());

			// Extraction des statistiques du document
			System.out.println("This document contains "
					+ extPropsDoc.getElementsByTagName("Words").item(0)
							.getTextContent()
					+ " words and is composed of "
					+ extPropsDoc.getElementsByTagName("Characters").item(0)
							.getTextContent()
					+ " characters and  "
					+ extPropsDoc.getElementsByTagName("Lines").item(0)
							.getTextContent() + " lines");

			inStream.close();
		} catch (Exception ioe) {
			System.err
					.println("Failed to extract extended properties ! :(");
		}
	}

}
