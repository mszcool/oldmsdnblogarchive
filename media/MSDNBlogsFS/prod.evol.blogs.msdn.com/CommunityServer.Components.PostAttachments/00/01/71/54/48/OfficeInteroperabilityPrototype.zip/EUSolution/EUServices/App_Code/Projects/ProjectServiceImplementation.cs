using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

using Project.Entities;
using Project.Contract;
using Microsoft.SharePoint;

namespace Project
{
    public class ProjectServiceImplementation : IProjectService
    {
        #region IProjectService Members

        public CategoriesResponseMessage GetCategories()
        {
            CategoriesResponseMessage response = new CategoriesResponseMessage();

            // Connect to the SharePoint site
            SPSite site = new SPSite(ConfigurationManager.AppSettings["SPSite"]);
            SPWeb web = site.OpenWeb();
            SPList categoriesList = web.GetList(ConfigurationManager.AppSettings["CategoryList"]);

            // Run through the library's entries and get data from the document
            foreach (SPListItem category in categoriesList.Items)
            {
                CategoryEntity c = new CategoryEntity();
                c.CategoryID = category["Identity"].ToString();
                c.CategoryName = category["Title"].ToString();
                response.Categories.Add(c);
            }

            return response;
        }

        public ProjectsResponseMessage GetProjects(ProjectsRequestMessage request)
        {
            ProjectsResponseMessage response = new ProjectsResponseMessage();

            #region Dummy Implementation
            /*
            for (int i = 0; i < 10; i++)
            {
                ProjectEntity p = new ProjectEntity(
                    i,
                    string.Format("Project {0}", i),
                    string.Format("Project {0} is a really {0} project!", i),
                    DateTime.Now.Subtract(TimeSpan.FromDays((i + 1) * 10)),
                    DateTime.Now.AddDays((i + 1) * 10)
                );

                response.Projects.Add(p);
            }
            */
            #endregion

            // Connect to the SharePoint site
            SPSite site = new SPSite(ConfigurationManager.AppSettings["SPSite"]);
            SPWeb web = site.OpenWeb();
            SPList projectsList = web.GetList(ConfigurationManager.AppSettings["ProjectList"]);

            // Run through the library's entries and get data from the document
            foreach (SPListItem project in projectsList.Items)
            {
                ProjectEntity p = new ProjectEntity();
                p.ProjectID = int.Parse(project["Project NR"].ToString());
                p.ProjectName = project["Title"].ToString();
                p.Description = project["Description"].ToString();
                p.StartDate = DateTime.Parse(project["Start"].ToString());
                p.EndDate = DateTime.Parse(project["End"].ToString());
                response.Projects.Add(p);
            }

            return response;
        }

        #endregion
    }
}