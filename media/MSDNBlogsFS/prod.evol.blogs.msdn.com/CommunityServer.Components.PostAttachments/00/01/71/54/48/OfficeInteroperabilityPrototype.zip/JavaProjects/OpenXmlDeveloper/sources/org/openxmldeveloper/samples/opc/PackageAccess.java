package org.openxmldeveloper.samples.opc;

/**
 * Sp�cifie l'acc�s � un package
 * 
 * @author Julien Chable
 * @version 1.0
 */
public enum PackageAccess {
	Read, // Exclusively read (by default)
	Write, // Exclusively write
	ReadWrite // Read and write mode
}
