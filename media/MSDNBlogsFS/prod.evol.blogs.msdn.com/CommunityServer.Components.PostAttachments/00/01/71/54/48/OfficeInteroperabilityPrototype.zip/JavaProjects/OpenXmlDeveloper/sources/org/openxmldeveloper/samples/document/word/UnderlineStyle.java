package org.openxmldeveloper.samples.document.word;

/**
 * Le style de soulignement.
 * 
 * @author Julien Chable
 */
public enum UnderlineStyle {
	DASH, NONE, SINGLE, THICK, WAVE, WORDS;

	@Override
	public String toString() {
		return name().toLowerCase();
	}
}