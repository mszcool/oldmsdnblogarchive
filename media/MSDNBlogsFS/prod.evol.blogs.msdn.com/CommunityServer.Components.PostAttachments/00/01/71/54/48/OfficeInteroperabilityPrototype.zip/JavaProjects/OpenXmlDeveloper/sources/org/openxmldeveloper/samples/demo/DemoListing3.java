package org.openxmldeveloper.samples.demo;

import java.io.File;
import java.io.IOException;
import java.util.zip.ZipFile;

import org.openxmldeveloper.samples.document.OpenXMLDocument;
import org.openxmldeveloper.samples.opc.Package;
import org.openxmldeveloper.samples.opc.PackageAccess;

/**
 * Affichage des propri�t�s du document.
 * 
 * @author Julien Chable
 */
public class DemoListing3 {

	public static void main(String[] args) {
		final String APP_ROOT = System.getProperty("user.dir") + File.separator;
		ZipFile zipFile = null;
		try {
			zipFile = new ZipFile(APP_ROOT + "sample.docx");
		} catch (IOException e) {
			e.printStackTrace();
		}

		OpenXMLDocument docx = new OpenXMLDocument(Package.open(zipFile,
				PackageAccess.Read));
		System.out.println(docx.getCoreProperties().getCreator());
		System.out.println(docx.getCoreProperties().getTitle());
		System.out.println(docx.getCoreProperties().getSubject());
	}
}