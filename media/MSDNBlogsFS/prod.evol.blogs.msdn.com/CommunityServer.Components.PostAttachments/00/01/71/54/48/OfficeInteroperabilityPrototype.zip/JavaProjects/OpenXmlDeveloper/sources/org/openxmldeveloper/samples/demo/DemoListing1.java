package org.openxmldeveloper.samples.demo;

import java.io.File;
import java.io.IOException;
import java.util.zip.ZipFile;

import org.openxmldeveloper.samples.opc.Package;
import org.openxmldeveloper.samples.opc.PackageAccess;
import org.openxmldeveloper.samples.opc.PackagePart;
import org.openxmldeveloper.samples.opc.PackageRelationship;
import org.openxmldeveloper.samples.opc.PackageRelationshipConstants;


/**
 * Retrieve the main part of a document.
 * 
 * @author Julien Chable
 */
public class DemoListing1 {

	public static void main(String[] args) {
		String APP_ROOT = System.getProperty("user.dir") + File.separator;
		ZipFile zipFile = null;
		try {
			zipFile = new ZipFile(APP_ROOT + "sample.docx");
		} catch (IOException e) {
			e.printStackTrace();
		}

		// Open the package
		Package p = Package.open(zipFile, PackageAccess.Read);

		// Retrieve main part relationship from his type
		PackageRelationship coreDocRelationship = p.getRelationshipsByType(
				PackageRelationshipConstants.NS_CORE_DOCUMENT).getRelationship(0);

		// Get the document�s content part from the relationship
		PackagePart corePart = p.getPart(coreDocRelationship);
		System.out.println(corePart.getUri() + " -> "
				+ corePart.getContentType());
	}

}