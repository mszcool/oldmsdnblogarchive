package org.openxmldeveloper.samples.document.word;

public class ParagraphBuilder {

	protected ParagraphAlignment alignment;

	protected boolean bold;

	protected boolean italic;

	protected boolean underline;

	public ParagraphAlignment getAlignment() {
		return alignment;
	}

	public void setAlignment(ParagraphAlignment alignment) {
		this.alignment = alignment;
	}

	public boolean isBold() {
		return bold;
	}

	public void setBold(boolean bold) {
		this.bold = bold;
	}

	public boolean isItalic() {
		return italic;
	}

	public void setItalic(boolean italic) {
		this.italic = italic;
	}

	public boolean isUnderline() {
		return underline;
	}

	public void setUnderline(boolean underline) {
		this.underline = underline;
	}

	/**
	 * Cr�ation d'un paragraphe poss�dant les caract�ristiques de la
	 * configuration de ce ParagrphBuilder.
	 */
	public Paragraph newParagraph() {
		Paragraph retPar = new Paragraph();
		retPar.setAlignment(alignment);
		return retPar;
	}
}