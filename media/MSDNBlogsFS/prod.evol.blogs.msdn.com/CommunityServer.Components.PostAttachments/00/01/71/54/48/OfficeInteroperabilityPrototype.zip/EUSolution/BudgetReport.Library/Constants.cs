using System;
using System.Data;
using System.Configuration;
using System.Web;

/// <summary>
/// Summary description for Constants
/// </summary>
namespace EUServices.NamespaceNames
{
    public sealed class Constants
    {
        public const string BaseNamespace = "http://www.microsoft.com/austria/2007/2/EUConference/Budgeting";
        public const string EntitiesNamespace = BaseNamespace + "/entities";

        public const string DepartmentServiceNamespace = BaseNamespace + "/departments";
        public const string DepartmentServiceEntityNamespace = DepartmentServiceNamespace + "/entities";

        public const string ProjectServiceNamespace = BaseNamespace + "/projects";
        public const string ProjectServiceEntityNamespace = ProjectServiceNamespace + "/entities";

        public const string BudgetServiceNamespace = BaseNamespace + "/budget";
        public const string BudgetServiceEntityNamespace = BudgetServiceNamespace + "/entities";
    }
}