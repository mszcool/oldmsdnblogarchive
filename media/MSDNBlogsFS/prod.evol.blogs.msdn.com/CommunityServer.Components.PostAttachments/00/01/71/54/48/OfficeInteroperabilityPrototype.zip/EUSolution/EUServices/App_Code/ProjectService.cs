using System;
using System.Web;
using System.Collections;
using System.Web.Services;
using System.Web.Services.Protocols;
using EUServices.NamespaceNames;

using Project;
using Project.Entities;
using Project.Contract;

/// <summary>
/// Summary description for ProjectService
/// </summary>
[WebService(Namespace = Constants.ProjectServiceNamespace)]
[WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
public class ProjectService : System.Web.Services.WebService, IProjectService {

    private IProjectService Implementation;

    public ProjectService () {

        //Uncomment the following line if using designed components 
        //InitializeComponent(); 

        Implementation = new ProjectServiceImplementation();
    }

    #region IProjectService Members

    [WebMethod]
    public CategoriesResponseMessage GetCategories()
    {
        return Implementation.GetCategories();
    }

    [WebMethod]
    public ProjectsResponseMessage GetProjects(ProjectsRequestMessage request)
    {
        return Implementation.GetProjects(request);
    }

    #endregion
}

