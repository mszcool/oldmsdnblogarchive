/**
 * ProjectServiceSoapImpl.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.3 Oct 05, 2005 (05:23:37 EDT) WSDL2Java emitter.
 */

package com.microsoft.www.austria._2007._2.EUConference.Budgeting.projects;

import java.util.Calendar;
import java.util.Random;

import com.microsoft.www.austria._2007._2.EUConference.Budgeting.projects.entities.CategoryEntity;
import com.microsoft.www.austria._2007._2.EUConference.Budgeting.projects.entities.ProjectEntity;

public class ProjectServiceSoapImpl implements com.microsoft.www.austria._2007._2.EUConference.Budgeting.projects.ProjectServiceSoap{
    public com.microsoft.www.austria._2007._2.EUConference.Budgeting.projects.CategoriesResponseMessage getCategories() throws java.rmi.RemoteException {
        CategoriesResponseMessage response = new CategoriesResponseMessage();
        CategoryEntity entities[] = new CategoryEntity[6];
        for(int i=0; i < entities.length; i++)
        {
        	CategoryEntity e = new CategoryEntity();
        	e.setCategoryID(Integer.toString(i+1));
        	e.setCategoryName("Java Category " + Integer.toString(i));
        	entities[i] = e;
        }
        response.setCategories(entities);
        return response;
    }

    public com.microsoft.www.austria._2007._2.EUConference.Budgeting.projects.ProjectsResponseMessage getProjects(com.microsoft.www.austria._2007._2.EUConference.Budgeting.projects.ProjectsRequestMessage request) throws java.rmi.RemoteException {
        ProjectsResponseMessage response = new ProjectsResponseMessage();
        
        Random rnd = new Random();
        int projectCount = rnd.nextInt(20) + 1;
        ProjectEntity projects[] = new ProjectEntity[projectCount];
        for(int i=0; i < projects.length; i++)
        {
        	Calendar start = Calendar.getInstance();
        	start.set(2007, 2, 15);
        	
        	Calendar end = Calendar.getInstance();
        	end.set(2007, 4, 20);
        	
        	ProjectEntity e = new ProjectEntity();
        	e.setProjectID(i);
        	e.setProjectName("Java Project " + Integer.toString(i));
        	e.setDescription("Retrieved " + Integer.toString(i) + " from Java Service!");
        	e.setStartDate(start);
        	e.setEndDate(end);
        	
        	projects[i] = e;
        }
        
        response.setProjects(projects);
        return response;
    }

}
