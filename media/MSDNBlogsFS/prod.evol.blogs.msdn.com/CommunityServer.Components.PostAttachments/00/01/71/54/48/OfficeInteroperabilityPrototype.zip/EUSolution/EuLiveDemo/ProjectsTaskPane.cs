using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;

namespace EuLiveDemo
{
    public partial class ProjectsTaskPane : UserControl
    {
        public ProjectsTaskPane()
        {
            InitializeComponent();

            // Call the web service to retrieve projects
            ProjectProxy.ProjectService service = new EuLiveDemo.ProjectProxy.ProjectService();
            service.Credentials = System.Net.CredentialCache.DefaultCredentials;

            ProjectProxy.ProjectsResponseMessage response =
                service.GetProjects(null);

            projectsBindingSource.DataSource = response.Projects;
            projectsBindingSource.ResetBindings(true);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (projectsBindingSource.Position >= 0)
            {
                Globals.Sheet1.InsertProject(
                    projectsBindingSource.Current as ProjectProxy.ProjectEntity
                );
            }
        }
    }
}
