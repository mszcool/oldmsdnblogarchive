﻿using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using Microsoft.VisualStudio.Tools.Applications.Runtime;
using Excel = Microsoft.Office.Interop.Excel;
using Office = Microsoft.Office.Core;
using BudgetReport.ActionPanes;
using Budget.Entities;
using BudgetReport.DepartmentProxy;
using BudgetReport.ProjectProxy;

namespace BudgetReport
{
    public partial class Sheet1
    {
        [Cached]
        public BudgetReportEntity ReportData;

        private ProjectSelection ProjectPanel;
        private DepartmentSelection DepartmentPanel;

        private ProjectProxy.ProjectService ProjectProxyInstance;
        private DepartmentProxy.DepartmentService DepartmentProxyInstance;

        private void Sheet1_Startup(object sender, System.EventArgs e)
        {
            // Create web service proxies and actions pane
            CreateActionsPane();

            // Now initialize the budget data
            if (NeedsFill("ReportData"))
            {
                ReportData = new BudgetReportEntity();
                ReportData.ReportDate = DateTime.Now;
                ReportData.ReportId = Guid.NewGuid().ToString();
            }

            // Bind to the binding source
            budgetReportEntityBindingSource.SuspendBinding();
            budgetReportEntityBindingSource.DataSource = ReportData;
            budgetReportEntityBindingSource.ResumeBinding();

            itemsBindingSource.SuspendBinding();
            itemsBindingSource.DataSource = ReportData.Items;
            itemsBindingSource.ResumeBinding();
        }

        private void Sheet1_Shutdown(object sender, System.EventArgs e)
        {
        }

        #region VSTO Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InternalStartup()
        {
            this.BudgetGeneral.Selected += new Microsoft.Office.Interop.Excel.DocEvents_SelectionChangeEventHandler(this.BudgetGeneral_Selected);
            this.BudgetGeneral.Deselected += new Microsoft.Office.Interop.Excel.DocEvents_SelectionChangeEventHandler(this.BudgetGeneral_Deselected);
            this.ProjectGeneral.Selected += new Microsoft.Office.Interop.Excel.DocEvents_SelectionChangeEventHandler(this.ProjectGeneral_Selected);
            this.ProjectGeneral.Deselected += new Microsoft.Office.Interop.Excel.DocEvents_SelectionChangeEventHandler(this.ProjectGeneral_Deselected);
            this.Shutdown += new System.EventHandler(this.Sheet1_Shutdown);
            this.Startup += new System.EventHandler(this.Sheet1_Startup);

        }

        #endregion

        private void CreateActionsPane()
        {
            // Create web service proxies
            ProjectProxyInstance = new BudgetReport.ProjectProxy.ProjectService();
            ProjectProxyInstance.Credentials = System.Net.CredentialCache.DefaultCredentials;
            DepartmentProxyInstance = new BudgetReport.DepartmentProxy.DepartmentService();
            DepartmentProxyInstance.Credentials = System.Net.CredentialCache.DefaultCredentials;

            // Get reference data and initialize task panes
            InitializeProjectData();
            InitializeDepartmentData();
        }

        private void InitializeDepartmentData()
        {
            // Now create the panel, get data from web service
            DepartmentPanel = new DepartmentSelection();
            DepartmentPanel.DepartmentSelected += new EventHandler(DepartmentPanel_DepartmentSelected);
            DepartmentPanel.InitializePanel
            (
                DepartmentProxyInstance.GetDepartments().Departments
            );

            Globals.ThisWorkbook.ActionsPane.Controls.Add(DepartmentPanel);
            DepartmentPanel.Hide();
        }

        void DepartmentPanel_DepartmentSelected(object sender, EventArgs e)
        {
            DepartmentEntity entity = DepartmentPanel.CurrentDepartment;

            // Copy the values to the budget report bound
            ReportData.Department.DepartmentID = entity.DepartmentID;
            ReportData.Department.Description = entity.Description;
            ReportData.Department.Name = entity.Name;
            ReportData.Department.Manager.EmployeeID = entity.Manager.EmployeeID;
            ReportData.Department.Manager.Firstname = entity.Manager.Firstname;
            ReportData.Department.Manager.Lastname = entity.Manager.Lastname;

            budgetReportEntityBindingSource.ResetBindings(false);
        }

        private void InitializeProjectData()
        {
            // Initialize request messages
            // TODO: Update project proxy call
            ProjectProxy.ProjectsRequestMessage request = new BudgetReport.ProjectProxy.ProjectsRequestMessage();
            request.DepartmentID = string.Empty;
            ProjectProxy.ProjectsResponseMessage ProjectResponse
                = ProjectProxyInstance.GetProjects(request);
            ProjectProxy.CategoriesResponseMessage CategoryResponse
                = ProjectProxyInstance.GetCategories();

            // Create the project panel and get data from web service
            ProjectPanel = new ProjectSelection();
            ProjectPanel.ProjectSelected += new EventHandler(ProjectPanel_ProjectSelected);
            ProjectPanel.InsertLineItemSelected += new EventHandler(ProjectPanel_InsertLineItemSelected);
            ProjectPanel.InitializePanel
            (
                ProjectResponse.Projects,
                CategoryResponse.Categories
            );

            Globals.ThisWorkbook.ActionsPane.Controls.Add(ProjectPanel);
            ProjectPanel.Hide();
        }

        void ProjectPanel_ProjectSelected(object sender, EventArgs e)
        {
            ProjectEntity p = ProjectPanel.CurrentProject;

            ReportData.Project.ProjectID = p.ProjectID;
            ReportData.Project.ProjectName = p.ProjectName;
            ReportData.Project.StartDate = p.StartDate;
            ReportData.Project.EndDate = p.EndDate;
            ReportData.Project.Description = p.Description;

            budgetReportEntityBindingSource.ResetBindings(false);
        }

        void ProjectPanel_InsertLineItemSelected(object sender, EventArgs e)
        {
            BudgetReportItemEntity item = new BudgetReportItemEntity();
            item.Amount = ProjectPanel.CurrentValue;
            item.Category = ProjectPanel.CurrentCategory;
            item.Description = "<enter here>";
            item.ItemDate = DateTime.Now;

            ReportData.Items.Add(item);

            itemsBindingSource.ResetBindings(false);
        }

        private void BudgetGeneral_Selected(Microsoft.Office.Interop.Excel.Range Target)
        {
            DepartmentPanel.Show();
        }

        private void ProjectGeneral_Selected(Microsoft.Office.Interop.Excel.Range Target)
        {
            ProjectPanel.Show();
        }

        private void BudgetGeneral_Deselected(Microsoft.Office.Interop.Excel.Range Target)
        {
            DepartmentPanel.Hide();
        }

        private void ProjectGeneral_Deselected(Microsoft.Office.Interop.Excel.Range Target)
        {
            ProjectPanel.Hide();
        }
    }
}
