package org.openxmldeveloper.samples.opc;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URI;

/**
 * 
 * @author Julien Chable
 * 
 */
public abstract class PackagePart {

	protected Package container;

	protected URI uri;

	protected String contentType;

	private boolean isRelationshipPart;

	private boolean isDeleted;

	private PackageRelationshipCollection relationships;

	/**
	 * Constructeur.
	 * 
	 * @param pack
	 *            Parent package.
	 * @param partURI
	 *            The part's Uniform Resource Identifier (URI), relative to the
	 *            parent Package root.
	 */
	public PackagePart(Package pack, URI partUri) {
		this.container = pack;
		this.uri = partUri;
		isRelationshipPart = PackageURIHelper.isRelationshipPartURI(partUri);
	}

	/**
	 * Constructor.
	 * 
	 * @param pack
	 *            Parent package.
	 * @param partURI
	 *            The part's Uniform Resource Identifier (URI), relative to the
	 *            parent Package root.
	 * @param contentType
	 *            The Multipurpose Internet Mail Extensions (MIME) content type
	 *            of the part's data stream.
	 */
	public PackagePart(Package pack, URI partURI, String contentType) {
		this(pack, partURI);
		this.contentType = contentType;
	}

	/**
	 * Ajout d'une relation � une partie (exclut les parties de type relation).
	 * 
	 * @param targetUri
	 *            URI de la partie cible, attention celle-ci doit �tre relative
	 *            par rapport au r�pertoire source de la partie.
	 * @param targetMode
	 *            Le mode [Internal|External].
	 * @param relationshipType
	 *            Le type de la relation.
	 * @return La relation qui a �t� ajout�e.
	 */
	public PackageRelationship addRelationship(URI targetUri,
			TargetMode targetMode, String relationshipType) {
		if (targetMode == null)
			targetMode = TargetMode.INTERNAL;

		// On v�rifie que la partie existe
		if (!container.partExists(targetUri))
			throw new InvalidOperationException(
					"La partie cible n'existe pas dans le paquet !");

		return addRelationship(targetUri, targetMode, relationshipType, null);
	}

	/**
	 * Ajout d'une relation � une partie (exclut les parties de type relation).
	 * 
	 * @param targetUri
	 *            URI de la partie cible.
	 * @param targetMode
	 *            Le mode [Internal|External].
	 * @param relationshipType
	 *            Le type de la relation.
	 * @param id
	 *            L'identifiant unique de la relation, si <i>null</i> alors un
	 *            identifiant est g�n�r� automatiquement.
	 * @return La relation qui a �t� ajout�e.
	 */
	public PackageRelationship addRelationship(URI targetUri,
			TargetMode targetMode, String relationshipType, String id) {
		container.throwExceptionIfReadOnly();

		// On n'ajoute pas de relations � une partie de relation directement,
		// mais � la partie source
		if (isRelationshipPart)
			throw new InvalidOperationException(
					"Cette op�ration ne peut �tre ex�cut�e sur une partie de type relation !");

		if (relationships == null)
			relationships = new PackageRelationshipCollection(this);

		return relationships.addRelationship(targetUri, targetMode,
				relationshipType, id);
	}

	/**
	 * Supprime toutes les relations de cette partie.
	 */
	public void clearRelationships() {
		relationships.clear();
	}

	/**
	 * R�cup�rer toutes relations de cette partie.
	 * 
	 * @return Toutes les relations de cette partie.
	 */
	public PackageRelationshipCollection getRelationships() {
		return getRelationshipsCore(null);
	}

	/**
	 * R�cup�rer toutes les relations dont le type correspond au filtre
	 * sp�cifi�.
	 * 
	 * @param relationshipType
	 *            Le filtre de type de relation.
	 * @return Toutes les relations correspondant au filtre de type.
	 */
	public PackageRelationshipCollection getRelationshipsByType(
			String relationshipType) {
		if (container.getPackageAccess() == PackageAccess.Write)
			throw new IllegalAccessException(
					"Acc�s ill�gal, doit autoriser la lecture !");

		return getRelationshipsCore(relationshipType);
	}

	/**
	 * Impl�mentation de la recherche des relations d'une partie.
	 * 
	 * @param filter
	 *            Le filtre sur le type de relation. SI <i>null</i> alors le
	 *            filtre est d�sactiv� et toutes les relations sont retourn�es.
	 * @return Toutes les relations dont le type est valid� par le filtre.
	 */
	private PackageRelationshipCollection getRelationshipsCore(String filter) {
		if (container.getPackageAccess() == PackageAccess.Write)
			throw new IllegalAccessException(
					"Acc�s ill�gal, doit autoriser la lecture !");

		if (relationships == null) {
			if (isRelationshipPart)
				throw new IllegalArgumentException(
						"Ne doit pas �tre une partie de relations !");
			relationships = new PackageRelationshipCollection(this);
		}
		return new PackageRelationshipCollection(relationships, filter);
	}

	/**
	 * Savoir si la partie poss�de des relations.
	 * 
	 * @return <b>true</b> si la partie poss�de des relations sinon <b>false</b>.
	 */
	public boolean hasRelationships() {
		if (!(relationships != null && relationships.size() > 0))
			return container.partExists(PackageURIHelper
					.getRelationshipPartUri(uri));
		return true;
	}

	/**
	 * Obtenir le flux de lecture de la partie.
	 */
	public InputStream getInputStream() throws IOException {
		InputStream inStream = this.getInputStreamImpl();
		if (inStream == null)
			throw new IOException(
					"Ne peut obtenir le flux d'entr�e de la partie " + uri);
		return inStream;
	}

	/**
	 * Obtenir le flux de sortie de la partie. Si la partie est contenue dans un
	 * ZIP, celle-ci est transform�e en partie de type <i>MemoryPackagePart</i>
	 * afin de pouvoir �crire dedans, l'API Java ne permettant pas d'�crire
	 * directement dans le fichier.
	 */
	public OutputStream getOutputStream() throws IOException {
		OutputStream outStream;
		// Si l'instance est une partie de Zip (lecture uniquement) nous la
		// transformons en partie de type MemorypackagePart.
		if (this instanceof ZipPackagePart) {
			container.removePart(this.uri);
			PackagePart part = container.addPart(this.uri, this.contentType);
			outStream = part.getOutputStreamImpl();
		} else
			outStream = this.getOutputStreamImpl();

		if (outStream == null)
			throw new IOException(
					"Ne peut obtenir le flux de sortie de la partie " + uri);
		return outStream;
	}

	/*
	 * Accessors
	 */

	public URI getUri() {
		return uri;
	}

	public void setUri(URI uri) {
		this.uri = uri;
	}

	public String getContentType() {
		return contentType;
	}

	public void setContentType(String contentType) {
		this.contentType = contentType;
	}

	public Package getParentPackage() {
		return container;
	}

	public boolean isRelationshipPart() {
		return isRelationshipPart;
	}

	public boolean isDeleted() {
		return isDeleted;
	}

	public void setDeleted(boolean isDeleted) {
		this.isDeleted = isDeleted;
	}

	/**
	 * Impl�mentation de la r�cup�ration du flux d'entr�e du contenu de la
	 * partie.
	 */
	protected abstract InputStream getInputStreamImpl();

	/**
	 * Impl�mentation de la r�cup�ration du flux de sortie du contenu de la
	 * aprtie.
	 */
	protected abstract OutputStream getOutputStreamImpl();

	/**
	 * Enregistrement de la partie et de la partie de relations si la partie
	 * poss�de au moins une relation.
	 * 
	 * @param zos
	 *            Flux d'enregistrement
	 */
	public abstract void save(OutputStream zos);
}