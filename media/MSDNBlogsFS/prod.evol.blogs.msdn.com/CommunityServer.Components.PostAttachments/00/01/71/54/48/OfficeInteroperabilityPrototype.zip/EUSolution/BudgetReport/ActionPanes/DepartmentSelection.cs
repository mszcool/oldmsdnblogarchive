#region Using directives

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;
using BudgetReport.DepartmentProxy;

#endregion

namespace BudgetReport.ActionPanes
{
    partial class DepartmentSelection : UserControl
    {
        public event EventHandler DepartmentSelected;

        public DepartmentSelection()
        {
            InitializeComponent();
        }

        public DepartmentEntity CurrentDepartment
        {
            get
            {
                if (departmentsBindingSource.Position >= 0)
                    return departmentsBindingSource.Current as DepartmentEntity;
                else
                    return null;
            }
        }

        public void InitializePanel(DepartmentEntity[] departments)
        {
            departmentsBindingSource.DataSource = departments;
        }

        private void ApplyCommand_Click(object sender, EventArgs e)
        {
            if (DepartmentSelected != null)
            {
                DepartmentSelected(this, new EventArgs());
            }
        }
    }
}
