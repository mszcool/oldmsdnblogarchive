package org.openxmldeveloper.samples.opc;

public final class ContentTypeConstant {

	public static final String CORE_PROPERTIES = "application/vnd.openxmlformats-package.core-properties+xml";

	public static final String WORD_MAIN_DOCUMENT = "application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml";

	public static final String IMAGE_JPEG = "image/jpeg";

	public static final String XML = "text/xml";

	/**
	 * Emp�che l'instanciation de cette classe
	 */
	private ContentTypeConstant() {

	}
}