/**
 * ProjectServiceSoapSkeleton.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.3 Oct 05, 2005 (05:23:37 EDT) WSDL2Java emitter.
 */

package com.microsoft.www.austria._2007._2.EUConference.Budgeting.projects;

public class ProjectServiceSoapSkeleton implements com.microsoft.www.austria._2007._2.EUConference.Budgeting.projects.ProjectServiceSoap, org.apache.axis.wsdl.Skeleton {
    private com.microsoft.www.austria._2007._2.EUConference.Budgeting.projects.ProjectServiceSoap impl;
    private static java.util.Map _myOperations = new java.util.Hashtable();
    private static java.util.Collection _myOperationsList = new java.util.ArrayList();

    /**
    * Returns List of OperationDesc objects with this name
    */
    public static java.util.List getOperationDescByName(java.lang.String methodName) {
        return (java.util.List)_myOperations.get(methodName);
    }

    /**
    * Returns Collection of OperationDescs
    */
    public static java.util.Collection getOperationDescs() {
        return _myOperationsList;
    }

    static {
        org.apache.axis.description.OperationDesc _oper;
        org.apache.axis.description.FaultDesc _fault;
        org.apache.axis.description.ParameterDesc [] _params;
        _params = new org.apache.axis.description.ParameterDesc [] {
        };
        _oper = new org.apache.axis.description.OperationDesc("getCategories", _params, new javax.xml.namespace.QName("http://www.microsoft.com/austria/2007/2/EUConference/Budgeting/projects", "GetCategoriesResult"));
        _oper.setReturnType(new javax.xml.namespace.QName("http://www.microsoft.com/austria/2007/2/EUConference/Budgeting/projects", "CategoriesResponseMessage"));
        _oper.setElementQName(new javax.xml.namespace.QName("http://www.microsoft.com/austria/2007/2/EUConference/Budgeting/projects", "GetCategories"));
        _oper.setSoapAction("http://www.microsoft.com/austria/2007/2/EUConference/Budgeting/projects/GetCategories");
        _myOperationsList.add(_oper);
        if (_myOperations.get("getCategories") == null) {
            _myOperations.put("getCategories", new java.util.ArrayList());
        }
        ((java.util.List)_myOperations.get("getCategories")).add(_oper);
        _params = new org.apache.axis.description.ParameterDesc [] {
            new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.microsoft.com/austria/2007/2/EUConference/Budgeting/projects", "request"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.microsoft.com/austria/2007/2/EUConference/Budgeting/projects", "ProjectsRequestMessage"), com.microsoft.www.austria._2007._2.EUConference.Budgeting.projects.ProjectsRequestMessage.class, false, false), 
        };
        _oper = new org.apache.axis.description.OperationDesc("getProjects", _params, new javax.xml.namespace.QName("http://www.microsoft.com/austria/2007/2/EUConference/Budgeting/projects", "GetProjectsResult"));
        _oper.setReturnType(new javax.xml.namespace.QName("http://www.microsoft.com/austria/2007/2/EUConference/Budgeting/projects", "ProjectsResponseMessage"));
        _oper.setElementQName(new javax.xml.namespace.QName("http://www.microsoft.com/austria/2007/2/EUConference/Budgeting/projects", "GetProjects"));
        _oper.setSoapAction("http://www.microsoft.com/austria/2007/2/EUConference/Budgeting/projects/GetProjects");
        _myOperationsList.add(_oper);
        if (_myOperations.get("getProjects") == null) {
            _myOperations.put("getProjects", new java.util.ArrayList());
        }
        ((java.util.List)_myOperations.get("getProjects")).add(_oper);
    }

    public ProjectServiceSoapSkeleton() {
        this.impl = new com.microsoft.www.austria._2007._2.EUConference.Budgeting.projects.ProjectServiceSoapImpl();
    }

    public ProjectServiceSoapSkeleton(com.microsoft.www.austria._2007._2.EUConference.Budgeting.projects.ProjectServiceSoap impl) {
        this.impl = impl;
    }
    public com.microsoft.www.austria._2007._2.EUConference.Budgeting.projects.CategoriesResponseMessage getCategories() throws java.rmi.RemoteException
    {
        com.microsoft.www.austria._2007._2.EUConference.Budgeting.projects.CategoriesResponseMessage ret = impl.getCategories();
        return ret;
    }

    public com.microsoft.www.austria._2007._2.EUConference.Budgeting.projects.ProjectsResponseMessage getProjects(com.microsoft.www.austria._2007._2.EUConference.Budgeting.projects.ProjectsRequestMessage request) throws java.rmi.RemoteException
    {
        com.microsoft.www.austria._2007._2.EUConference.Budgeting.projects.ProjectsResponseMessage ret = impl.getProjects(request);
        return ret;
    }

}
