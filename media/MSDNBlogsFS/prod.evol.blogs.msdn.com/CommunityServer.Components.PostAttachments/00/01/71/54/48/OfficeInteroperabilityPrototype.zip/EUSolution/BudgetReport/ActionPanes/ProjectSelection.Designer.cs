namespace BudgetReport.ActionPanes
{
    [System.ComponentModel.ToolboxItemAttribute(false)]
    partial class ProjectSelection
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.TitlePanel = new System.Windows.Forms.Panel();
            this.TitleLabel = new System.Windows.Forms.Label();
            this.projectsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.projectsDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.InsertProjectCommand = new System.Windows.Forms.Button();
            this.SpendingsGroup = new System.Windows.Forms.GroupBox();
            this.InsertSpendingCommand = new System.Windows.Forms.Button();
            this.SpendingAmountText = new System.Windows.Forms.TextBox();
            this.SpendingLabel = new System.Windows.Forms.Label();
            this.CategoryCombo = new System.Windows.Forms.ComboBox();
            this.categoriesBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.SelectCategoryLabel = new System.Windows.Forms.Label();
            this.TitlePanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.projectsBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.projectsDataGridView)).BeginInit();
            this.SpendingsGroup.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.categoriesBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // TitlePanel
            // 
            this.TitlePanel.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.TitlePanel.Controls.Add(this.TitleLabel);
            this.TitlePanel.Dock = System.Windows.Forms.DockStyle.Top;
            this.TitlePanel.Location = new System.Drawing.Point(0, 0);
            this.TitlePanel.Name = "TitlePanel";
            this.TitlePanel.Padding = new System.Windows.Forms.Padding(8);
            this.TitlePanel.Size = new System.Drawing.Size(291, 38);
            this.TitlePanel.TabIndex = 1;
            // 
            // TitleLabel
            // 
            this.TitleLabel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TitleLabel.Location = new System.Drawing.Point(8, 8);
            this.TitleLabel.Name = "TitleLabel";
            this.TitleLabel.Size = new System.Drawing.Size(275, 22);
            this.TitleLabel.TabIndex = 0;
            this.TitleLabel.Text = "Project and Spendings";
            // 
            // projectsBindingSource
            // 
            this.projectsBindingSource.DataSource = typeof(BudgetReport.ProjectProxy.ProjectEntity);
            // 
            // projectsDataGridView
            // 
            this.projectsDataGridView.AllowUserToAddRows = false;
            this.projectsDataGridView.AllowUserToDeleteRows = false;
            this.projectsDataGridView.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.projectsDataGridView.AutoGenerateColumns = false;
            this.projectsDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2});
            this.projectsDataGridView.DataSource = this.projectsBindingSource;
            this.projectsDataGridView.Location = new System.Drawing.Point(3, 44);
            this.projectsDataGridView.Name = "projectsDataGridView";
            this.projectsDataGridView.ReadOnly = true;
            this.projectsDataGridView.Size = new System.Drawing.Size(285, 158);
            this.projectsDataGridView.TabIndex = 2;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "ProjectName";
            this.dataGridViewTextBoxColumn3.HeaderText = "ProjectName";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "EndDate";
            this.dataGridViewTextBoxColumn1.HeaderText = "EndDate";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "StartDate";
            this.dataGridViewTextBoxColumn2.HeaderText = "StartDate";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.ReadOnly = true;
            // 
            // InsertProjectCommand
            // 
            this.InsertProjectCommand.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.InsertProjectCommand.Location = new System.Drawing.Point(3, 208);
            this.InsertProjectCommand.Name = "InsertProjectCommand";
            this.InsertProjectCommand.Size = new System.Drawing.Size(285, 31);
            this.InsertProjectCommand.TabIndex = 3;
            this.InsertProjectCommand.Text = "Insert Project...";
            this.InsertProjectCommand.UseVisualStyleBackColor = true;
            this.InsertProjectCommand.Click += new System.EventHandler(this.InsertProjectCommand_Click);
            // 
            // SpendingsGroup
            // 
            this.SpendingsGroup.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.SpendingsGroup.Controls.Add(this.InsertSpendingCommand);
            this.SpendingsGroup.Controls.Add(this.SpendingAmountText);
            this.SpendingsGroup.Controls.Add(this.SpendingLabel);
            this.SpendingsGroup.Controls.Add(this.CategoryCombo);
            this.SpendingsGroup.Controls.Add(this.SelectCategoryLabel);
            this.SpendingsGroup.Location = new System.Drawing.Point(3, 245);
            this.SpendingsGroup.Name = "SpendingsGroup";
            this.SpendingsGroup.Size = new System.Drawing.Size(285, 130);
            this.SpendingsGroup.TabIndex = 4;
            this.SpendingsGroup.TabStop = false;
            this.SpendingsGroup.Text = "Insert Spending";
            // 
            // InsertSpendingCommand
            // 
            this.InsertSpendingCommand.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.InsertSpendingCommand.Location = new System.Drawing.Point(83, 93);
            this.InsertSpendingCommand.Name = "InsertSpendingCommand";
            this.InsertSpendingCommand.Size = new System.Drawing.Size(196, 31);
            this.InsertSpendingCommand.TabIndex = 4;
            this.InsertSpendingCommand.Text = "Add line...";
            this.InsertSpendingCommand.UseVisualStyleBackColor = true;
            this.InsertSpendingCommand.Click += new System.EventHandler(this.InsertSpendingCommand_Click);
            // 
            // SpendingAmountText
            // 
            this.SpendingAmountText.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.SpendingAmountText.Location = new System.Drawing.Point(83, 63);
            this.SpendingAmountText.Name = "SpendingAmountText";
            this.SpendingAmountText.Size = new System.Drawing.Size(196, 25);
            this.SpendingAmountText.TabIndex = 3;
            // 
            // SpendingLabel
            // 
            this.SpendingLabel.AutoSize = true;
            this.SpendingLabel.Location = new System.Drawing.Point(9, 66);
            this.SpendingLabel.Name = "SpendingLabel";
            this.SpendingLabel.Size = new System.Drawing.Size(69, 19);
            this.SpendingLabel.TabIndex = 2;
            this.SpendingLabel.Text = "Spending:";
            // 
            // CategoryCombo
            // 
            this.CategoryCombo.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.CategoryCombo.DataSource = this.categoriesBindingSource;
            this.CategoryCombo.DisplayMember = "CategoryName";
            this.CategoryCombo.FormattingEnabled = true;
            this.CategoryCombo.Location = new System.Drawing.Point(83, 24);
            this.CategoryCombo.Name = "CategoryCombo";
            this.CategoryCombo.Size = new System.Drawing.Size(197, 25);
            this.CategoryCombo.TabIndex = 1;
            this.CategoryCombo.ValueMember = "CategoryID";
            // 
            // categoriesBindingSource
            // 
            this.categoriesBindingSource.DataSource = typeof(BudgetReport.ProjectProxy.CategoryEntity);
            // 
            // SelectCategoryLabel
            // 
            this.SelectCategoryLabel.AutoSize = true;
            this.SelectCategoryLabel.Location = new System.Drawing.Point(9, 27);
            this.SelectCategoryLabel.Name = "SelectCategoryLabel";
            this.SelectCategoryLabel.Size = new System.Drawing.Size(68, 19);
            this.SelectCategoryLabel.TabIndex = 0;
            this.SelectCategoryLabel.Text = "Category:";
            // 
            // ProjectSelection
            // 
            this.Controls.Add(this.SpendingsGroup);
            this.Controls.Add(this.InsertProjectCommand);
            this.Controls.Add(this.projectsDataGridView);
            this.Controls.Add(this.TitlePanel);
            this.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "ProjectSelection";
            this.Size = new System.Drawing.Size(291, 378);
            this.TitlePanel.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.projectsBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.projectsDataGridView)).EndInit();
            this.SpendingsGroup.ResumeLayout(false);
            this.SpendingsGroup.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.categoriesBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel TitlePanel;
        private System.Windows.Forms.Label TitleLabel;
        private System.Windows.Forms.BindingSource projectsBindingSource;
        private System.Windows.Forms.DataGridView projectsDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.Button InsertProjectCommand;
        private System.Windows.Forms.GroupBox SpendingsGroup;
        private System.Windows.Forms.TextBox SpendingAmountText;
        private System.Windows.Forms.Label SpendingLabel;
        private System.Windows.Forms.ComboBox CategoryCombo;
        private System.Windows.Forms.BindingSource categoriesBindingSource;
        private System.Windows.Forms.Label SelectCategoryLabel;
        private System.Windows.Forms.Button InsertSpendingCommand;
    }
}
