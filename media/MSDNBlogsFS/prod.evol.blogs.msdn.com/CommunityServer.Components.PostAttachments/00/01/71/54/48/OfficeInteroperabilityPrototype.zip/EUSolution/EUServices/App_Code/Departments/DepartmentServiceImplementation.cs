using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

/// <summary>
/// Summary description for DepartmentServiceImplementation
/// </summary>
namespace Department
{
    using Department.Entities;
    using Department.Contract;
    using Microsoft.SharePoint;

    public class DepartmentServiceImplementation : IDepartmentService
    {
        #region IDepartmentService Members

        public DepartmentListResponseMessage GetDepartments()
        {
            DepartmentListResponseMessage response = new DepartmentListResponseMessage();

            #region Dummy Implementation
            /*
            for (int i = 0; i < 5; i++)
            {
                DepartmentEntity d = new DepartmentEntity(
                    i.ToString(),
                    "Department " + i.ToString(),
                    "This is a nice department " + i.ToString(),
                    new GeneralEntities.Employee(i + 1, "First " + i.ToString(), "Last " + i.ToString())
                );

                response.Departments.Add(d);
            }
            */
            #endregion

            // Connect to the SharePoint site
            SPSite site = new SPSite(ConfigurationManager.AppSettings["SPSite"]);
            SPWeb web = site.OpenWeb();
            SPList departmentsList = web.GetList(ConfigurationManager.AppSettings["DepartmentList"]);

            // Run through the library's entries and get data from the document
            foreach (SPListItem department in departmentsList.Items)
            {
                DepartmentEntity e = new DepartmentEntity();
                e.DepartmentID = department["DepartmentID"].ToString();
                e.Name = department["Title"].ToString();
                e.Description = department["Description"].ToString();
                    e.Description = e.Description.Replace("<div>", "");
                    e.Description = e.Description.Replace("</div>", "");
                e.Manager = new GeneralEntities.Employee();
                e.Manager.EmployeeID = int.Parse(department["Manager ID"].ToString());
                e.Manager.Firstname = department["First Name"].ToString();
                e.Manager.Lastname = department["Last Name"].ToString();
                response.Departments.Add(e);
            }

            return response;
        }

        #endregion
    }
}