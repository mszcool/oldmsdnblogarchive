/**
 * BudgetReportEntity.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.3 Oct 05, 2005 (05:23:37 EDT) WSDL2Java emitter.
 */

package com.microsoft.www.austria._2007._2.EUConference.Budgeting.budget.entities;

public class BudgetReportEntity  implements java.io.Serializable {
    private java.lang.String reportId;

    private java.util.Calendar reportDate;

    private com.microsoft.www.austria._2007._2.EUConference.Budgeting.departments.entities.DepartmentEntity department;

    private com.microsoft.www.austria._2007._2.EUConference.Budgeting.projects.entities.ProjectEntity project;

    private com.microsoft.www.austria._2007._2.EUConference.Budgeting.budget.entities.BudgetReportItemEntity[] items;

    public BudgetReportEntity() {
    }

    public BudgetReportEntity(
           java.lang.String reportId,
           java.util.Calendar reportDate,
           com.microsoft.www.austria._2007._2.EUConference.Budgeting.departments.entities.DepartmentEntity department,
           com.microsoft.www.austria._2007._2.EUConference.Budgeting.projects.entities.ProjectEntity project,
           com.microsoft.www.austria._2007._2.EUConference.Budgeting.budget.entities.BudgetReportItemEntity[] items) {
           this.reportId = reportId;
           this.reportDate = reportDate;
           this.department = department;
           this.project = project;
           this.items = items;
    }


    /**
     * Gets the reportId value for this BudgetReportEntity.
     * 
     * @return reportId
     */
    public java.lang.String getReportId() {
        return reportId;
    }


    /**
     * Sets the reportId value for this BudgetReportEntity.
     * 
     * @param reportId
     */
    public void setReportId(java.lang.String reportId) {
        this.reportId = reportId;
    }


    /**
     * Gets the reportDate value for this BudgetReportEntity.
     * 
     * @return reportDate
     */
    public java.util.Calendar getReportDate() {
        return reportDate;
    }


    /**
     * Sets the reportDate value for this BudgetReportEntity.
     * 
     * @param reportDate
     */
    public void setReportDate(java.util.Calendar reportDate) {
        this.reportDate = reportDate;
    }


    /**
     * Gets the department value for this BudgetReportEntity.
     * 
     * @return department
     */
    public com.microsoft.www.austria._2007._2.EUConference.Budgeting.departments.entities.DepartmentEntity getDepartment() {
        return department;
    }


    /**
     * Sets the department value for this BudgetReportEntity.
     * 
     * @param department
     */
    public void setDepartment(com.microsoft.www.austria._2007._2.EUConference.Budgeting.departments.entities.DepartmentEntity department) {
        this.department = department;
    }


    /**
     * Gets the project value for this BudgetReportEntity.
     * 
     * @return project
     */
    public com.microsoft.www.austria._2007._2.EUConference.Budgeting.projects.entities.ProjectEntity getProject() {
        return project;
    }


    /**
     * Sets the project value for this BudgetReportEntity.
     * 
     * @param project
     */
    public void setProject(com.microsoft.www.austria._2007._2.EUConference.Budgeting.projects.entities.ProjectEntity project) {
        this.project = project;
    }


    /**
     * Gets the items value for this BudgetReportEntity.
     * 
     * @return items
     */
    public com.microsoft.www.austria._2007._2.EUConference.Budgeting.budget.entities.BudgetReportItemEntity[] getItems() {
        return items;
    }


    /**
     * Sets the items value for this BudgetReportEntity.
     * 
     * @param items
     */
    public void setItems(com.microsoft.www.austria._2007._2.EUConference.Budgeting.budget.entities.BudgetReportItemEntity[] items) {
        this.items = items;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof BudgetReportEntity)) return false;
        BudgetReportEntity other = (BudgetReportEntity) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.reportId==null && other.getReportId()==null) || 
             (this.reportId!=null &&
              this.reportId.equals(other.getReportId()))) &&
            ((this.reportDate==null && other.getReportDate()==null) || 
             (this.reportDate!=null &&
              this.reportDate.equals(other.getReportDate()))) &&
            ((this.department==null && other.getDepartment()==null) || 
             (this.department!=null &&
              this.department.equals(other.getDepartment()))) &&
            ((this.project==null && other.getProject()==null) || 
             (this.project!=null &&
              this.project.equals(other.getProject()))) &&
            ((this.items==null && other.getItems()==null) || 
             (this.items!=null &&
              java.util.Arrays.equals(this.items, other.getItems())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getReportId() != null) {
            _hashCode += getReportId().hashCode();
        }
        if (getReportDate() != null) {
            _hashCode += getReportDate().hashCode();
        }
        if (getDepartment() != null) {
            _hashCode += getDepartment().hashCode();
        }
        if (getProject() != null) {
            _hashCode += getProject().hashCode();
        }
        if (getItems() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getItems());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getItems(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(BudgetReportEntity.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://www.microsoft.com/austria/2007/2/EUConference/Budgeting/budget/entities", "BudgetReportEntity"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("reportId");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.microsoft.com/austria/2007/2/EUConference/Budgeting/budget/entities", "ReportId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("reportDate");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.microsoft.com/austria/2007/2/EUConference/Budgeting/budget/entities", "ReportDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("department");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.microsoft.com/austria/2007/2/EUConference/Budgeting/budget/entities", "Department"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.microsoft.com/austria/2007/2/EUConference/Budgeting/departments/entities", "DepartmentEntity"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("project");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.microsoft.com/austria/2007/2/EUConference/Budgeting/budget/entities", "Project"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.microsoft.com/austria/2007/2/EUConference/Budgeting/projects/entities", "ProjectEntity"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("items");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.microsoft.com/austria/2007/2/EUConference/Budgeting/budget/entities", "Items"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.microsoft.com/austria/2007/2/EUConference/Budgeting/budget/entities", "BudgetReportItemEntity"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setItemQName(new javax.xml.namespace.QName("http://www.microsoft.com/austria/2007/2/EUConference/Budgeting/budget/entities", "BudgetReportItemEntity"));
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
