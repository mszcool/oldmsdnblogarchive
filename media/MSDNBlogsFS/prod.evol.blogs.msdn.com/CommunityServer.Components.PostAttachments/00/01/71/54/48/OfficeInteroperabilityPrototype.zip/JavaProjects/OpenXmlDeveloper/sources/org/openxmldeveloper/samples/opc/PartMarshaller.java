package org.openxmldeveloper.samples.opc;

import java.io.OutputStream;

public interface PartMarshaller {

	public void marshall(PackagePart part, OutputStream out);
}