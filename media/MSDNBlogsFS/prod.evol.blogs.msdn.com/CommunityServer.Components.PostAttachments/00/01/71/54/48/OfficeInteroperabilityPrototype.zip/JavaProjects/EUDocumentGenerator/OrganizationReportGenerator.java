import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.Calendar;
import java.util.Date;
import java.util.Random;
import java.util.zip.ZipFile;

import org.dom4j.*;
import org.dom4j.io.SAXReader;
import org.openxmldeveloper.samples.opc.ContentTypeConstant;
import org.openxmldeveloper.samples.opc.Package;
import org.openxmldeveloper.samples.opc.PackageAccess;
import org.openxmldeveloper.samples.opc.PackagePart;
import org.openxmldeveloper.samples.opc.PackageRelationship;
import org.openxmldeveloper.samples.opc.PackageRelationshipConstants;

import sun.util.calendar.CalendarDate;
import sun.util.calendar.CalendarSystem;
import sun.util.calendar.CalendarUtils;

import com.microsoft.www.austria._2007._2.EUConference.Budgeting.budget.entities.BudgetReportEntity;
import com.microsoft.www.austria._2007._2.EUConference.Budgeting.budget.entities.BudgetReportItemEntity;

public class OrganizationReportGenerator {

	public static void GenerateOrganizationReport(BudgetReportEntity reports[], File template, File target) throws Exception
	{
		// Open the word document template file
		Package templatePackage;
		try {
			ZipFile zipFile = new ZipFile(template);
			templatePackage = Package.open(zipFile, PackageAccess.ReadWrite);
		} catch(IOException ex) {
			throw new Exception("Unable to open template package!");
		}
		
		// Retrieve the main package part
		PackageRelationship coreDocRelationship = 
		templatePackage.getRelationshipsByType(
				PackageRelationshipConstants.NS_CORE_DOCUMENT).getRelationship(0);

		// Get the content part from the relationship
		PackagePart coreDocument = templatePackage.getPart(coreDocRelationship);
		
		// Read the package into a dom4j document
		InputStream wordDocumentPartInStream = coreDocument.getInputStream();
		SAXReader reader = new SAXReader();
		Document wordDocumentXml = reader.read(wordDocumentPartInStream);
		wordDocumentPartInStream.close();
		
		// Update the document itself
		UpdateDocument(reports, wordDocumentXml);
	
		// Add a marshaller for saving the document
		templatePackage.addMarshaller(
				ContentTypeConstant.WORD_MAIN_DOCUMENT, 
				new WordDocumentMarshaller(wordDocumentXml));
		
		// Package the document back
		templatePackage.save(target);	
	}
	
	private static void UpdateDocument(BudgetReportEntity reports[], Document doc)
	{
		// Some value counters
		Calendar fromDate, toDate;
		double gains, losses, overallResults = 0;
		
		// Get original values for the nodes
		Element departmentOverviewsRoot = GetElementNode("departmentOverviews", "//", doc.getDocument());
		Element departmentOverviewsRootTable = (Element)departmentOverviewsRoot.selectSingleNode(".//w:tbl");
		Element singleDepartmentOverview = null;
		
		Element departmentDetailsRoot = GetElementNode("departmentDetails", "//", doc.getDocument());
		Element departmentDetailsTemplate = GetElementNode("departmentDetail", ".//", departmentDetailsRoot).createCopy();
		Element departmentDetails = null;
		Element budgetItem = null;
		Element budgetItemTable = null;
		
		// Each report entity has one summary line and one details chapter
		fromDate = Calendar.getInstance();
		toDate = Calendar.getInstance();
		for(int i=0; i < reports.length; i++){
			
			// Verify the date for the report
			if(reports[i].getReportDate().compareTo(fromDate) < 0)
				fromDate = reports[i].getReportDate();
			if(reports[i].getReportDate().compareTo(toDate) >= 0)
				toDate = reports[i].getReportDate();
			
			// The name of the report is the department and its project
			String departmentName = String.format("%s (%s)", 
					reports[i].getDepartment().getName(),
					reports[i].getProject().getProjectName());
			
			// Create a new department details node
			if(departmentDetails == null)
			{
				departmentDetails = GetElementNode("departmentDetail", ".//", departmentDetailsRoot);
			}
			else
			{
				departmentDetails = departmentDetailsTemplate.createCopy();
				departmentDetailsRoot.add(departmentDetails);
			}
			UpdateElement(departmentDetails, "departmentName", departmentName);
			budgetItemTable = (Element)departmentDetails.selectSingleNode(".//w:tbl");
			
			// Calculate summary values
			gains = losses = 0;
			budgetItem = null;
			BudgetReportItemEntity[] items = reports[i].getItems();
			for(int j=0; j < items.length; j++)
			{
				double dv = items[j].getAmount().doubleValue();
				if(dv > 0)
					gains += dv;
				else
					losses += dv * (-1);
				
				// For each detail create one row in the current details table
				if(budgetItem == null)
				{
					budgetItem = GetElementNode("budgetItem", ".//", budgetItemTable);
				}
				else
				{
					budgetItem = budgetItem.createCopy();
					budgetItemTable.add(budgetItem);
				}
				UpdateElement(budgetItem, "description", items[j].getDescription());
				UpdateElement(budgetItem, "amount", items[j].getAmount().toString());
			}
			overallResults += (gains - losses);
			
			// First of all create the summary line
			if(singleDepartmentOverview == null)
			{
				singleDepartmentOverview = GetElementNode("overviewItem", ".//", departmentOverviewsRoot);
			} 
			else 
			{
				singleDepartmentOverview = singleDepartmentOverview.createCopy();
				departmentOverviewsRootTable.add(singleDepartmentOverview);
			}
			
			UpdateElement(singleDepartmentOverview, 
					"departmentName", departmentName);
			UpdateElement(singleDepartmentOverview,
					"gains", Double.toString(gains));
			UpdateElement(singleDepartmentOverview,
					"losses", Double.toString(losses));
			UpdateElement(singleDepartmentOverview, 
					"results", Double.toString(overallResults));
		}
		
		// Update the general values
		Random rnd = new Random();
		int reportID = rnd.nextInt();
		if(reportID < 0) reportID *= (-1);
		
		CalendarSystem system = CalendarSystem.getGregorianCalendar();
		CalendarDate currentDate = system.getCalendarDate();
		String currentDateString = String.format("%s-%s-%s", 
				currentDate.getYear(), currentDate.getMonth(), currentDate.getDayOfMonth());
		
		String fromDateString = String.format("%s-%s-%s", 
				fromDate.getTime().getYear(), fromDate.getTime().getMonth(), fromDate.getTime().getDay());
		String toDateString = String.format("%s-%s-%s", 
				toDate.getTime().getYear(), toDate.getTime().getMonth(), toDate.getTime().getDay());
		
		UpdateElement(doc.getRootElement(), "reportID", Integer.toString(reportID));
		UpdateElement(doc.getRootElement(), "reportDate", currentDateString);
		UpdateElement(doc.getRootElement(), "resultsValue", Double.toString(overallResults));
		UpdateElement(doc.getRootElement(), "fromPeriod", fromDateString);
		UpdateElement(doc.getRootElement(), "toPeriod", toDateString);
	}
	
	private static Element GetElementNode(String elementName, String prefix, Node parent){
		String XPathExpression =
			String.format("%sw:customXml[@w:element='%s']", prefix, elementName);
		return (Element)parent.selectSingleNode(XPathExpression);
	}
	
	private static void UpdateElement(Element parent, String elementName, String value)
	{
		Node toUpdate = GetElementNode(elementName, ".//", parent);
		Node textRun = toUpdate.selectSingleNode(".//w:t");
		textRun.setText(value);
	}
}
