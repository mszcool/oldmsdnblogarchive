using System;
using System.Web;
using System.Collections;
using System.Web.Services;
using System.Web.Services.Protocols;

using Department;
using Department.Entities;
using Department.Contract;
using EUServices.NamespaceNames;

/// <summary>
/// Summary description for DepartmentService
/// </summary>
[WebService(Namespace = Constants.DepartmentServiceNamespace)]
[WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
public class DepartmentService : System.Web.Services.WebService, IDepartmentService {

    DepartmentServiceImplementation Implementation;

    public DepartmentService () {

        //Uncomment the following line if using designed components 
        //InitializeComponent(); 

        Implementation = new DepartmentServiceImplementation();
    }

    #region IDepartmentService Members

    [WebMethod]
    public DepartmentListResponseMessage GetDepartments()
    {
        return Implementation.GetDepartments();
    }

    #endregion
}

