
public class ReportGeneratorConstants {
    public static final String WordNamespace = "http://schemas.openxmlformats.org/wordprocessingml/2006/main";
    public static final String OfficeNamespace = "urn:schemas-microsoft-com:office:office";

    public static final String BudgetNamespace = "http://www.microsoft.com/austria/samples/euconference/2007/02/budgetreport";

    public static final String WordText = "<w:t xml:space=\"preserve\">{0}</w:t>";
    public static final String WordRun = "<w:r>{0}</w:r>";
    public static final String WordBreak = "<w:br />";

    public static final String WordDocumentPartUri = "/word/document.xml";
    public static final String WordDocumentPartContentType = "application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml";
}
