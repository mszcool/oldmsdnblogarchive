/**
 * BudgetReportsLocator.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.3 Oct 05, 2005 (05:23:37 EDT) WSDL2Java emitter.
 */

package com.microsoft.www.austria._2007._2.EUConference.Budgeting.budget;

public class BudgetReportsLocator extends org.apache.axis.client.Service implements com.microsoft.www.austria._2007._2.EUConference.Budgeting.budget.BudgetReports {

    public BudgetReportsLocator() {
    }


    public BudgetReportsLocator(org.apache.axis.EngineConfiguration config) {
        super(config);
    }

    public BudgetReportsLocator(java.lang.String wsdlLoc, javax.xml.namespace.QName sName) throws javax.xml.rpc.ServiceException {
        super(wsdlLoc, sName);
    }

    // Use to get a proxy class for BudgetReportsSoap
    private java.lang.String BudgetReportsSoap_address = "http://localhost:1076/EUServices/BudgetReports.asmx";

    public java.lang.String getBudgetReportsSoapAddress() {
        return BudgetReportsSoap_address;
    }

    // The WSDD service name defaults to the port name.
    private java.lang.String BudgetReportsSoapWSDDServiceName = "BudgetReportsSoap";

    public java.lang.String getBudgetReportsSoapWSDDServiceName() {
        return BudgetReportsSoapWSDDServiceName;
    }

    public void setBudgetReportsSoapWSDDServiceName(java.lang.String name) {
        BudgetReportsSoapWSDDServiceName = name;
    }

    public com.microsoft.www.austria._2007._2.EUConference.Budgeting.budget.BudgetReportsSoap getBudgetReportsSoap() throws javax.xml.rpc.ServiceException {
       java.net.URL endpoint;
        try {
            endpoint = new java.net.URL(BudgetReportsSoap_address);
        }
        catch (java.net.MalformedURLException e) {
            throw new javax.xml.rpc.ServiceException(e);
        }
        return getBudgetReportsSoap(endpoint);
    }

    public com.microsoft.www.austria._2007._2.EUConference.Budgeting.budget.BudgetReportsSoap getBudgetReportsSoap(java.net.URL portAddress) throws javax.xml.rpc.ServiceException {
        try {
            com.microsoft.www.austria._2007._2.EUConference.Budgeting.budget.BudgetReportsSoapStub _stub = new com.microsoft.www.austria._2007._2.EUConference.Budgeting.budget.BudgetReportsSoapStub(portAddress, this);
            _stub.setPortName(getBudgetReportsSoapWSDDServiceName());
            return _stub;
        }
        catch (org.apache.axis.AxisFault e) {
            return null;
        }
    }

    public void setBudgetReportsSoapEndpointAddress(java.lang.String address) {
        BudgetReportsSoap_address = address;
    }


    // Use to get a proxy class for BudgetReportsSoap12
    private java.lang.String BudgetReportsSoap12_address = "http://localhost:1076/EUServices/BudgetReports.asmx";

    public java.lang.String getBudgetReportsSoap12Address() {
        return BudgetReportsSoap12_address;
    }

    // The WSDD service name defaults to the port name.
    private java.lang.String BudgetReportsSoap12WSDDServiceName = "BudgetReportsSoap12";

    public java.lang.String getBudgetReportsSoap12WSDDServiceName() {
        return BudgetReportsSoap12WSDDServiceName;
    }

    public void setBudgetReportsSoap12WSDDServiceName(java.lang.String name) {
        BudgetReportsSoap12WSDDServiceName = name;
    }

    public com.microsoft.www.austria._2007._2.EUConference.Budgeting.budget.BudgetReportsSoap getBudgetReportsSoap12() throws javax.xml.rpc.ServiceException {
       java.net.URL endpoint;
        try {
            endpoint = new java.net.URL(BudgetReportsSoap12_address);
        }
        catch (java.net.MalformedURLException e) {
            throw new javax.xml.rpc.ServiceException(e);
        }
        return getBudgetReportsSoap12(endpoint);
    }

    public com.microsoft.www.austria._2007._2.EUConference.Budgeting.budget.BudgetReportsSoap getBudgetReportsSoap12(java.net.URL portAddress) throws javax.xml.rpc.ServiceException {
        try {
            com.microsoft.www.austria._2007._2.EUConference.Budgeting.budget.BudgetReportsSoap12Stub _stub = new com.microsoft.www.austria._2007._2.EUConference.Budgeting.budget.BudgetReportsSoap12Stub(portAddress, this);
            _stub.setPortName(getBudgetReportsSoap12WSDDServiceName());
            return _stub;
        }
        catch (org.apache.axis.AxisFault e) {
            return null;
        }
    }

    public void setBudgetReportsSoap12EndpointAddress(java.lang.String address) {
        BudgetReportsSoap12_address = address;
    }

    /**
     * For the given interface, get the stub implementation.
     * If this service has no port for the given interface,
     * then ServiceException is thrown.
     * This service has multiple ports for a given interface;
     * the proxy implementation returned may be indeterminate.
     */
    public java.rmi.Remote getPort(Class serviceEndpointInterface) throws javax.xml.rpc.ServiceException {
        try {
            if (com.microsoft.www.austria._2007._2.EUConference.Budgeting.budget.BudgetReportsSoap.class.isAssignableFrom(serviceEndpointInterface)) {
                com.microsoft.www.austria._2007._2.EUConference.Budgeting.budget.BudgetReportsSoapStub _stub = new com.microsoft.www.austria._2007._2.EUConference.Budgeting.budget.BudgetReportsSoapStub(new java.net.URL(BudgetReportsSoap_address), this);
                _stub.setPortName(getBudgetReportsSoapWSDDServiceName());
                return _stub;
            }
            if (com.microsoft.www.austria._2007._2.EUConference.Budgeting.budget.BudgetReportsSoap.class.isAssignableFrom(serviceEndpointInterface)) {
                com.microsoft.www.austria._2007._2.EUConference.Budgeting.budget.BudgetReportsSoap12Stub _stub = new com.microsoft.www.austria._2007._2.EUConference.Budgeting.budget.BudgetReportsSoap12Stub(new java.net.URL(BudgetReportsSoap12_address), this);
                _stub.setPortName(getBudgetReportsSoap12WSDDServiceName());
                return _stub;
            }
        }
        catch (java.lang.Throwable t) {
            throw new javax.xml.rpc.ServiceException(t);
        }
        throw new javax.xml.rpc.ServiceException("There is no stub implementation for the interface:  " + (serviceEndpointInterface == null ? "null" : serviceEndpointInterface.getName()));
    }

    /**
     * For the given interface, get the stub implementation.
     * If this service has no port for the given interface,
     * then ServiceException is thrown.
     */
    public java.rmi.Remote getPort(javax.xml.namespace.QName portName, Class serviceEndpointInterface) throws javax.xml.rpc.ServiceException {
        if (portName == null) {
            return getPort(serviceEndpointInterface);
        }
        java.lang.String inputPortName = portName.getLocalPart();
        if ("BudgetReportsSoap".equals(inputPortName)) {
            return getBudgetReportsSoap();
        }
        else if ("BudgetReportsSoap12".equals(inputPortName)) {
            return getBudgetReportsSoap12();
        }
        else  {
            java.rmi.Remote _stub = getPort(serviceEndpointInterface);
            ((org.apache.axis.client.Stub) _stub).setPortName(portName);
            return _stub;
        }
    }

    public javax.xml.namespace.QName getServiceName() {
        return new javax.xml.namespace.QName("http://www.microsoft.com/austria/2007/2/EUConference/Budgeting/budget", "BudgetReports");
    }

    private java.util.HashSet ports = null;

    public java.util.Iterator getPorts() {
        if (ports == null) {
            ports = new java.util.HashSet();
            ports.add(new javax.xml.namespace.QName("http://www.microsoft.com/austria/2007/2/EUConference/Budgeting/budget", "BudgetReportsSoap"));
            ports.add(new javax.xml.namespace.QName("http://www.microsoft.com/austria/2007/2/EUConference/Budgeting/budget", "BudgetReportsSoap12"));
        }
        return ports.iterator();
    }

    /**
    * Set the endpoint address for the specified port name.
    */
    public void setEndpointAddress(java.lang.String portName, java.lang.String address) throws javax.xml.rpc.ServiceException {
        
if ("BudgetReportsSoap".equals(portName)) {
            setBudgetReportsSoapEndpointAddress(address);
        }
        else 
if ("BudgetReportsSoap12".equals(portName)) {
            setBudgetReportsSoap12EndpointAddress(address);
        }
        else 
{ // Unknown Port Name
            throw new javax.xml.rpc.ServiceException(" Cannot set Endpoint Address for Unknown Port" + portName);
        }
    }

    /**
    * Set the endpoint address for the specified port name.
    */
    public void setEndpointAddress(javax.xml.namespace.QName portName, java.lang.String address) throws javax.xml.rpc.ServiceException {
        setEndpointAddress(portName.getLocalPart(), address);
    }

}
