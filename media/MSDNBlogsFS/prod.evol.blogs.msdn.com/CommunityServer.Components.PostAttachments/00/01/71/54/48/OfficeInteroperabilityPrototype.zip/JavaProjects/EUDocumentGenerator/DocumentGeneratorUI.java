import java.awt.Container;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.util.Calendar;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import com.microsoft.www.austria._2007._2.EUConference.Budgeting.budget.BudgetReportRequestMessage;
import com.microsoft.www.austria._2007._2.EUConference.Budgeting.budget.BudgetReportResponseMessage;
import com.microsoft.www.austria._2007._2.EUConference.Budgeting.budget.BudgetReportsSoapProxy;
import com.microsoft.www.austria._2007._2.EUConference.Budgeting.budget.BudgetReportsSoapStub;
import com.microsoft.www.austria._2007._2.EUConference.Budgeting.budget.entities.BudgetReportEntity;


public class DocumentGeneratorUI extends JFrame implements ActionListener {

	private JTextField InputFileNameText;
	private JTextField OutputFileNameText;
	private JTextField UsernameText;
	private JPasswordField PasswordText;
	private JButton ConvertNowCommand;
	private JTextArea LogAreaText;
	
	public static final long serialVersionUID = 1; 
	
	public DocumentGeneratorUI()
	{	
		super("Office Open XML Document Generator");
		
		// Set basic properties
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		Container pane = this.getContentPane();
		
		pane.setLayout(new GridBagLayout());
		GridBagConstraints c = new GridBagConstraints();
		c.fill = GridBagConstraints.HORIZONTAL;
		
		// Create controls
		
		JLabel UsernameLabel = new JLabel();
		UsernameLabel.setText("User Name:");
		c.gridx = 0;
		c.gridy = 0;
		pane.add(UsernameLabel);
		
		UsernameText = new JTextField();
		UsernameText.setText("Administrator");
		UsernameText.setColumns(18);
		c.gridx = 1;
		c.gridy = 0;
		pane.add(UsernameText);
		
		JLabel PasswordLabel = new JLabel();
		PasswordLabel.setText("Password:");
		c.gridx = 2;
		c.gridy = 0;
		pane.add(PasswordLabel);

		PasswordText = new JPasswordField();
		PasswordText.setColumns(18);
		c.gridx = 4;
		c.gridy = 0;
		pane.add(PasswordText);
		
		InputFileNameText = new JTextField();
		InputFileNameText.setText("OrgReport.docx");
		InputFileNameText.setColumns(25);
		c.gridx = 0;
		c.gridy = 1;
		c.gridwidth = 2;
		pane.add(InputFileNameText, c);
		
		OutputFileNameText = new JTextField();
		OutputFileNameText.setText("TestOutput.docx");
		c.gridx = 2;
		c.gridy = 1;
		c.gridwidth = 2;
		OutputFileNameText.setColumns(25);
		pane.add(OutputFileNameText, c);
		
		ConvertNowCommand = new JButton("Generate...");
		ConvertNowCommand.addActionListener(this);
		c.gridx = 0;
		c.gridy = 2;
		c.gridwidth = 4;
		pane.add(ConvertNowCommand, c);
		
		JPanel areaPanel = new JPanel();
		c.ipady = 40;      //make this component tall
		c.weightx = 0.0;
		c.gridwidth = 4;
		c.gridx = 0;
		c.gridy = 3;
		
		LogAreaText = new JTextArea();
		LogAreaText.setText("Log\r\nhere...");
		areaPanel.add(LogAreaText);
		LogAreaText.setRows(20);
		LogAreaText.setColumns(50);
		pane.add(areaPanel, c);
	}
	
	public void actionPerformed(ActionEvent e)
	{		
		// Now open the template package
		File sourceFile = new File(InputFileNameText.getText());
		File targetFile = new File(OutputFileNameText.getText());
		
		LogAreaText.setText("Starting document generation...");
		try 
		{
			// Calling the web service
			BudgetReportEntity[] reports;
			reports = CallWebService();
			
			// Now generate based on web service results
			LogAreaText.append("\r\nDocument generator starts working...");
			OrganizationReportGenerator.GenerateOrganizationReport(reports, sourceFile, targetFile);
			LogAreaText.append("\r\nDocument generated!");
		} 
		catch(Exception ex) {
			LogAreaText.append("\r\nException occured!");
			LogAreaText.append("\r\n" + ex.getMessage());
			ex.printStackTrace();
		}
		LogAreaText.append("\r\nProcess completed!");
	}
	
	private BudgetReportEntity[] CallWebService() throws Exception 
	{
		BudgetReportEntity[] entities = null;
		
		try 
		{
			LogAreaText.append("\r\nCalling web service...");
			BudgetReportsSoapProxy proxy = new BudgetReportsSoapProxy();
			//proxy.setEndpoint("http://localhost:1076/EUServices/BudgetReports.asmx");
			proxy.setEndpoint("http://localhost/EUServices/BudgetReports.asmx");
			BudgetReportsSoapStub stub = (BudgetReportsSoapStub)proxy.getBudgetReportsSoap();
			stub.setUsername(UsernameText.getText());
			stub.setPassword(String.valueOf(PasswordText.getPassword()));
			
			BudgetReportRequestMessage request = new BudgetReportRequestMessage();
			request.setEndDate(Calendar.getInstance());
			request.setStartDate(Calendar.getInstance());
	
			BudgetReportResponseMessage response = stub.getReports(request);
			entities = response.getReports();
			LogAreaText.append("\r\nWeb service called successfully!");
		}
		catch(Exception ex) {
			LogAreaText.append("\r\nUnable to call web service!");
			ex.printStackTrace();
			throw new Exception("\r\nUnable to call web service!");
		}
		
		return entities;
	}
}
