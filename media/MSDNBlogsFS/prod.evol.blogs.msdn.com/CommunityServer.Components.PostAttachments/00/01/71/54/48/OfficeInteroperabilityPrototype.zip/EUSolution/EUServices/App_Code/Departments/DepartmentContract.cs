using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Xml.Serialization;
using EUServices.NamespaceNames;
using Department.Entities;

namespace Department.Contract
{
    [XmlType(Namespace = Constants.DepartmentServiceNamespace)]
    public class DepartmentListResponseMessage
    {
        private DepartmentEntities _Departments;

        public DepartmentEntities Departments
        {
            get { return _Departments; }
            set { _Departments = value; }
        }

        public DepartmentListResponseMessage()
        {
            _Departments = new DepartmentEntities();
        }
    }

    [XmlType(Namespace=Constants.DepartmentServiceNamespace)]
    public interface IDepartmentService
    {
        DepartmentListResponseMessage GetDepartments();
    }
}