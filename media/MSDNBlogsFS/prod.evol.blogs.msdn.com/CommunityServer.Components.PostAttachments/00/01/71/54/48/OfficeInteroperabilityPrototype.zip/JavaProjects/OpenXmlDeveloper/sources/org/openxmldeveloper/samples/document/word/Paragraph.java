package org.openxmldeveloper.samples.document.word;

import java.util.ArrayList;

import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;

/**
 * Repr�sente un paragraphe. <b>Attention, ce code de d�monstration ne prend ne
 * tient pas compte des styles et autres informations du document. Ainsi les
 * propri�t�s des paragraphes et des runs en plus d'�tre incompl�tes, ne sont
 * pas correctement impl�ment�es, donc non valides avec les sp�cifications.
 * Cependant, cette impl�mentation suffit � cette d�monstration.</b>
 * 
 * @author Julien Chable
 */
public final class Paragraph {

	private static final String RUN_VERTICAL_ALIGNEMENT_PROPERTY_TAG_NAME = "w:vertAlign";

	private static final String RUN_FONT_SIZE_PROPERTY_TAG_NAME = "w:sz";

	public static final String RUN_UNDERLINE_PROPERTY_TAG_NAME = "w:u";

	public static final String RUN_ITALIC_PROPERTY_TAG_NAME = "w:i";

	public static final String RUN_BOLD_PROPERTY_TAG_NAME = "w:b";

	public static final String RUN_PROPERTIES_TAG_NAME = "w:rPr";

	public static final String PARAGRAPH_RUN_TAG_NAME = "w:r";

	public static final String PROPERTIES_VALUE_TAG_NAME = "w:val";

	public static final String PARAGRAPH_ALIGNEMENT_TAG_NAME = "w:jc";

	public static final String PARAGRAPH_PROPERTIES_TAG_NAME = "w:pPr";

	public static final String BODY_PARAGRAPH_TAG_NAME = "w:p";

	public static final String RUN_TEXT = "w:t";

	/**
	 * L'alignement du paragraphe.
	 */
	protected ParagraphAlignment alignment;

	/**
	 * La liste des Runs dans l'ordre dans lesquels ceux-ci ont �t� ajout�s.
	 */
	protected ArrayList<Run> runs;

	/**
	 * Pr�vient la construction de paragraphe.
	 */
	protected Paragraph() {
		runs = new ArrayList<Run>();
	}

	/**
	 * Ajoute un Run � ce paragraphe.
	 * 
	 * @param run
	 *            Le Run � ajouter.
	 */
	public void addRun(Run run) {
		runs.add(run);
	}

	/**
	 * Impl�mentation rudimentaire d'une contruction de l'�l�ment XML de ce
	 * paragraphe.
	 * 
	 * @return Le noeud DOM repr�sentant ce paragraphe.
	 */
	public Node build(Document rootDocument) {
		Element paragraph = rootDocument.createElement(BODY_PARAGRAPH_TAG_NAME);

		// Les propri�t�s
		Element parProps = rootDocument
				.createElement(PARAGRAPH_PROPERTIES_TAG_NAME);
		paragraph.appendChild(parProps);

		// Alignement du paragraphe
		Element paraAlignement = rootDocument
				.createElement(PARAGRAPH_ALIGNEMENT_TAG_NAME);
		Attr attrAlignement = rootDocument
				.createAttribute(PROPERTIES_VALUE_TAG_NAME);
		attrAlignement.setValue(alignment.toString());
		paraAlignement.setAttributeNode(attrAlignement);
		parProps.appendChild(paraAlignement);

		// Les Runs
		for (Run r : runs) {
			Element run = rootDocument.createElement(PARAGRAPH_RUN_TAG_NAME);
			paragraph.appendChild(run);

			// Propri�t�s du Run
			Element runProps = rootDocument
					.createElement(RUN_PROPERTIES_TAG_NAME);
			run.appendChild(runProps);

			// Gras
			if (r.isBold()) {
				Element boldProp = rootDocument
						.createElement(RUN_BOLD_PROPERTY_TAG_NAME);
				runProps.appendChild(boldProp);
			}

			// Italique
			if (r.isItalic()) {
				Element italicProp = rootDocument
						.createElement(RUN_ITALIC_PROPERTY_TAG_NAME);
				runProps.appendChild(italicProp);
			}

			// Soulignement
			if (r.getUnderline() != UnderlineStyle.NONE) {
				Element underlineProp = rootDocument
						.createElement(RUN_UNDERLINE_PROPERTY_TAG_NAME);
				Attr val = rootDocument
						.createAttribute(PROPERTIES_VALUE_TAG_NAME);
				val.setValue(r.getUnderline().toString());
				underlineProp.setAttributeNode(val);
				runProps.appendChild(underlineProp);
			}

			// Alignement verticale
			if (r.getVerticalAlignement() != VerticalAlignment.NONE) {
				Element vertAlignProp = rootDocument
						.createElement(RUN_VERTICAL_ALIGNEMENT_PROPERTY_TAG_NAME);
				Attr val = rootDocument
						.createAttribute(PROPERTIES_VALUE_TAG_NAME);
				val.setValue(r.verticalAlignement.toString());
				vertAlignProp.setAttributeNode(val);
				runProps.appendChild(vertAlignProp);
			}

			// Taille de la police
			Element fontSizeProp = rootDocument
					.createElement(RUN_FONT_SIZE_PROPERTY_TAG_NAME);
			Attr fontSizeVal = rootDocument
					.createAttribute(PROPERTIES_VALUE_TAG_NAME);
			fontSizeVal.setValue("" + r.fontSize);
			fontSizeProp.setAttributeNode(fontSizeVal);
			runProps.appendChild(fontSizeProp);

			// Le texte
			Element text = rootDocument.createElement(RUN_TEXT);
			if (r.getText().indexOf(" ") != -1) {
				Attr xmlSpacePreserve = rootDocument
						.createAttribute("xml:space");
				xmlSpacePreserve.setValue("preserve");
				text.setAttributeNode(xmlSpacePreserve);
			}
			run.appendChild(text);
			text.setTextContent(r.getText());
		}

		return paragraph;
	}

	/* Accesseurs */

	public ParagraphAlignment getAlignment() {
		return alignment;
	}

	public void setAlignment(ParagraphAlignment alignment) {
		this.alignment = alignment;
	}
}