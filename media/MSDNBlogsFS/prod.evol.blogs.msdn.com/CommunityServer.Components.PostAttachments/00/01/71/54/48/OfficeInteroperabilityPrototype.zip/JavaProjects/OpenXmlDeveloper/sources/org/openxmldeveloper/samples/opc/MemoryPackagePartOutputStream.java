package org.openxmldeveloper.samples.opc;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStream;

/**
 * Cr�� un flux de sortie pour les parties de type MemoryPackagePart.
 * 
 * @author Julien Chable
 */
public final class MemoryPackagePartOutputStream extends OutputStream {

	private MemoryPackagePart part;

	private ByteArrayOutputStream buff;

	public MemoryPackagePartOutputStream(MemoryPackagePart part) {
		this.part = part;
		buff = new ByteArrayOutputStream();
	}

	@Override
	public void write(int b) throws IOException {
		buff.write(b);
	}

	@Override
	public void close() throws IOException {
		this.flush();
	}

	@Override
	public void flush() throws IOException {
		buff.flush();
        if(part.data != null) {
			byte[] newArray = new byte[part.data.length + buff.size()];
			System.arraycopy(part.data, 0, newArray, 0, part.data.length);
			byte[] buffArr = buff.toByteArray();
			System.arraycopy(buffArr, 0, newArray, part.data.length, buffArr.length);
        }
	}

	@Override
	public void write(byte[] b, int off, int len) throws IOException {
		buff.write(b, off, len);
	}

	@Override
	public void write(byte[] b) throws IOException {
		buff.write(b);
	}
}