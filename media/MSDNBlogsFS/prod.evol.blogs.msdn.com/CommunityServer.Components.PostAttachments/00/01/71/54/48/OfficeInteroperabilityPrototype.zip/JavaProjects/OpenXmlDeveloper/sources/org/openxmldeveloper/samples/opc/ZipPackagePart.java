package org.openxmldeveloper.samples.opc;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URI;
import java.util.zip.ZipEntry;

public class ZipPackagePart extends PackagePart {

	private ZipEntry zipEntry;

	public ZipPackagePart(Package parent, URI partURI, String contentType) {
		super(parent, partURI, contentType);
	}

	public ZipPackagePart(Package parent, ZipEntry zipEntry, URI partURI,
			String contentType) {
		super(parent, partURI, contentType);
		this.zipEntry = zipEntry;
	}

	public ZipEntry getZipArchive() {
		return zipEntry;
	}

	@Override
	protected InputStream getInputStreamImpl() {
		try {
			// On utilise la m�thode getInputStream() de la classe
			// java.util.zip.ZipFile qui renvoie un InputStream vers le contenu
			// de l�entr�e donn�e en param�tre.
			return (container).getArchive().getInputStream(zipEntry);
		} catch (IOException e) {
			return null;
		}
	}

	@Override
	protected OutputStream getOutputStreamImpl() {
		return null;
	}

	@Override
	public void save(OutputStream os) {
		new ZipPartMarshaller().marshall(this, os);
	}
}