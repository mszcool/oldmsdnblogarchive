package org.openxmldeveloper.samples.opc;

import java.io.OutputStream;
import java.util.zip.ZipOutputStream;

public final class ZipPackageMarshaller extends ZipPartMarshaller {

	private Package pack;

	public ZipPackageMarshaller(Package pack) {
		this.pack = pack;
	}

	@Override
	public void marshall(PackagePart part, OutputStream os) {
		if (!(os instanceof ZipOutputStream))
			throw new IllegalArgumentException(
					"Le flux doit �tre un ZipOutputStream !");

		marshallRelationshipPart(pack.getRelationships(),
				PackageURIHelper.PACKAGE_RELATIONSHIPS_ROOT_URI,
				(ZipOutputStream) os);
	}
}