using System;
using System.Data;
using System.Configuration;
using System.Xml.Serialization;

using EUServices.NamespaceNames;
using System.Collections.Generic;

namespace Project.Entities
{
    [XmlType(Namespace=Constants.ProjectServiceEntityNamespace)]
    public class ProjectEntity
    {
        public ProjectEntity() { }

        public ProjectEntity(int id, string name, string descr, DateTime start, DateTime end)
        {
            ProjectID = id;
            ProjectName = name;
            Description = descr;
            StartDate = start;
            EndDate = end;
        }

        private int _ProjectId;
        public int ProjectID
        {
            get { return _ProjectId; }
            set { _ProjectId = value; }
        }

        private string _ProjectName;
        public string ProjectName
        {
            get { return _ProjectName; }
            set { _ProjectName = value; }
        }

        private string _Description;
        public string Description
        {
            get { return _Description; }
            set { _Description = value; }
        }

        private DateTime _StartDate;
        public DateTime StartDate
        {
            get { return _StartDate; }
            set { _StartDate = value; }
        }

        private DateTime _EndDate;
        public DateTime EndDate
        {
            get { return _EndDate; }
            set { _EndDate = value; }
        }
    }

    [XmlType(Namespace=Constants.ProjectServiceEntityNamespace)]
    public class ProjectEntities : List<ProjectEntity>
    {
    }

    [XmlType(Namespace=Constants.ProjectServiceEntityNamespace)]
    public class CategoryEntity
    {
        public CategoryEntity() { }

        public CategoryEntity(string id, string name)
        {
            CategoryID = id;
            CategoryName = name;
        }

        private string _CatID;
        public string CategoryID
        {
            get { return _CatID; }
            set { _CatID = value; }
        }

        private string _CategoryName;
        public string CategoryName
        {
            get { return _CategoryName; }
            set { _CategoryName = value; }
        }
    }

    [XmlType(Namespace = Constants.ProjectServiceEntityNamespace)]
    public class CategoryEntities : List<CategoryEntity>
    {
    }
}