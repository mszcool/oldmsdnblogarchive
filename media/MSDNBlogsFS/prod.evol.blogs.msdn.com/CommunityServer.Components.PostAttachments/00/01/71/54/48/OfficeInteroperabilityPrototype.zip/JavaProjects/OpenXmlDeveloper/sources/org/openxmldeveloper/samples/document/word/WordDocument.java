package org.openxmldeveloper.samples.document.word;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.openxmldeveloper.samples.document.OpenXMLDocument;
import org.openxmldeveloper.samples.opc.ContentTypeConstant;
import org.openxmldeveloper.samples.opc.InvalidFormatException;
import org.openxmldeveloper.samples.opc.Package;
import org.openxmldeveloper.samples.opc.PackagePart;
import org.openxmldeveloper.samples.opc.PackageRelationshipConstants;
import org.openxmldeveloper.samples.opc.PartMarshaller;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;


/**
 * Classe de manipulation du contenu d'un document Word 2007.
 * 
 * @author Julien Chable
 */
public final class WordDocument extends OpenXMLDocument {

	/**
	 * Le contenu du document.
	 */
	private Document content;

	/**
	 * Aide � la gestion du contenu du document.
	 */
	private MainDocumentHelper mainDocumentHelper;

	public WordDocument(Package pack) {
		super(pack);
		mainDocumentHelper = new MainDocumentHelper();
		mainDocumentHelper.parseDocumentContent();
		container.addMarshaller(ContentTypeConstant.WORD_MAIN_DOCUMENT,
				mainDocumentHelper);
	}

	/**
	 * Obtenir le contenu du document.
	 */
	public PackagePart getCorePart() {
		return container.getPartByRelationshipType(
				PackageRelationshipConstants.NS_CORE_DOCUMENT).get(0);
	}

	/**
	 * Permet d'obtenir l'arbre DOM du contenu du document.
	 */
	public Document getCoreDocument() {
		return content;
	}

	/**
	 * Sauvegarde du document.
	 */
	public void save(File destFile) {
		super.save(destFile);
	}

	/**
	 * Ajoute un paragraphe � la suite du document. Attention cette op�ration
	 * est irr�versible.
	 */
	public void appendParagraph(Paragraph paragraph) {
		Node body = content.getElementsByTagNameNS(WordprocessingML.NS_WORD12,
				"body").item(0);

		// On ins�re le paragraphe en dernier avant les autres noeuds fils du
		// corps.
		NodeList paragraphs = body.getChildNodes();
		for (int i = 0; i < paragraphs.getLength(); ++i) {
			Node curNode = paragraphs.item(i);
			if (curNode.getLocalName() != null
					&& !curNode.getLocalName().equals(
							Paragraph.BODY_PARAGRAPH_TAG_NAME)
					|| !curNode.getNodeName().equals(
							Paragraph.BODY_PARAGRAPH_TAG_NAME)) {
				body.insertBefore(paragraph.build(content), curNode);
				return;
			}
		}

		// Si tous les enfants du corps sont des paragraphes alors on l'ajoute �
		// la fin.
		body.appendChild(paragraph.build(content));
	}

	/**
	 * Classe d'aide pour g�rer la partie principale du contenu du document.
	 * 
	 * @author Julien Chable
	 */
	class MainDocumentHelper implements PartMarshaller {

		/**
		 * Parse le contenu du document.
		 */
		private void parseDocumentContent() {
			PackagePart contentPart = getCorePart();
			if (contentPart == null)
				throw new InvalidFormatException(
						"Le document ne poss�de pas de contenu !");

			// Obtention du flux de lecture
			InputStream inStream = null;
			try {
				inStream = contentPart.getInputStream();
			} catch (IOException e) {
				e.printStackTrace();
				return;
			}

			// Cr�ation du parser DOM
			DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory
					.newInstance();
			documentBuilderFactory.setNamespaceAware(true);
			DocumentBuilder documentBuilder;
			try {
				documentBuilder = documentBuilderFactory.newDocumentBuilder();

				// On parse le document XML en arbre DOM
				content = documentBuilder.parse(inStream);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		/**
		 * Enregistre le contenu principal du document dans le flux sp�cifi�.
		 */
		public void marshall(PackagePart part, OutputStream os) {
			if (!(os instanceof ZipOutputStream))
				throw new IllegalArgumentException(
						"Le flux doit �tre un ZipOutputSTream !");

			ZipOutputStream out = (ZipOutputStream) os;

			// Enregistrement de la partie dans le zip
			ZipEntry ctEntry = new ZipEntry(part.getUri().getPath());
			try {
				// Cr�ation de l'entr�e dans le fichier ZIP
				out.putNextEntry(ctEntry);
				DOMSource source = new DOMSource(content);
				StreamResult result = new StreamResult(out);
				TransformerFactory transFactory = TransformerFactory
						.newInstance();
				try {
					Transformer transformer = transFactory.newTransformer();
					// Si d�sactiv� permet de gagner de r�duire la taille du
					// fichier
					transformer.setOutputProperty(OutputKeys.INDENT, "yes");
					transformer.setOutputProperty(OutputKeys.STANDALONE, "yes");
					transformer.transform(source, result);
				} catch (TransformerException e) {
					System.err
							.println("Echec de l'enregistrement : impossible de cr�er le fichier "
									+ part.getUri());
				}
				// Fermeture de l'entr�e du fichier ZIP
				out.closeEntry();
			} catch (IOException e1) {
				System.err.println("");
			}
		}
	}
}