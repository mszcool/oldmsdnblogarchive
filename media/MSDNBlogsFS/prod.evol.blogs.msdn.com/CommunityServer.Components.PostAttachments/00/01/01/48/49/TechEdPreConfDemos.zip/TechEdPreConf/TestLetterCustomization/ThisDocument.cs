using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using Microsoft.VisualStudio.Tools.Applications.Runtime;
using Word = Microsoft.Office.Interop.Word;
using Office = Microsoft.Office.Core;

namespace TestLetterCustomization
{
    public partial class ThisDocument
    {
        private AddressContext adr = new AddressContext();
        private CustomerGeneral cust = new CustomerGeneral();
        private InterestControl inter = new InterestControl();

        private void ThisDocument_Startup(object sender, System.EventArgs e)
        {
            ActionsPane.Controls.Add(cust);
            ActionsPane.Controls.Add(adr);
            ActionsPane.Controls.Add(inter);

            adr.Visible = false;
            inter.Visible = false;
        }

        private void ThisDocument_Shutdown(object sender, System.EventArgs e)
        {
        }

        #region VSTO Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InternalStartup()
        {
            this.TechEdPreConfDocElementAddressContextNode.ContextEnter += new Microsoft.Office.Tools.Word.ContextChangeEventHandler(this.TechEdPreConfDocElementAddressContextNode_ContextEnter);
            this.TechEdPreConfDocElementAddressContextNode.ContextLeave += new Microsoft.Office.Tools.Word.ContextChangeEventHandler(this.TechEdPreConfDocElementAddressContextNode_ContextLeave);
            this.TechEdPreConfDocElementInterestContextNode.ContextEnter += new Microsoft.Office.Tools.Word.ContextChangeEventHandler(this.TechEdPreConfDocElementInterestContextNode_ContextEnter);
            this.TechEdPreConfDocElementInterestContextNode.ContextLeave += new Microsoft.Office.Tools.Word.ContextChangeEventHandler(this.TechEdPreConfDocElementInterestContextNode_ContextLeave);
            this.Startup += new System.EventHandler(this.ThisDocument_Startup);
            this.Shutdown += new System.EventHandler(this.ThisDocument_Shutdown);

        }

        #endregion

        private void TechEdPreConfDocElementAddressContextNode_ContextEnter(object sender, Microsoft.Office.Tools.Word.ContextChangeEventArgs e)
        {
            adr.Visible = true;
        }

        private void TechEdPreConfDocElementAddressContextNode_ContextLeave(object sender, Microsoft.Office.Tools.Word.ContextChangeEventArgs e)
        {
            adr.Visible = false;
        }

        private void TechEdPreConfDocElementInterestContextNode_ContextEnter(object sender, Microsoft.Office.Tools.Word.ContextChangeEventArgs e)
        {
            inter.Visible = true;
        }

        private void TechEdPreConfDocElementInterestContextNode_ContextLeave(object sender, Microsoft.Office.Tools.Word.ContextChangeEventArgs e)
        {
            inter.Visible = false;
        }
    }
}
