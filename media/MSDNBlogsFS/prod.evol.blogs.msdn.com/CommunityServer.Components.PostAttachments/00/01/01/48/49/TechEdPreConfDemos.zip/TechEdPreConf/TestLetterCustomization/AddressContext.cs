#region Using directives

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;

#endregion

namespace TestLetterCustomization
{
    partial class AddressContext : UserControl
    {
        public AddressContext()
        {
            InitializeComponent();
        }

        private void AddressContext_Load(object sender, EventArgs e)
        {
            webBrowser1.Navigate("http://localhost");
        }
    }
}
