using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace TestWPFControl
{
    /// <summary>
    /// Interaction logic for UserControl1.xaml
    /// </summary>

    public partial class UserControl1 : System.Windows.Controls.UserControl
    {
        public event EventHandler<StringEventArgs> SomethingSelected;

        public UserControl1()
        {
            InitializeComponent();
        }


        protected void MyButton_Click(object sender, RoutedEventArgs e)
        {
            TestList.Items.Add(MyTextBox.Text);

            if (SomethingSelected != null)
            {
                SomethingSelected(this,
                    new StringEventArgs(MyTextBox.Text));
            }
        }
    }


    public class StringEventArgs : EventArgs
    {
        private string _StringValue;

        public string StringValue
        {
            get { return _StringValue; }
            set { _StringValue = value; }
        }

        public StringEventArgs(string val)
        {
            this._StringValue = val;
        }
    }
}