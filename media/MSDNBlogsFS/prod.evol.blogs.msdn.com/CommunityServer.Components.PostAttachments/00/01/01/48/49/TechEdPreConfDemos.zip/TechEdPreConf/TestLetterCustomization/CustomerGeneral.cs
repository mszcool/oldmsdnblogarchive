#region Using directives

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;

#endregion

namespace TestLetterCustomization
{
    partial class CustomerGeneral : UserControl
    {
        public CustomerGeneral()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Globals.ThisDocument.TechEdPreConfDocElementFirstnameNode.Text = textBox1.Text;
            Globals.ThisDocument.TechEdPreConfDocElementLastnameNode.Text = textBox2.Text;
            Globals.ThisDocument.TechEdPreConfDocElementBirthdateNode.Text = dateTimePicker1.Value.ToString();
        }
    }
}
