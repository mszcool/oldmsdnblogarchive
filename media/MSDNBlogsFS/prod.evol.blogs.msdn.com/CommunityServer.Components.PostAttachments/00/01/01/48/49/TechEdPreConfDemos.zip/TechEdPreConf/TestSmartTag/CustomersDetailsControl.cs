#region Using directives

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;

#endregion

namespace TestSmartTag
{
    partial class CustomersDetailsControl : UserControl
    {
        public CustomersDetailsControl()
        {
            InitializeComponent();
        }

        public void InitCustomer(CustomersSet.CustomersRow row)
        {
            customersBindingSource.SuspendBinding();
            customersBindingSource.DataSource = row;
            customersBindingSource.ResumeBinding();
        }

        private void customersBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.customersBindingSource.EndEdit();
            this.customersTableAdapter.Update(this.customersSet.Customers);
        }
    }
}
