using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;

namespace TestTechEdLibrary
{
    public partial class UserControl1 : UserControl
    {
        public event EventHandler<SimpleCustomerSelectedEventArgs> CustomerSelected;

        public UserControl1()
        {
            InitializeComponent();
        }

        private void customersBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.customersBindingSource.EndEdit();
            this.customersTableAdapter.Update(this.northwind_mszDataSet.Customers);

        }

        private void UserControl1_Load(object sender, EventArgs e)
        {
            this.customersTableAdapter.Fill(northwind_mszDataSet.Customers);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (CustomerSelected != null)
            {
                Northwind_mszDataSet.CustomersRow row =
                    (customersBindingSource.Current as DataRowView).Row as Northwind_mszDataSet.CustomersRow;

                CustomerSelected(this,
                    new SimpleCustomerSelectedEventArgs(
                            row.CustomerID, row.ContactName, row.CompanyName));
            }
        }
    }

    public class SimpleCustomerSelectedEventArgs : EventArgs
    {
        private string _CustomerID;

        public string CustomerID
        {
            get { return _CustomerID; }
            set { _CustomerID = value; }
        }

        private string _ContactName;

        public string ContactName
        {
            get { return _ContactName; }
            set { _ContactName = value; }
        }

        private string _CompanyName;

        public string CompanyName
        {
            get { return _CompanyName; }
            set { _CompanyName = value; }
        }

        public SimpleCustomerSelectedEventArgs(
            string id, string contact, string company)
        {
            CustomerID = id;
            CompanyName = company;
            ContactName = contact;
        }
    }
}