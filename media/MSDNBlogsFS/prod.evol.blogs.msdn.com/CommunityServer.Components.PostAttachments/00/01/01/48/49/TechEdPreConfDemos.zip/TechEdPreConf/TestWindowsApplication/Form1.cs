using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace TestWindowsApplication
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void userControl11_CustomerSelected(object sender, TestTechEdLibrary.SimpleCustomerSelectedEventArgs e)
        {
            MessageBox.Show(
                string.Format("Customer Selected: {0} {1} {2}",
                        e.CustomerID, e.ContactName, e.CompanyName)
            );
        }
    }
}