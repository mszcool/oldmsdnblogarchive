using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using Microsoft.VisualStudio.Tools.Applications.Runtime;
using Word = Microsoft.Office.Interop.Word;
using Office = Microsoft.Office.Core;
using Microsoft.Office.Tools.Word;
using System.Windows.Forms.Integration;

namespace TestSmartTag
{
    public partial class ThisDocument
    {
        private TestTechEdLibrary.UserControl1 uc = new TestTechEdLibrary.UserControl1();

        private CustomersDetailsControl MyCustomerDetails = null;
        private CustomersSet.CustomersDataTable MyCustomers;

        private TestWPFControl.UserControl1 ucWPF = new TestWPFControl.UserControl1();

        private void ThisDocument_Startup(object sender, System.EventArgs e)
        {
            ActionsPane.Controls.Add(uc);
            uc.CustomerSelected += new EventHandler<TestTechEdLibrary.SimpleCustomerSelectedEventArgs>(uc_CustomerSelected);

            // Create our WPF Control now
            ElementHost host = new ElementHost();
            host.Height = 400;
            host.Child = ucWPF;
            ucWPF.SomethingSelected += new EventHandler<TestWPFControl.StringEventArgs>(ucWPF_SomethingSelected);

            ActionsPane.Controls.Add(host);



            // Load the customers from the database
            CustomersSetTableAdapters.CustomersTableAdapter adapter = new TestSmartTag.CustomersSetTableAdapters.CustomersTableAdapter();
            MyCustomers = adapter.GetData();

            // Create a smart tag for the customer numbers
            SmartTag CustomersTag = new SmartTag("http://teched2006preconf#Customers", "Customers");
            foreach (CustomersSet.CustomersRow row in MyCustomers)
            {
                CustomersTag.Terms.Add(row.CustomerID);
            }

            // Next create an action to show the details
            Action ShowDetailsAction = new Action("Show Details");
            ShowDetailsAction.Click += new ActionClickEventHandler(ShowDetailsAction_Click);
            CustomersTag.Actions = new Microsoft.Office.Tools.ActionBase[] { ShowDetailsAction };

            // Register the smart tag now
            VstoSmartTags.Add(CustomersTag);
        }

        void ucWPF_SomethingSelected(object sender, TestWPFControl.StringEventArgs e)
        {
            bookmark4.Text = e.StringValue;
        }

        void uc_CustomerSelected(object sender, TestTechEdLibrary.SimpleCustomerSelectedEventArgs e)
        {
            bookmark1.Text = e.CustomerID;
            bookmark2.Text = e.CompanyName;
            bookmark3.Text = e.ContactName;
        }

        void ShowDetailsAction_Click(object sender, 
            ActionEventArgs e)
        {
            // Show a user control in the actionspane
            if (MyCustomerDetails == null)
            {
                MyCustomerDetails = new CustomersDetailsControl();
                ActionsPane.Controls.Add(MyCustomerDetails);
            }

            // Get the currently selected customer
            CustomersSet.CustomersRow row = 
                MyCustomers.FindByCustomerID(e.Text);

            if (row != null)
            {
                MyCustomerDetails.InitCustomer(row);
            }
        }

        private void ThisDocument_Shutdown(object sender, System.EventArgs e)
        {
        }

        #region VSTO Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InternalStartup()
        {
            this.Startup += new System.EventHandler(ThisDocument_Startup);
            this.Shutdown += new System.EventHandler(ThisDocument_Shutdown);
        }

        #endregion
    }
}
