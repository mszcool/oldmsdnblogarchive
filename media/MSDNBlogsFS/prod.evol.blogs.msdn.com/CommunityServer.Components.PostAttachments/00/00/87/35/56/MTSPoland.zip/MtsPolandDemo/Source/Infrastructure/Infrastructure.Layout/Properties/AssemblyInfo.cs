﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("Infrastructure.Layout")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Microsoft Corporation")]
[assembly: AssemblyProduct("Infrastructure.Layout")]
[assembly: AssemblyCopyright("Copyright © Microsoft Corporation 2006")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(false)]
[assembly: Guid("aa255fa6-a678-4b1c-8e38-47cc902f667c")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
