using System;
using System.Web;
using System.Collections;
using System.Web.Services;
using System.Web.Services.Protocols;
using System.Collections.Generic;


/// <summary>
/// Summary description for ProductsService
/// </summary>
[WebService(Namespace = "http://www.microsoft.com/austria/demos/poland/mts/2006/11/cabsession")]
[WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
public class ProductsService : System.Web.Services.WebService
{
    public ProductsService()
    {

        //Uncomment the following line if using designed components 
        //InitializeComponent(); 
    }

    [WebMethod]
    public Messages.CategoriesResponseMessage GetCategories()
    {
        Messages.CategoriesResponseMessage response = new Messages.CategoriesResponseMessage();
        response.Categories = new List<Entities.Category>();

        // Get the categories from the backend
        CategoriesDataSet.CategoriesDataTable dt;
        CategoriesDataSetTableAdapters.CategoriesTableAdapter adapter = new CategoriesDataSetTableAdapters.CategoriesTableAdapter();

        dt = adapter.GetData();

        foreach (CategoriesDataSet.CategoriesRow row in dt)
        {
            Entities.Category entity = new Entities.Category();
            entity.CategoryName = row.CategoryName;
            entity.Id = row.CategoryID;
            entity.Description = row.Description;

            response.Categories.Add(entity);
        }

        return response;
    }

    [WebMethod]
    public Messages.ProductsResponseMessage GetProducts(Messages.ProductRequestMessage request)
    {
        Messages.ProductsResponseMessage response = new Messages.ProductsResponseMessage();
        response.Products = new List<Entities.Product>();

        ProductsDataSet.ProductsDataTable dt;
        ProductsDataSetTableAdapters.ProductsTableAdapter adapter = new ProductsDataSetTableAdapters.ProductsTableAdapter();
        dt = adapter.GetData(request.CategoryId);

        foreach (ProductsDataSet.ProductsRow row in dt)
        {
            Entities.Product entity = new Entities.Product();
            entity.CategoryId = row.CategoryID;
            entity.ProductId = row.ProductID;
            entity.ProductName = row.ProductName;
            entity.QuantityPerUnit = row.QuantityPerUnit;
            entity.ReorderLevel = row.ReorderLevel;
            entity.UnitPrice = row.UnitPrice;
            entity.UnitsInStock = row.UnitsInStock;
            entity.UnitsOnOrder = row.UnitsOnOrder;

            response.Products.Add(entity);
        }

        return response;
    }
}

namespace Entities
{
    public class Category
    {
        public int Id;
        public string CategoryName;
        public string Description;
    }

    public class Product
    {
        public int ProductId;
        public int CategoryId;
        public string ProductName;
        public string QuantityPerUnit;
        public decimal UnitPrice;
        public int UnitsInStock;
        public int UnitsOnOrder;
        public int ReorderLevel;
    }
}

namespace Messages
{
    public class ProductRequestMessage
    {
        public int CategoryId;
    }

    public class CategoriesResponseMessage
    {
        public List<Entities.Category> Categories;
    }

    public class ProductsResponseMessage
    {
        public List<Entities.Product> Products;
    }
}