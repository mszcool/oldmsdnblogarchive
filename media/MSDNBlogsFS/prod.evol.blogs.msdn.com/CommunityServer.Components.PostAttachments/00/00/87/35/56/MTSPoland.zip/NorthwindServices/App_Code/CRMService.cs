using System;
using System.Web;
using System.Collections;
using System.Web.Services;
using System.Web.Services.Protocols;
using System.Collections.Generic;


/// <summary>
/// Summary description for CRMService
/// </summary>
[WebService(Namespace = "http://www.microsoft.com/austria/demos/poland/mts/2006/11/cabsession")]
[WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
public class CRMService : System.Web.Services.WebService {

    public CRMService () {

        //Uncomment the following line if using designed components 
        //InitializeComponent(); 
    }

    [WebMethod]
    public Messages.CustomerResponseMessage GetCustomers(Messages.CustomerRequestMessage request)
    {
        Messages.CustomerResponseMessage response = new Messages.CustomerResponseMessage();

        CustomersDataSet.CustomersDataTable dt;
        CustomersDataSetTableAdapters.CustomersTableAdapter adapter = new CustomersDataSetTableAdapters.CustomersTableAdapter();
        if (request.Country != null)
            dt = adapter.GetDataByCountry(request.Country);
        else if (request.Region != null)
            dt = adapter.GetDataByRegion(request.Region);
        else
            dt = adapter.GetData();

        foreach (CustomersDataSet.CustomersRow row in dt)
        {
            Entities.Customer c = new Entities.Customer();
            c.Address = row.Address;
            c.City = row.City;
            c.CompanyName = row.CompanyName;
            c.ContactName = row.ContactName;
            c.ContactTitle = row.ContactTitle;
            c.Country = row.Country;
            c.CustomerId = row.CustomerID;
            c.Fax = (row.IsFaxNull() ? string.Empty : row.Fax);
            c.Phone = row.Phone;
            c.PostalCode = row.PostalCode;
            c.Region = (row.IsRegionNull() ? string.Empty : row.Region);

            response.Customers.Add(c);
        }

        return response;
    }
    
}

namespace Entities
{
    public class Customer
    {
        public string CustomerId;
        public string CompanyName;
        public string ContactName;
        public string ContactTitle;
        public string Address;
        public string City;
        public string Region;
        public string PostalCode;
        public string Country;
        public string Phone;
        public string Fax;
    }
}

namespace Messages
{
    public class CustomerRequestMessage
    {
        public string Region;
        public string Country;
    }

    public class CustomerResponseMessage 
    {
        public List<Entities.Customer> Customers;

        public CustomerResponseMessage()
        {
            this.Customers = new List<Entities.Customer>();
        }
    }
}