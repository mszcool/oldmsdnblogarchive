using System;
using System.Web;
using System.Collections;
using System.Web.Services;
using System.Web.Services.Protocols;
using System.Collections.Generic;


/// <summary>
/// Summary description for HRService
/// </summary>
[WebService(Namespace = "http://www.microsoft.com/austria/demos/poland/mts/2006/11/cabsession")]
[WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
public class HRService : System.Web.Services.WebService {

    public HRService () {

        //Uncomment the following line if using designed components 
        //InitializeComponent(); 
    }

    [WebMethod]
    public Messages.EmployeeResponseMessage GetEmployees()
    {
        Messages.EmployeeResponseMessage response = new Messages.EmployeeResponseMessage();

        EmployeesDataSet.EmployeesDataTable dt;
        EmployeesDataSetTableAdapters.EmployeesTableAdapter adapter = new EmployeesDataSetTableAdapters.EmployeesTableAdapter();
        dt = adapter.GetData();

        foreach (EmployeesDataSet.EmployeesRow row in dt)
        {
            Entities.Employee e = new Entities.Employee();
            e.Address = row.Address;
            e.BirthDate = row.BirthDate;
            e.City = row.City;
            e.Country = row.Country;
            e.EmployeeId = row.EmployeeID;
            e.Extension = row.Extension;
            e.Firstname = row.FirstName;
            e.HireDate = row.HireDate;
            e.HomePhone = row.HomePhone;
            e.Lastname = row.LastName;
            e.PostalCode = row.PostalCode;
            e.Title = row.Title;
            e.TitleOfCourtesy = row.TitleOfCourtesy;

            response.Employees.Add(e);
        }

        return response;
    }
    
}

namespace Entities
{
    public class Employee
    {
        public int EmployeeId;
        public string Lastname;
        public string Firstname;
        public string Title;
        public string TitleOfCourtesy;
        public DateTime BirthDate;
        public DateTime HireDate;
        public string Address;
        public string City;
        public string PostalCode;
        public string Country;
        public string HomePhone;
        public string Extension;
    }
}

namespace Messages
{
    public class EmployeeResponseMessage
    {
        public List<Entities.Employee> Employees;

        public EmployeeResponseMessage()
        {
            this.Employees = new List<Entities.Employee>();
        }
    }
}

