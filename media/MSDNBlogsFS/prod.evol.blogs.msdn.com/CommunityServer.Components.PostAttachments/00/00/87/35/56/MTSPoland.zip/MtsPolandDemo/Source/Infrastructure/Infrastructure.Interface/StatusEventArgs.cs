using System;
using System.Data;
using System.Configuration;

namespace MtsPoland.Infrastructure.Interface
{
    public class StatusEventArgs : EventArgs<string>
    {
        public StatusEventArgs(string data)
            : base(data)
        {
        }
    }
}
