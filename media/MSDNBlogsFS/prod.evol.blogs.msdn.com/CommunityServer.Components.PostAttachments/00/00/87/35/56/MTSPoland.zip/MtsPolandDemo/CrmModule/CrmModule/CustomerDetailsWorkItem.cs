using System;
using System.Windows.Forms;
using MtsPoland.Infrastructure.Interface;
using Microsoft.Practices.CompositeUI;
using Microsoft.Practices.CompositeUI.Commands;

namespace MtsPoland.CrmModule
{
    public class CustomerDetailsWorkItem : WorkItemController
    {
        private CustomerDetailsView _CustomerDetailsView;

        public void Initialize(CrmProxy.Customer customer)
        {
            WorkItem.State["CurrentCustomer"] = customer;
            _CustomerDetailsView = WorkItem.Items.AddNew<CustomerDetailsView>();
            Show();
        }

        public void Show()
        {
            WorkItem.Workspaces[
                Constants.WorkspaceNames.RightWorkspace
            ].Show(_CustomerDetailsView);
        }
    }
}
