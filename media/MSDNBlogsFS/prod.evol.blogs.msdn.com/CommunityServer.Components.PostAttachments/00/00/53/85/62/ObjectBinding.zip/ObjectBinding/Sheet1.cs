﻿using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using System.Collections.Generic;
using Microsoft.VisualStudio.Tools.Applications.Runtime;
using Excel = Microsoft.Office.Interop.Excel;
using Office = Microsoft.Office.Core;

namespace Demo3
{
    public partial class Sheet1
    {
        private List<SimplePerson> _Persons;

        private void Sheet1_Startup(object sender, System.EventArgs e)
        {
            _Persons = new List<SimplePerson>();
            for (int i = 0; i < 10; i++)
            {
                SimplePerson p = new SimplePerson();
                p.Firstname = "Person " + i.ToString();
                p.Lastname = "Lastname " + i.ToString();
                p.Birthdate = DateTime.Now.AddDays(i);

                _Persons.Add(p);
            }

            simplePersonBindingSource.SuspendBinding();
            simplePersonBindingSource.DataSource = _Persons;
            simplePersonBindingSource.ResumeBinding();
        }

        private void Sheet1_Shutdown(object sender, System.EventArgs e)
        {
        }

        #region VSTO Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InternalStartup()
        {
            this.firstnameNamedRange.Change += new Microsoft.Office.Interop.Excel.DocEvents_ChangeEventHandler(this.firstnameNamedRange_Change);
            this.lastnameNamedRange.Change += new Microsoft.Office.Interop.Excel.DocEvents_ChangeEventHandler(this.lastnameNamedRange_Change);
            this.Shutdown += new System.EventHandler(this.Sheet1_Shutdown);
            this.Startup += new System.EventHandler(this.Sheet1_Startup);

        }

        #endregion

        private void firstnameNamedRange_Change(Microsoft.Office.Interop.Excel.Range Target)
        {
            firstnameNamedRange.DataBindings[0].WriteValue();
        }

        private void lastnameNamedRange_Change(Microsoft.Office.Interop.Excel.Range Target)
        {
            lastnameNamedRange.DataBindings[0].WriteValue();
        }

    }
}
