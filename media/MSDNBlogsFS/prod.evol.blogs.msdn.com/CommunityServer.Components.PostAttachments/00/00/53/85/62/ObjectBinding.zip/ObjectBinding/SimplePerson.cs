using System;
using System.Collections.Generic;
using System.Text;

namespace Demo3
{
    [Serializable]
    public class SimplePerson
    {
        private string _Firstname;

        public string Firstname
        {
            get { return _Firstname; }
            set { _Firstname = value; }
        }

        private string _Lastname;

        public string Lastname
        {
            get { return _Lastname; }
            set { _Lastname = value; }
        }

        private DateTime _Birthdate;

        public DateTime Birthdate
        {
            get { return _Birthdate; }
            set { _Birthdate = value; }
        }
    }
}
