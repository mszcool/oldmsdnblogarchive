using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;
using System.Configuration;
using System.IO;
using System.Xml;

namespace TemplateDemo
{
    public partial class TemplateSelectionControl : UserControl
    {
        private Properties.Settings MySettings = new TemplateDemo.Properties.Settings();

        public TemplateSelectionControl()
        {
            InitializeComponent();
        }

        private void TemplateSelectionControl_Load(object sender, EventArgs e)
        {
            XmlDocument doc = new XmlDocument();

            // Load the templates from the templates directory
            DirectoryInfo TemplateDir = new DirectoryInfo(MySettings.TemplateDirectory);
            foreach (DirectoryInfo di in TemplateDir.GetDirectories())
            {
                // Read the template XML file
                doc.Load(di.FullName + "\\Template.xml");

                // Load details from XML
                string TemplateName = doc.SelectSingleNode("//Name").InnerText;
                string TemplateDescription = doc.SelectSingleNode("//Description").InnerText;
                Image img = Image.FromFile(di.FullName + "\\" + doc.SelectSingleNode("//Icon").InnerText);
                IconsImageList.Images.Add(img);

                // Create a new ListViewItem
                ListViewItem lvi = new ListViewItem(new string[] { TemplateName, TemplateDescription });
                lvi.ImageIndex = IconsImageList.Images.Count - 1;
                lvi.Tag = di.Name;

                // Add the item to the list
                TemplatesList.Items.Add(lvi);
            }
        }

        private void SelectTemplateCommand_Click(object sender, EventArgs e)
        {
            object start, end;
            object missing = System.Type.Missing;
            string TemplatePath = TemplatesList.SelectedItems[0].Tag as string;

            // Insert the header templates
            start = Globals.ThisDocument.HeaderBookmark.Start + 1;
            end = Globals.ThisDocument.HeaderBookmark.End - 1;
            Globals.ThisDocument.Range(ref start, ref end).Select();
            Globals.ThisDocument.Application.Selection.InsertFile(
                string.Format("{0}\\{1}\\Header.doc",
                                    MySettings.TemplateDirectory,
                                    TemplatePath
                ),
                ref missing, ref missing, ref missing, ref missing
            );

            // Insert the footer templates
            start = Globals.ThisDocument.CompanyFooterBookmark.Start + 1;
            end = Globals.ThisDocument.CompanyFooterBookmark.End - 1;
            Globals.ThisDocument.Range(ref start, ref end).Select();
            Globals.ThisDocument.Application.Selection.InsertFile(
                string.Format("{0}\\{1}\\Footer.doc",
                                    MySettings.TemplateDirectory,
                                    TemplatePath
                ),
                ref missing, ref missing, ref missing, ref missing
            );

            // Insert the logo templates
            // Logo is within a text box shape - so select ranges in shape
            Globals.ThisDocument.CompanyLogoBookmark.Range.Select();
            Globals.ThisDocument.Application.Selection.Start += 1;
            Globals.ThisDocument.Application.Selection.End -= 1;
            Globals.ThisDocument.Application.Selection.InsertFile(
                string.Format("{0}\\{1}\\Logo.doc",
                                    MySettings.TemplateDirectory,
                                    TemplatePath
                ),
                ref missing, ref missing, ref missing, ref missing
            );
        }

        private void TemplatesList_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
