namespace TemplateDemo
{
    partial class GeneralInfosControl
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.DocumentTitleText = new System.Windows.Forms.TextBox();
            this.DocumentSubTitleText = new System.Windows.Forms.TextBox();
            this.InsertCommand = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label3 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(3, 79);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(82, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Document Title:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(3, 102);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(104, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Document Sub Title:";
            // 
            // DocumentTitleText
            // 
            this.DocumentTitleText.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.DocumentTitleText.Location = new System.Drawing.Point(113, 76);
            this.DocumentTitleText.Name = "DocumentTitleText";
            this.DocumentTitleText.Size = new System.Drawing.Size(300, 20);
            this.DocumentTitleText.TabIndex = 2;
            // 
            // DocumentSubTitleText
            // 
            this.DocumentSubTitleText.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.DocumentSubTitleText.Location = new System.Drawing.Point(113, 102);
            this.DocumentSubTitleText.Multiline = true;
            this.DocumentSubTitleText.Name = "DocumentSubTitleText";
            this.DocumentSubTitleText.Size = new System.Drawing.Size(300, 124);
            this.DocumentSubTitleText.TabIndex = 3;
            // 
            // InsertCommand
            // 
            this.InsertCommand.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.InsertCommand.Location = new System.Drawing.Point(113, 232);
            this.InsertCommand.Name = "InsertCommand";
            this.InsertCommand.Size = new System.Drawing.Size(300, 25);
            this.InsertCommand.TabIndex = 4;
            this.InsertCommand.Text = "Insert Information";
            this.InsertCommand.UseVisualStyleBackColor = true;
            this.InsertCommand.Click += new System.EventHandler(this.InsertCommand_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox1.Image = global::TemplateDemo.Properties.Resources.FILECOPY_16;
            this.pictureBox1.Location = new System.Drawing.Point(113, 29);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(300, 41);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 5;
            this.pictureBox1.TabStop = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Verdana", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(3, 3);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(209, 23);
            this.label3.TabIndex = 6;
            this.label3.Text = "Templates Sample";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // GeneralInfosControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.label3);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.InsertCommand);
            this.Controls.Add(this.DocumentSubTitleText);
            this.Controls.Add(this.DocumentTitleText);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "GeneralInfosControl";
            this.Size = new System.Drawing.Size(416, 265);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox DocumentTitleText;
        private System.Windows.Forms.TextBox DocumentSubTitleText;
        private System.Windows.Forms.Button InsertCommand;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label3;
    }
}
