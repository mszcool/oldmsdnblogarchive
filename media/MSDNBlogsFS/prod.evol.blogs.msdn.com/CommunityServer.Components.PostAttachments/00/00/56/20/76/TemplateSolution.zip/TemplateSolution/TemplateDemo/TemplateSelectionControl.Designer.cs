namespace TemplateDemo
{
    partial class TemplateSelectionControl
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.SelectTemplateCommand = new System.Windows.Forms.Button();
            this.TemplatesList = new System.Windows.Forms.ListView();
            this.TemplateNameColumnHeader = new System.Windows.Forms.ColumnHeader();
            this.TemplateDescriptionColumnHeader = new System.Windows.Forms.ColumnHeader();
            this.IconsImageList = new System.Windows.Forms.ImageList(this.components);
            this.label3 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // SelectTemplateCommand
            // 
            this.SelectTemplateCommand.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.SelectTemplateCommand.Location = new System.Drawing.Point(135, 250);
            this.SelectTemplateCommand.Name = "SelectTemplateCommand";
            this.SelectTemplateCommand.Size = new System.Drawing.Size(178, 23);
            this.SelectTemplateCommand.TabIndex = 1;
            this.SelectTemplateCommand.Text = "Select Template";
            this.SelectTemplateCommand.UseVisualStyleBackColor = true;
            this.SelectTemplateCommand.Click += new System.EventHandler(this.SelectTemplateCommand_Click);
            // 
            // TemplatesList
            // 
            this.TemplatesList.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.TemplatesList.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.TemplateNameColumnHeader,
            this.TemplateDescriptionColumnHeader});
            this.TemplatesList.FullRowSelect = true;
            this.TemplatesList.HideSelection = false;
            this.TemplatesList.HoverSelection = true;
            this.TemplatesList.LargeImageList = this.IconsImageList;
            this.TemplatesList.Location = new System.Drawing.Point(3, 38);
            this.TemplatesList.Name = "TemplatesList";
            this.TemplatesList.Size = new System.Drawing.Size(310, 206);
            this.TemplatesList.SmallImageList = this.IconsImageList;
            this.TemplatesList.TabIndex = 2;
            this.TemplatesList.UseCompatibleStateImageBehavior = false;
            this.TemplatesList.View = System.Windows.Forms.View.Details;
            this.TemplatesList.SelectedIndexChanged += new System.EventHandler(this.TemplatesList_SelectedIndexChanged);
            // 
            // TemplateNameColumnHeader
            // 
            this.TemplateNameColumnHeader.Text = "Template Name";
            this.TemplateNameColumnHeader.Width = 129;
            // 
            // TemplateDescriptionColumnHeader
            // 
            this.TemplateDescriptionColumnHeader.Text = "Description";
            this.TemplateDescriptionColumnHeader.Width = 206;
            // 
            // IconsImageList
            // 
            this.IconsImageList.ColorDepth = System.Windows.Forms.ColorDepth.Depth8Bit;
            this.IconsImageList.ImageSize = new System.Drawing.Size(16, 16);
            this.IconsImageList.TransparentColor = System.Drawing.Color.Transparent;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(3, 12);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(161, 18);
            this.label3.TabIndex = 7;
            this.label3.Text = "Select a Template:";
            // 
            // TemplateSelectionControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.label3);
            this.Controls.Add(this.TemplatesList);
            this.Controls.Add(this.SelectTemplateCommand);
            this.Name = "TemplateSelectionControl";
            this.Size = new System.Drawing.Size(316, 281);
            this.Load += new System.EventHandler(this.TemplateSelectionControl_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button SelectTemplateCommand;
        private System.Windows.Forms.ListView TemplatesList;
        private System.Windows.Forms.ColumnHeader TemplateNameColumnHeader;
        private System.Windows.Forms.ColumnHeader TemplateDescriptionColumnHeader;
        private System.Windows.Forms.ImageList IconsImageList;
        private System.Windows.Forms.Label label3;
    }
}
