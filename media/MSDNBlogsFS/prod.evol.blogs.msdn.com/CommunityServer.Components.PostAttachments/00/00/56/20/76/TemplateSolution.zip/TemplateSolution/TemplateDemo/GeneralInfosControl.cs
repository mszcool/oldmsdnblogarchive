using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;

namespace TemplateDemo
{
    public partial class GeneralInfosControl : UserControl
    {
        public GeneralInfosControl()
        {
            InitializeComponent();
        }

        private void InsertCommand_Click(object sender, EventArgs e)
        {
            Globals.ThisDocument.DocumentTitleBookmark.Text = DocumentTitleText.Text;
            Globals.ThisDocument.DocumentSubTitleBookmark.Text = DocumentSubTitleText.Text;
            Globals.ThisDocument.PersonBookmark.Text =
                System.Security.Principal.WindowsIdentity.GetCurrent().Name;
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }
    }
}
