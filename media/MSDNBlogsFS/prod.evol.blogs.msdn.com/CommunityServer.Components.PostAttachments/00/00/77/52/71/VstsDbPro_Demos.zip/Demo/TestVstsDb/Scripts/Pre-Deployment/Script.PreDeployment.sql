﻿
SQLCMD :r .\Logins.sql

SQLCMD :r .\EncryptionKeysAndCertificates.sql

SQLCMD :r .\LinkedServers.sql

SQLCMD :r .\CustomErrors.sql
