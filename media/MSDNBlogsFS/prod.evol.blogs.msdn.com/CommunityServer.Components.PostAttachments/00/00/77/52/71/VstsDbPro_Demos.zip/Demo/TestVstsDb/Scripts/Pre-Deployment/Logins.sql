﻿IF NOT EXISTS(SELECT * FROM sys.syslogins WHERE NAME=N'devbase\Developer')
BEGIN
  CREATE LOGIN [devbase\Developer] FROM WINDOWS
END