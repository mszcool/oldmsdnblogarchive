﻿
sp_addrolemember N'db_owner', N'developer'
GO

SQLCMD :r .\Permissions.sql

SQLCMD :r .\RulesAndDefaults.sql

SQLCMD :r .\Signatures.sql
