﻿using System;
using System.Text;
using System.Data;
using System.Data.Common;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.VisualStudio.TeamSystem.Data.UnitTesting;
using Microsoft.VisualStudio.TeamSystem.Data.UnitTesting.Conditions;

namespace TestProject1
{
  [TestClass()]
  public class DatabaseUnitTest1 : DatabaseTestClass
  {

    public DatabaseUnitTest1()
    {
      InitializeComponent();
    }

    [TestInitialize()]
    public void TestInitialize()
    {
      base.InitializeTest();
    }
    [TestCleanup()]
    public void TestCleanup()
    {
      base.CleanupTest();
    }
    [TestMethod()]
    public void dbo_AddAuctionBetTest()
    {
      DatabaseTestActions testActions = this.dbo_AddAuctionBetTestData;
      // Execute the pre-test script
      // 
      System.Diagnostics.Trace.WriteLineIf((testActions.PretestAction != null), "Executing pre-test script...");
      ExecutionResult[] pretestResults = TestService.Execute(this.PrivilegedContext, this.PrivilegedContext, testActions.PretestAction);
      // Execute the test script
      // 
      System.Diagnostics.Trace.WriteLineIf((testActions.TestAction != null), "Executing test script...");
      ExecutionResult[] testResults = TestService.Execute(this.ExecutionContext, this.PrivilegedContext, testActions.TestAction);
      // Execute the post-test script
      // 
      System.Diagnostics.Trace.WriteLineIf((testActions.PosttestAction != null), "Executing post-test script...");
      ExecutionResult[] posttestResults = TestService.Execute(this.PrivilegedContext, this.PrivilegedContext, testActions.PosttestAction);
    }

    #region Designer support code

    /// <summary> 
    /// Required method for Designer support - do not modify 
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
      Microsoft.VisualStudio.TeamSystem.Data.UnitTesting.DatabaseTestAction dbo_AddAuctionBetTest_TestAction;
      System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DatabaseUnitTest1));
      this.dbo_AddAuctionBetTestData = new Microsoft.VisualStudio.TeamSystem.Data.UnitTesting.DatabaseTestActions();
      dbo_AddAuctionBetTest_TestAction = new Microsoft.VisualStudio.TeamSystem.Data.UnitTesting.DatabaseTestAction();
      // 
      // dbo_AddAuctionBetTest_TestAction
      // 
      resources.ApplyResources(dbo_AddAuctionBetTest_TestAction, "dbo_AddAuctionBetTest_TestAction");
      // 
      // dbo_AddAuctionBetTestData
      // 
      this.dbo_AddAuctionBetTestData.PosttestAction = null;
      this.dbo_AddAuctionBetTestData.PretestAction = null;
      this.dbo_AddAuctionBetTestData.TestAction = dbo_AddAuctionBetTest_TestAction;
    }

    #endregion


    #region Additional test attributes
    //
    // You can use the following additional attributes as you write your tests:
    //
    // Use ClassInitialize to run code before running the first test in the class
    // [ClassInitialize()]
    // public static void MyClassInitialize(TestContext testContext) { }
    //
    // Use ClassCleanup to run code after all tests in a class have run
    // [ClassCleanup()]
    // public static void MyClassCleanup() { }
    //
    #endregion

    private DatabaseTestActions dbo_AddAuctionBetTestData;
  }
}
