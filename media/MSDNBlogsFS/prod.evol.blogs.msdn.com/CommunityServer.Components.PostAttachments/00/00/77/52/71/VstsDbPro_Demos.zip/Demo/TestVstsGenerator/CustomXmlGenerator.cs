using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.VisualStudio.TeamSystem.Data.DataGenerator;
using System.Xml;
using Microsoft.VisualStudio.TeamSystem.Data.Generators;
using System.ComponentModel;

namespace TestVstsGenerator
{
  [Generator(typeof(DefaultGeneratorDesigner))]
  public class CustomXmlGenerator : Generator
  {
    public override string ToString()
    {
      return "Custom XML Generator";
    }

    [Output(Description="String Value with the XML", Name="XmlContent")]
    public string XmlOutput
    {
      get 
      {
        Random rnd = new Random();

        XmlDocument doc = new XmlDocument();
        doc.LoadXml("<sample />");

        for (int i = 0; i < rnd.Next(5, 10); i++)
        {
          XmlNode n = doc.CreateNode(XmlNodeType.Element, "node", string.Empty);
          n.InnerText = string.Format("Value {0}", i);

          doc.DocumentElement.AppendChild(n);
        }
        
        return doc.OuterXml;
      }
    }

    private int _InputCount;

    [Input(DefaultValue=10, Visible=true, ReadOnly=false)]
    public int ElementCount
    {
      get { return _InputCount; }
      set { _InputCount = value; }
    }
  }
}
