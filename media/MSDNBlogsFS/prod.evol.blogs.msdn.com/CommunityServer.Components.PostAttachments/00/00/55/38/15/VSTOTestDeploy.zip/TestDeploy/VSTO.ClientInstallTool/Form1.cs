using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Reflection;

using System.Security;
using System.Security.Principal;
using System.Security.Policy;
using System.Security.Permissions;

namespace VSTO.ClientInstallTool
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void BrowseToAssemblyCommand_Click(object sender, EventArgs e)
        {
            if (OpenAssemblyDialog.ShowDialog(this) == DialogResult.OK)
            {
                AssemblyPathText.Text = OpenAssemblyDialog.FileName;
            }
        }

        private void CreateCodeGroupsCommand_Click(object sender, EventArgs e)
        {
            try
            {
                WindowsPrincipal prin = new WindowsPrincipal(WindowsIdentity.GetCurrent());
                if (!prin.IsInRole(WindowsBuiltInRole.Administrator))
                {
                    MessageBox.Show(this, "You must be administrator to setup this type of policy!", "Admin rights required!", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    return;
                }

                // First of all extract the strong name from the assembly
                // WARNING: this should only be executed on trusted assemblies
                // This code is really supposed to be used in setup package creation, not in WinForms, 
                // this is really just a sample to demonstrate code, that you would use in a setup project
                // within Visual Studio in a trusted environment

                Assembly Asm = Assembly.LoadFrom(AssemblyPathText.Text);
                AssemblyName AsmName = Asm.GetName();
                byte[] StrongNameToken = AsmName.GetPublicKey();

                // No create the new code groups
                // Get the user's node in code access security configuration

                System.Collections.IEnumerator PolicyEnumerator = SecurityManager.PolicyHierarchy();
                while (PolicyEnumerator.MoveNext())
                {
                    // Get the current policy
                    PolicyLevel pl = (PolicyLevel)PolicyEnumerator.Current;
                    if (pl.Type == PolicyLevelType.Machine)
                    {
                        // Add the code groups to the user's level
                        CreatePolicyLevel(pl, StrongNameToken);

                        // Inform the user
                        MessageBox.Show(this,
                            "Successfully created security configuration. You can now run your solution!",
                            "Security Configuration Completed",
                            MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Unable to create code groups on client: " + ex.Message);
            }
        }

        private void CreatePolicyLevel(PolicyLevel pl, byte[] publicKey)
        {
            // Get the full trust permission set
            NamedPermissionSet FullTrustSet = null;
            foreach (NamedPermissionSet nsp in pl.NamedPermissionSets)
            {
                if (nsp.Name.Equals("FullTrust"))
                {
                    FullTrustSet = nsp;
                    break;
                }
            }

            if (FullTrustSet == null)
                throw new Exception("Unable to find FullTrust permission set!");

            // Create the code group for the strong name assembly
            StrongNameMembershipCondition SNMembership = 
                new StrongNameMembershipCondition(
                            new StrongNamePublicKeyBlob(publicKey), null, null
                );
            PolicyStatement PStmt = new PolicyStatement(FullTrustSet, PolicyStatementAttribute.Exclusive);
            UnionCodeGroup AssemblyCodeGroup = new UnionCodeGroup(SNMembership, PStmt);
            AssemblyCodeGroup.Name = "mszCool_" + Guid.NewGuid().ToString();

            // Create the code group for the document url
            UrlMembershipCondition UrlMembership =
                new UrlMembershipCondition(ServerDocumentURL.Text);
            PolicyStatement DocPStmt = new PolicyStatement(FullTrustSet, PolicyStatementAttribute.Exclusive);
            UnionCodeGroup DocumentCodeGroup = new UnionCodeGroup(UrlMembership, DocPStmt);
            DocumentCodeGroup.Name = "mszCool_" + Guid.NewGuid().ToString();

            // Add the code groups to the policy level
            pl.RootCodeGroup.AddChild(AssemblyCodeGroup);
            pl.RootCodeGroup.AddChild(DocumentCodeGroup);

            // Save the configuration
            SecurityManager.SavePolicyLevel(pl);
        }
    }
}