namespace VSTO.ServerInstallTool
{
    partial class VstoToolMainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.CreatePublishedDirCommand = new System.Windows.Forms.Button();
            this.SourceLegend = new System.Windows.Forms.Label();
            this.SourceDirectoryText = new System.Windows.Forms.TextBox();
            this.VirtualDirectoryText = new System.Windows.Forms.TextBox();
            this.VirtualDirectoryLegend = new System.Windows.Forms.Label();
            this.LogText = new System.Windows.Forms.TextBox();
            this.BrowseSourceDialog = new System.Windows.Forms.Button();
            this.SourceFolderBrowserDialog = new System.Windows.Forms.FolderBrowserDialog();
            this.AppManifestText = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // CreatePublishedDirCommand
            // 
            this.CreatePublishedDirCommand.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.CreatePublishedDirCommand.Location = new System.Drawing.Point(15, 84);
            this.CreatePublishedDirCommand.Name = "CreatePublishedDirCommand";
            this.CreatePublishedDirCommand.Size = new System.Drawing.Size(410, 30);
            this.CreatePublishedDirCommand.TabIndex = 0;
            this.CreatePublishedDirCommand.Text = "Prepare Published Directory";
            this.CreatePublishedDirCommand.UseVisualStyleBackColor = true;
            this.CreatePublishedDirCommand.Click += new System.EventHandler(this.CreatePublishedDirCommand_Click);
            // 
            // SourceLegend
            // 
            this.SourceLegend.AutoSize = true;
            this.SourceLegend.Location = new System.Drawing.Point(12, 9);
            this.SourceLegend.Name = "SourceLegend";
            this.SourceLegend.Size = new System.Drawing.Size(196, 13);
            this.SourceLegend.TabIndex = 1;
            this.SourceLegend.Text = "Source Directory (on destination server):";
            // 
            // SourceDirectoryText
            // 
            this.SourceDirectoryText.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.SourceDirectoryText.Location = new System.Drawing.Point(214, 6);
            this.SourceDirectoryText.Name = "SourceDirectoryText";
            this.SourceDirectoryText.Size = new System.Drawing.Size(179, 20);
            this.SourceDirectoryText.TabIndex = 2;
            // 
            // VirtualDirectoryText
            // 
            this.VirtualDirectoryText.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.VirtualDirectoryText.Location = new System.Drawing.Point(214, 32);
            this.VirtualDirectoryText.Name = "VirtualDirectoryText";
            this.VirtualDirectoryText.Size = new System.Drawing.Size(211, 20);
            this.VirtualDirectoryText.TabIndex = 4;
            // 
            // VirtualDirectoryLegend
            // 
            this.VirtualDirectoryLegend.AutoSize = true;
            this.VirtualDirectoryLegend.Location = new System.Drawing.Point(12, 35);
            this.VirtualDirectoryLegend.Name = "VirtualDirectoryLegend";
            this.VirtualDirectoryLegend.Size = new System.Drawing.Size(170, 13);
            this.VirtualDirectoryLegend.TabIndex = 3;
            this.VirtualDirectoryLegend.Text = "Virtual Directory (relative \'/yourdir\'):";
            // 
            // LogText
            // 
            this.LogText.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.LogText.Font = new System.Drawing.Font("Lucida Console", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LogText.Location = new System.Drawing.Point(15, 120);
            this.LogText.Multiline = true;
            this.LogText.Name = "LogText";
            this.LogText.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.LogText.Size = new System.Drawing.Size(404, 243);
            this.LogText.TabIndex = 5;
            this.LogText.WordWrap = false;
            // 
            // BrowseSourceDialog
            // 
            this.BrowseSourceDialog.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.BrowseSourceDialog.Location = new System.Drawing.Point(399, 6);
            this.BrowseSourceDialog.Name = "BrowseSourceDialog";
            this.BrowseSourceDialog.Size = new System.Drawing.Size(25, 20);
            this.BrowseSourceDialog.TabIndex = 6;
            this.BrowseSourceDialog.Text = "...";
            this.BrowseSourceDialog.UseVisualStyleBackColor = true;
            this.BrowseSourceDialog.Click += new System.EventHandler(this.BrowseSourceDialog_Click);
            // 
            // AppManifestText
            // 
            this.AppManifestText.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.AppManifestText.Location = new System.Drawing.Point(213, 58);
            this.AppManifestText.Name = "AppManifestText";
            this.AppManifestText.Size = new System.Drawing.Size(211, 20);
            this.AppManifestText.TabIndex = 8;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(11, 61);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(155, 13);
            this.label1.TabIndex = 7;
            this.label1.Text = "Application Manifest File-Name:";
            // 
            // VstoToolMainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(431, 375);
            this.Controls.Add(this.AppManifestText);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.BrowseSourceDialog);
            this.Controls.Add(this.LogText);
            this.Controls.Add(this.VirtualDirectoryText);
            this.Controls.Add(this.VirtualDirectoryLegend);
            this.Controls.Add(this.SourceDirectoryText);
            this.Controls.Add(this.SourceLegend);
            this.Controls.Add(this.CreatePublishedDirCommand);
            this.MinimumSize = new System.Drawing.Size(439, 409);
            this.Name = "VstoToolMainForm";
            this.Text = "VSTO 2005 - Update Published Directory Tool";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button CreatePublishedDirCommand;
        private System.Windows.Forms.Label SourceLegend;
        private System.Windows.Forms.TextBox SourceDirectoryText;
        private System.Windows.Forms.TextBox VirtualDirectoryText;
        private System.Windows.Forms.Label VirtualDirectoryLegend;
        private System.Windows.Forms.TextBox LogText;
        private System.Windows.Forms.Button BrowseSourceDialog;
        private System.Windows.Forms.FolderBrowserDialog SourceFolderBrowserDialog;
        private System.Windows.Forms.TextBox AppManifestText;
        private System.Windows.Forms.Label label1;
    }
}

