using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.IO;
using Microsoft.VisualStudio.Tools.Applications.Runtime;

namespace VSTO.ServerInstallTool
{
    public partial class VstoToolMainForm : Form
    {
        private string DestinationUrl = string.Empty;

        public VstoToolMainForm()
        {
            InitializeComponent();
        }

        private void CreatePublishedDirCommand_Click(object sender, EventArgs e)
        {
            if (Directory.Exists(SourceDirectoryText.Text))
            {
                LogText.Text = "Starting document updates...";

                // Get the destination URL
                DestinationUrl = string.Format("http://{0}/{1}",
                                                Environment.MachineName, VirtualDirectoryText.Text);
                if (!Uri.IsWellFormedUriString(DestinationUrl, UriKind.Absolute))
                {
                    MessageBox.Show("Invalid URI entered. Please enter virtual directory relative on publishing host, only!");
                    return;
                }

                // Verify if application manifest is valid
                if (AppManifestText.Text.Trim().Length == 0)
                    MessageBox.Show("Please enter an application manifest file name");

                // Process the directories
                ProcessDirectory(SourceDirectoryText.Text);

                LogText.AppendText("\r\n\r\nFinished document updates!");

                MessageBox.Show(this, "Directory prepared successfully. Now publish this directory on your server as " + DestinationUrl,
                    "TODO NOW: Publish your web directory!", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show(this, "Please enter a valid directory!", "Invalid directory", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
        }

        private void ProcessDirectory(string fullPath)
        {
            try
            {
                // Update manifests in all word documents or excel workbooks
                DirectoryInfo di = new DirectoryInfo(fullPath);
                FileInfo[] AllFiles = di.GetFiles();
                foreach (FileInfo fi in AllFiles)
                {
                    if (fi.Extension.Contains("xls") || fi.Extension.Contains("doc"))
                    {
                        UpdateDocumentManifest(fi.FullName);
                    }
                }

                // Now process the other sub directories
                DirectoryInfo[] SubDirs = di.GetDirectories();
                foreach (DirectoryInfo sdi in SubDirs)
                {
                    ProcessDirectory(sdi.FullName);
                }
            }
            catch (Exception ex)
            {
                LogText.AppendText(string.Format("\r\n!! Error processing {0} --> {1}", fullPath, ex.Message));
            }
        }

        private void UpdateDocumentManifest(string documentPath)
        {
            try
            {
                if (ServerDocument.IsCustomized(documentPath))
                {
                    LogText.AppendText(string.Format("\r\n\r\nProcessing {0}...", documentPath));

                    using (ServerDocument doc = new ServerDocument(documentPath))
                    {
                        LogText.AppendText(string.Format("\r\n-) Old path: {0}", doc.AppManifest.DeployManifestPath));

                        doc.AppManifest.DeployManifestPath = string.Format("{0}/{1}", DestinationUrl, AppManifestText.Text);

                        LogText.AppendText(string.Format("\r\n-) New path: {0}", doc.AppManifest.DeployManifestPath));

                        doc.Save();
                        doc.Close();
                    }

                    LogText.AppendText(string.Format("\r\nSuccessfully processed {0}...", documentPath));
                }
                else
                {
                    LogText.AppendText(string.Format("\r\nDocument '{0}' is not customized!", documentPath));
                }
            }
            catch (Exception ex)
            {
                LogText.AppendText(string.Format("\r\n!! Error processing {0} --> {1}", documentPath, ex.Message));
            }
        }

        private void BrowseSourceDialog_Click(object sender, EventArgs e)
        {
            if (SourceFolderBrowserDialog.ShowDialog(this) == DialogResult.OK)
            {
                SourceDirectoryText.Text = SourceFolderBrowserDialog.SelectedPath;
            }
        }
    }
}