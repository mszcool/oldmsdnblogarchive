
Partial Class TestMasterPage
    Inherits System.Web.UI.MasterPage


    Protected Sub SwitchSkinCommand_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles SwitchSkinCommand.Click

        If (SelectSkinList.SelectedIndex >= 0) Then
            Session("SelectedSkin") = SelectSkinList.SelectedValue
            Response.Redirect(Request.Url.ToString(), True)
        End If

    End Sub

End Class

