Imports Microsoft.VisualBasic
Imports System.Collections.Generic
Imports System.Web

Public Class PersonService

    Public Function GetPersons() As List(Of Person)

        Dim persons As List(Of Person) = New List(Of Person)

        If IsNothing(HttpContext.Current.Cache("PersonsList")) Then
            Dim rnd As New Random
            For i As Integer = 0 To rnd.Next(5, 10) Step 1

                Dim p As New Person
                p.PersonID = i
                p.Firstname = String.Format("First {0}", i)
                p.Lastname = String.Format("Last {0}", i)
                p.Age = (i + 1) * 2

                persons.Add(p)

            Next

            HttpContext.Current.Cache.Insert("PersonsList", persons, _
                    Nothing, DateTime.Now.AddMinutes(5), TimeSpan.Zero)
        Else

            persons = CType(HttpContext.Current.Cache("PersonsList"), List(Of Person))

        End If

        Return persons

    End Function

    Public Function GetPersons(ByVal pid As Integer) As Person

        Dim lp As List(Of Person) = Me.GetPersons()
        For i As Integer = 0 To lp.Count - 1 Step 1

            If (lp(i).PersonID.Equals(pid)) Then

                Return lp(i)

            End If

        Next

        Return Nothing

    End Function

    Public Sub UpdatePerson(ByVal p As Person)

        'Try to find the person
        Dim lp As List(Of Person) = Me.GetPersons()
        For i As Integer = 0 To lp.Count - 1 Step 1

            If (lp(i).PersonID.Equals(p.PersonID)) Then

                lp(i) = p
                Exit For

            End If

        Next

    End Sub

End Class
