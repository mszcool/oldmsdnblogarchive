
Partial Class SecondPage
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As EventArgs) Handles Me.Load

        If Not IsNothing(PreviousPage) Then

            If TypeOf Me.PreviousPage Is ICrossPagePostback Then

                Dim help As ICrossPagePostback = _
                        CType(Me.PreviousPage, ICrossPagePostback)
                TestPostBackData.Text = help.SomeData

            End If

        Else

            TestPostBackData.Text = "This is not a cross-page postback!"

        End If

    End Sub

    Protected Sub SwitchViewCommand_Click(ByVal sender As Object, ByVal e As EventArgs)

        If TestMultiView.ActiveViewIndex = 0 Then
            TestMultiView.ActiveViewIndex = 1
        Else
            TestMultiView.ActiveViewIndex = 0
        End If



    End Sub

End Class
