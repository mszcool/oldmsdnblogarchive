
Partial Class SecondContentPage
    Inherits System.Web.UI.Page

End Class
