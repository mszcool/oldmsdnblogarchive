Imports Microsoft.VisualBasic

Public Interface ICrossPagePostback

    ReadOnly Property SomeData() As String

End Interface
