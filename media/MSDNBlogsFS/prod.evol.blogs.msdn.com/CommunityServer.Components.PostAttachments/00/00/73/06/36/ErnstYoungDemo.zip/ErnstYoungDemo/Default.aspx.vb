
Partial Class _Default
    Inherits PageBaseTest
    Implements ICrossPagePostback

    Private Property WizardContent() As TestClass
        Get

            If IsNothing(Session("WizardContents")) Then

                Dim x As New TestClass
                Session("WizardContents") = x

            End If

            Return CType(Session("WizardContents"), TestClass)

        End Get

        Set(ByVal value As TestClass)
            Session("WizardContents") = value
        End Set
    End Property


    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        SomeContentCrossPage.Text = ConfigurationManager.ConnectionStrings("Northwind_mszConnectionString1").ConnectionString


        If Not Me.IsPostBack Then

            Dim RootItem As MenuItem
            RootItem = TestMenu.Items(0)

            Dim rnd As New Random

            For i As Integer = 0 To rnd.Next(5, 10)

                Dim m As New MenuItem
                m.Text = String.Format("Item {0}", i)
                RootItem.ChildItems.Add(m)

            Next

        End If

    End Sub

    Protected Sub TestMenu_MenuItemClick(ByVal sender As Object, _
                    ByVal e As System.Web.UI.WebControls.MenuEventArgs) Handles TestMenu.MenuItemClick

        SelectedMenuEntry.Text = String.Format("Menu {0} clicked!", e.Item.Text)

    End Sub

    Protected Sub CreateTreeCommand_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles CreateTreeCommand.Click

        TestTreeView.Nodes.Clear()

        Dim root As New TreeNode
        root.Text = "Root"
        TestTreeView.Nodes.Add(root)

        Dim count As Integer = Int32.Parse(TextBox1.Text)
        Dim depth As Integer = Int32.Parse(TextBox2.Text)

        CreateTreeNodes(root, count, depth)

    End Sub

    Private Sub CreateTreeNodes(ByRef parent As TreeNode, ByVal count As Integer, ByVal depth As Integer)


        ' Create the sub nodes and for each sub node create more sub nodes
        For i As Integer = 0 To count Step 1

            Dim node As New TreeNode
            node.Text = String.Format("Node {0}", i)
            parent.ChildNodes.Add(node)

            If depth > 0 Then

                CreateTreeNodes(node, count, depth - 1)

            End If

        Next


    End Sub

    Protected Sub TestWizard_FinishButtonClick(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.WizardNavigationEventArgs) Handles TestWizard.FinishButtonClick

        Me.WizardContent.SelectedDate = Calendar1.SelectedDate
        Me.WizardContent.SelectedText = _
                String.Format("{0} {1} {2}", _
                    TextBox4.Text, TextBox5.Text, TextBox3.Text)
        Me.WizardContent.SelectedListEntry = ListBox1.SelectedItem.Text

        ' Output something
        WizardOutCome.Text = String.Format("Wizard finished: {0}", DateTime.Now)


    End Sub

    Protected Sub TestWizard_ActiveStepChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles TestWizard.ActiveStepChanged



    End Sub

    Public ReadOnly Property SomeData() As String Implements ICrossPagePostback.SomeData
        Get
            Return SomeContentCrossPage.Text
        End Get
    End Property
End Class
