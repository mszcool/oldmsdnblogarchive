
Partial Class FirstContentPage
    Inherits PageBaseTest

End Class
