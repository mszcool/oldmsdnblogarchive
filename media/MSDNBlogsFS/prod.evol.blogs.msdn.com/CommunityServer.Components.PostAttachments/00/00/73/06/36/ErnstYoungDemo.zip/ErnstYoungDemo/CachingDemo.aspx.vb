Imports System.Data
Imports System.Data.SqlClient

Partial Class CachingDemo
    Inherits System.Web.UI.Page

    Private ds As DataSet

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If IsNothing(Cache("SomeData")) Then

            Response.Write("Loading Data...<br>")

            Dim conn As New SqlConnection()
            conn.ConnectionString = ConfigurationManager.ConnectionStrings("Northwind_mszConnectionString1").ConnectionString

            Dim da As New SqlDataAdapter("SELECT * FROM Categories", conn)
            ds = New DataSet
            da.Fill(ds, "Categories")

            Cache.Add("SomeData", ds, _
                     Nothing, DateTime.Now.AddMinutes(5), _
                     TimeSpan.Zero, CacheItemPriority.Default, Nothing)
        Else
            Response.Write("Data from cache!<br>")

            ds = CType(Cache("SomeData"), DataSet)
        End If

        TestCachingGrid1.DataSource = ds
        TestCachingGrid1.DataMember = "Categories"
        TestCachingGrid1.DataBind()

    End Sub

    Protected Sub SqlDataSource1_Selecting(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.SqlDataSourceSelectingEventArgs) Handles SqlDataSource1.Selecting
        Response.Write("Selecting from database...")
    End Sub
End Class
