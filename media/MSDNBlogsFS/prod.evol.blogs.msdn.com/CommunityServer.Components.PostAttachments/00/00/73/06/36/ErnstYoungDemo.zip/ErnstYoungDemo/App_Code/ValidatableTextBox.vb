Imports Microsoft.VisualBasic
Imports System.ComponentModel

Namespace ErnstYoung.Controls

    Public Class ValidatableTextBox
        Inherits TextBox

        Private _Required As Boolean
        <Category("ErnstYoung"), _
         Localizable(True)> _
        Public Property Required() As Boolean
            Get
                Return _Required
            End Get
            Set(ByVal value As Boolean)
                _Required = value
            End Set
        End Property

        Private _Expression As String = String.Empty
        <Category("ErnstYoung"), _
         Localizable(True)> _
        Public Property Expression() As String
            Get
                Return _Expression
            End Get
            Set(ByVal value As String)
                _Expression = value
            End Set
        End Property

        Private _RequiredErrorMessage As String = "*"
        <Category("ErnstYoung"), _
         Localizable(True)> _
        Public Property RequiredErrorMessage() As String
            Get
                Return _RequiredErrorMessage
            End Get
            Set(ByVal value As String)
                _RequiredErrorMessage = value
            End Set
        End Property

        Private _ExpressionErrorMessage As String = "!!"
        <Category("ErnstYoung"), _
         Localizable(True)> _
        Public Property ExpressionErrorMessage() As String
            Get
                Return _ExpressionErrorMessage
            End Get
            Set(ByVal value As String)
                _ExpressionErrorMessage = value
            End Set
        End Property


        Private RequiredValidator As RequiredFieldValidator
        Private ExpressionValidator As RegularExpressionValidator

        Protected Overrides Sub CreateChildControls()

            RequiredValidator = New RequiredFieldValidator()
            ExpressionValidator = New RegularExpressionValidator()

            RequiredValidator.ControlToValidate = Me.ID
            ExpressionValidator.ControlToValidate = Me.ID

            Controls.Add(RequiredValidator)
            Controls.Add(ExpressionValidator)

        End Sub

        Protected Overrides Sub OnPreRender(ByVal e As System.EventArgs)
            MyBase.OnPreRender(e)

            EnsureChildControls()

            RequiredValidator.Enabled = Me.Required
            RequiredValidator.ErrorMessage = Me.RequiredErrorMessage

            If _Expression.Equals(String.Empty) Then
                ExpressionValidator.Enabled = False
            Else
                ExpressionValidator.Enabled = True
                ExpressionValidator.ErrorMessage = Me.ExpressionErrorMessage
                ExpressionValidator.ValidationExpression = _Expression
            End If
        End Sub

        Public Overrides Sub RenderControl(ByVal writer As System.Web.UI.HtmlTextWriter)

            EnsureChildControls()

            MyBase.RenderControl(writer)
            RequiredValidator.RenderControl(writer)
            ExpressionValidator.RenderControl(writer)

        End Sub

    End Class

End Namespace

