
Partial Class EasyBinding
    Inherits System.Web.UI.Page

End Class
