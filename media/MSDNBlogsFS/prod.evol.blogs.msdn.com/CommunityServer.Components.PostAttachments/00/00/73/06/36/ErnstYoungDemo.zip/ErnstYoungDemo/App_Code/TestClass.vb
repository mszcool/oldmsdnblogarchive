Imports Microsoft.VisualBasic

Public Class TestClass

    Public SelectedDate As DateTime
    Public SelectedText As String
    Public SelectedListEntry As String

End Class
