Imports Microsoft.VisualBasic

Public Class PageBaseTest
    Inherits System.Web.UI.Page


    Protected Overrides Sub OnPreInit(ByVal e As System.EventArgs)
        MyBase.OnPreInit(e)

        ' Theme switched?
        If Not IsNothing(Session("SelectedSkin")) Then
            Page.Theme = Session("SelectedSkin").ToString()
        End If

    End Sub
End Class
