Imports Microsoft.VisualBasic

Public Class Person

    Private _PersonID As Integer
    Public Property PersonID() As Integer
        Get
            Return _PersonID
        End Get
        Set(ByVal value As Integer)
            _PersonID = value
        End Set
    End Property

    Private _Firstname As String
    Public Property Firstname() As String
        Get
            Return _Firstname
        End Get
        Set(ByVal value As String)
            _Firstname = value
        End Set
    End Property

    Private _Lastname As String
    Public Property Lastname() As String
        Get
            Return _Lastname
        End Get
        Set(ByVal value As String)
            _Lastname = value
        End Set
    End Property

    Private _Age As Int16
    Public Property Age() As Int16
        Get
            Return _Age
        End Get
        Set(ByVal value As Int16)
            _Age = value
        End Set
    End Property

End Class
