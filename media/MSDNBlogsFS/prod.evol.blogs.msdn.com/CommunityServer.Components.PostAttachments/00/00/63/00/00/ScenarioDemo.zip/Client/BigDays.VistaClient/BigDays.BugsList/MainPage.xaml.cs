using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

using BigDaysOfficeClient.BugRequestsProxy;

namespace BigDays.BugsList
{
    /// <summary>
    /// Interaction logic for Page1.xaml
    /// </summary>

    public partial class MainPage : Page
    {
        private Service BugRequestsService;
        private BugSummaryResponse BugSummaryResponse;

        public MainPage()
        {
            InitializeComponent();

            BugRequestsService = new Service();
            BugRequestsService.Credentials = System.Net.CredentialCache.DefaultCredentials;
        }

        protected void Page_Loaded(object sender, RoutedEventArgs e)
        {
            try
            {
                BugSummaryResponse = BugRequestsService.GetBugSummary();

                BugsList.Items.Clear();
                foreach (BugSummary s in BugSummaryResponse.Bugs)
                {
                    BugsList.Items.Add(s);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Unexpected error occured when calling Bug Requests Service: " + ex.Message,
                                "Unable to call Bug Requests Service", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        public void ShowDetailsCommand_Click(object sender, RoutedEventArgs e)
        {
            if (BugsList.SelectedItem != null)
            {
                BugSummary summary = BugsList.SelectedItem as BugSummary;

                BugDetails details = new BugDetails();
                details.InitializeBugContents(summary);
                details.Show();
            }
        }
    }
}
