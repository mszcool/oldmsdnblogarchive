using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

using BigDaysOfficeClient.BugRequestsProxy;
using System.Diagnostics;

namespace BigDays.BugsList
{
    /// <summary>
    /// Interaction logic for BugDetails.xaml
    /// </summary>

    public partial class BugDetails : Window
    {
        private Service BugsService;
        private BugSummary BugSummaryContent;
        private BugListResponse BugsOfMonth;
        
        public BugDetails()
        {
            InitializeComponent();

            BugsService = new Service();
            BugsService.Credentials = System.Net.CredentialCache.DefaultCredentials;
        }

        public void InitializeBugContents(BugSummary currentSummary)
        {
            this.BugSummaryContent = currentSummary;

            BugListRequest ListRequest = new BugListRequest();
            ListRequest.Month = currentSummary.Month;
            BugsOfMonth = BugsService.GetBugList(ListRequest);
        }

        protected void BugDetails_Loaded(object sender, RoutedEventArgs e)
        {
            TitleTextBlock.DataContext = BugSummaryContent;
            BugSummaryPanel.DataContext = BugSummaryContent;

            // Load the bug details for every entry
            foreach (BugListEntry entry in BugsOfMonth.Entries)
            {
                BugDetailsRequest DetailsRequest = new BugDetailsRequest();
                DetailsRequest.FileUrl = entry.FileUrl;
                BugDetailsResponse DetailsResponse = BugsService.GetBugDetails(DetailsRequest);

                BugDetailsControl bdc = new BugDetailsControl();
                bdc.InitializeBugDetails(DetailsResponse);

                Viewbox vb = new Viewbox();
                vb.Height = 200;
                vb.Width = 200;
                vb.Child = bdc;

                BugsListContent.Children.Add(vb);

                Binding b = new Binding("Value");
                b.ElementName = "MySlider";
                BindingOperations.SetBinding(vb, Viewbox.WidthProperty, b);
                BindingOperations.SetBinding(vb, Viewbox.HeightProperty, b);
            }

            BugsListContentViewer.SizeChanged += new SizeChangedEventHandler(BugsListContentViewer_SizeChanged);
        }

        void BugsListContentViewer_SizeChanged(object sender, SizeChangedEventArgs e)
        {
            UpdateWrapPanelView();
        }

        protected void MySlider_ValueChanged(object sender, RoutedEventArgs e)
        {
            UpdateWrapPanelView();
        }

        private void UpdateWrapPanelView()
        {
            try
            {
                if (((Viewbox)BugsListContent.Children[0]).Width >= BugsListContentViewer.ActualWidth)
                {
                    BugsListContent.MaxWidth = ((Viewbox)BugsListContent.Children[0]).Width;
                    BugsListContentViewer.HorizontalScrollBarVisibility = ScrollBarVisibility.Visible;
                }
                else
                {
                    BugsListContent.MaxWidth = BugsListContentViewer.ActualWidth;
                    BugsListContentViewer.HorizontalScrollBarVisibility = ScrollBarVisibility.Disabled;
                }
            }
            catch
            {
                if(BugsListContent != null && BugsListContentViewer != null)
                    BugsListContent.Width = BugsListContentViewer.ActualWidth;
            }
        }
    }
}

