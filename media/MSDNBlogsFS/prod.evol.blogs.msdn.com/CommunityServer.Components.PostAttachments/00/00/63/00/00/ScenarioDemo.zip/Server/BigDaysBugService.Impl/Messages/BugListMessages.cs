using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

/// <summary>
/// Summary description for BugListMessages
/// </summary>
namespace BigDaysBugService.Impl
{
    public class BugListRequest
    {
        public int Month;
        public string Employee;
    }

    public class BugListResponse
    {
        public BugListEntry[] Entries;
    }

    public class BugListEntry
    {
        public string FileUrl;
        public string Title;
        public string Priority;
        public DateTime SubmissionDate;
    }
}