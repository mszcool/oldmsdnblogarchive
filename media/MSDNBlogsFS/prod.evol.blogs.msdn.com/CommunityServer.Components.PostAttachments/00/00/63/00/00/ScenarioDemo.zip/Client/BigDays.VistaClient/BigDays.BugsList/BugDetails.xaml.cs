using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

using BigDaysOfficeClient.BugRequestsProxy;
using System.Diagnostics;
using System.Windows.Media.Animation;

namespace BigDays.BugsList
{
    /// <summary>
    /// Interaction logic for BugDetails.xaml
    /// </summary>

    public partial class BugDetails : Window
    {
        private Service BugsService;
        private BugSummary BugSummaryContent;
        private BugListResponse BugsOfMonth;
        
        public BugDetails()
        {
            InitializeComponent();

            BugsService = new Service();
            BugsService.Credentials = System.Net.CredentialCache.DefaultCredentials;
        }

        public void InitializeBugContents(BugSummary currentSummary)
        {
            this.BugSummaryContent = currentSummary;

            BugListRequest ListRequest = new BugListRequest();
            ListRequest.Month = currentSummary.Month;
            BugsOfMonth = BugsService.GetBugList(ListRequest);
        }

        protected void BugDetails_Loaded(object sender, RoutedEventArgs e)
        {
            //TitleTextBlock.DataContext = BugSummaryContent;
            BugSummaryPanel.DataContext = BugSummaryContent;

            // Load the bug details for every entry
            foreach (BugListEntry entry in BugsOfMonth.Entries)
            {
                BugDetailsRequest DetailsRequest = new BugDetailsRequest();
                DetailsRequest.FileUrl = entry.FileUrl;
                BugDetailsResponse DetailsResponse = BugsService.GetBugDetails(DetailsRequest);

                BugDetailsControl bdc = new BugDetailsControl();
                bdc.InitializeBugDetails(DetailsResponse);
                bdc.BugDetailsClicked += new EventHandler<BugDetailsControlClickedEventArgs>(bdc_BugDetailsClicked);

                Viewbox vb = new Viewbox();
                vb.Height = 200;
                vb.Width = 200;
                vb.Child = bdc;

                BugsListContent.Children.Add(vb);

                Binding b = new Binding("Value");
                b.ElementName = "MySlider";
                BindingOperations.SetBinding(vb, Viewbox.WidthProperty, b);
                BindingOperations.SetBinding(vb, Viewbox.HeightProperty, b);
            }

            BugsListContentViewer.SizeChanged += new SizeChangedEventHandler(BugsListContentViewer_SizeChanged);

            // Add the reflection on bottom
            ReflectionRectangle.Fill = new VisualBrush(RootGrid);
            ReflectionRectangle.Opacity = 0.3;
            //ReflectionRectangle.Fill = Brushes.Red;
        }

        BugDetailsControl DetailsControl = null;

        void bdc_BugDetailsClicked(object sender, BugDetailsControlClickedEventArgs e)
        {
            if (DetailsControl == null)
            {
                DetailsControl = new BugDetailsControl();
                DetailsDockPanel.Children.Clear();
                DetailsDockPanel.Children.Add(DetailsControl);
            }
            DetailsControl.InitializeBugDetails(e.SelectedBugDetails);

            // Now start the animation
            Storyboard sb = RootGrid.FindResource("DetailsFlyIn") as Storyboard;
            if (sb != null)
            {
                sb.Begin(RootGrid);
            }
        }

        void BugsListContentViewer_SizeChanged(object sender, SizeChangedEventArgs e)
        {
            UpdateWrapPanelView();
        }

        protected void MySlider_ValueChanged(object sender, RoutedEventArgs e)
        {
            UpdateWrapPanelView();
        }

        private void UpdateWrapPanelView()
        {
            try
            {
                if (((Viewbox)BugsListContent.Children[0]).Width >= BugsListContentViewer.ActualWidth)
                {
                    BugsListContent.MaxWidth = ((Viewbox)BugsListContent.Children[0]).Width;
                    BugsListContentViewer.HorizontalScrollBarVisibility = ScrollBarVisibility.Visible;
                }
                else
                {
                    BugsListContent.MaxWidth = BugsListContentViewer.ActualWidth;
                    BugsListContentViewer.HorizontalScrollBarVisibility = ScrollBarVisibility.Disabled;
                }
            }
            catch
            {
                if(BugsListContent != null && BugsListContentViewer != null)
                    BugsListContent.Width = BugsListContentViewer.ActualWidth;
            }
        }
    }
}

