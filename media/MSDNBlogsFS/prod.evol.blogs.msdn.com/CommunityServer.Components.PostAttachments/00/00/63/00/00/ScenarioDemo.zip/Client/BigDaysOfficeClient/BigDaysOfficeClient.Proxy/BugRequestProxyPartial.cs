using System;
using System.Collections.Generic;

namespace BigDaysOfficeClient.BugRequestsProxy
{
    using System.Xml;
    using System.Xml.Serialization;

    [System.Xml.Serialization.XmlRootAttribute(Namespace = "http://tempuri.org/BugRequest.xsd", IsNullable = false)]
    public partial class BugDetailsResponseDetails
    {
    }

    [System.Xml.Serialization.XmlRootAttribute(Namespace = "http://tempuri.org/BugRequest.xsd", IsNullable = false)]
    public partial class BugDetailsResponseDetailsReproSteps
    {
    }
}