using System;
using System.IO;
using System.Xml;
using System.ComponentModel;
using System.ComponentModel.Design;
using System.Collections;
using System.Drawing;
using System.Workflow.ComponentModel.Compiler;
using System.Workflow.ComponentModel.Serialization;
using System.Workflow.ComponentModel;
using System.Workflow.ComponentModel.Design;
using System.Workflow.Runtime;
using System.Workflow.Activities;
using System.Workflow.Activities.Rules;
using System.Xml.Serialization;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WorkflowActions;
using Microsoft.Office.Workflow.Utility;
using Microsoft.SharePoint.Workflow;

namespace BigDays.BugsWorkflow
{
	public sealed partial class BugWorkflow: SequentialWorkflowActivity
	{
		public BugWorkflow()
		{
			InitializeComponent();
		}

        //
        // Workflow general members
        //
        public Guid workflowId = default(System.Guid);
        public Microsoft.SharePoint.Workflow.SPWorkflowActivationProperties workflowProperties = new Microsoft.SharePoint.Workflow.SPWorkflowActivationProperties();

        //
        // Approval task members (when manager assigns a task)
        //
        public string ProjectManager;
        public string ApprovalAssignedTo;
        public string ApprovalPostpone;
        public string ApprovalComments;
        public Guid ApprovalTaskID = default(Guid);
        public SPWorkflowTaskProperties ApprovalTaskProps = new SPWorkflowTaskProperties();
        public SPWorkflowTaskProperties ApprovalTaskBeforeProps = new SPWorkflowTaskProperties();
        public SPWorkflowTaskProperties ApprovalTaskAfterProps = new SPWorkflowTaskProperties();

        //
        // Complete task members (when employee completes a task)
        //
        public string CompletionComments;
        public Guid CompleteTaskID = default(Guid);
        public SPWorkflowTaskProperties CompleteTaskProps = new SPWorkflowTaskProperties();
        public SPWorkflowTaskProperties CompleteTaskBeforeProps = new SPWorkflowTaskProperties();
        public SPWorkflowTaskProperties CompleteTaskAfterProps = new SPWorkflowTaskProperties();

        //
        // Workflow Implementation --------------------------------------------------------------------------
        //

        private void OnBugWorkflowActivated_Invoked(object sender, ExternalDataEventArgs e)
        {
            this.workflowId = workflowProperties.WorkflowId;

            XmlDocument doc = new XmlDocument();
            doc.LoadXml(workflowProperties.AssociationData);
            XmlNamespaceManager nsMgr = new XmlNamespaceManager(doc.NameTable);
            nsMgr.AddNamespace("my", "http://schemas.microsoft.com/office/infopath/2003/myXSD/2006-04-27T23:34:50");
            XmlNode node = doc.SelectSingleNode("//my:ProjectManager", nsMgr);
            this.ProjectManager = node.InnerText;
        }

        private void CreateApprovalTask_MethodInvoking(object sender, EventArgs e)
        {
            this.LoadDocument();
            string BugTitle = this.GetDocumentProperty("BugTitle");
            string BugDescription = this.GetDocumentProperty("Description");

            ApprovalTaskID = Guid.NewGuid();
            ApprovalTaskProps.AssignedTo = this.ProjectManager;
            ApprovalTaskProps.Description =
                string.Format("Please approve new Bug '{0}'", BugTitle);
            ApprovalTaskProps.Title = BugDescription;
            ApprovalTaskProps.TaskType = 0;
        }

        private void OnApprovalTaskChanged_Invoked(object sender, ExternalDataEventArgs e)
        {
            ApprovalPostpone = ApprovalTaskAfterProps.ExtendedProperties["ApprovalPostpone"].ToString();
            ApprovalAssignedTo = ApprovalTaskAfterProps.ExtendedProperties["ApprovalAssigendTo"].ToString();
            ApprovalComments = ApprovalTaskAfterProps.ExtendedProperties["ApprovalComments"].ToString();
        }

        private void BugPostponedAction_ExecuteCode(object sender, EventArgs e)
        {
            this.LoadDocument();
            this.UpdateDocumentProperty("State", "Postponed");
            this.SaveDocument();
        }

        private void UpdateBugDocument_ExecuteCode(object sender, EventArgs e)
        {
            // Now the bug is open, but assigned to an employee
            this.LoadDocument();
            this.UpdateDocumentProperty("AssignedTo", ApprovalAssignedTo);
            this.SaveDocument();
        }

        private void CreateCompletedTask_MethodInvoking(object sender, EventArgs e)
        {
            this.LoadDocument();
            string BugTitle = this.GetDocumentProperty("BugTitle");
            string BugDescription = this.GetDocumentProperty("Description");

            CompleteTaskID = Guid.NewGuid();
            CompleteTaskProps.AssignedTo = ApprovalAssignedTo;
            CompleteTaskProps.Title = string.Format("Please fix {0}!", BugTitle);
            CompleteTaskProps.Description = BugDescription + "(" + ApprovalComments + ")";
            CompleteTaskProps.TaskType = 1;
            CompleteTaskProps.ExtendedProperties["Comments"] = ApprovalComments;
        }

        private void OnCompletedTaskChanged_Invoked(object sender, ExternalDataEventArgs e)
        {
            CompletionComments = CompleteTaskAfterProps.ExtendedProperties["CompletionComments"].ToString();
        }

        private void CompleteCompletedTask_MethodInvoking(object sender, EventArgs e)
        {
            this.LoadDocument();
            this.UpdateDocumentProperty("State", "Closed");
            this.UpdateDocumentProperty("FixedDate", DateTime.Now.ToString("yyyy-MM-dd"));
            this.SaveDocument();
        }

        #region Document Helper

        private XmlDocument BugRequest = null;

        private void LoadDocument()
        {
            if (BugRequest != null)
                return;

            // Get the SharePoint document
            SPSite site = new SPSite(workflowProperties.SiteId);
            SPWeb web = site.AllWebs[workflowProperties.WebId];
            SPFile file = web.GetFile(workflowProperties.ItemUrl);

            // Load the document into the library
            BugRequest = new XmlDocument();
            using (Stream s = file.OpenBinaryStream())
            {
                BugRequest.Load(s);
            }
        }

        private void SaveDocument()
        {
            // Get the SharePoint document
            SPSite site = new SPSite(workflowProperties.SiteId);
            SPWeb web = site.AllWebs[workflowProperties.WebId];
            SPFile file = web.GetFile(workflowProperties.ItemUrl);

            // Create a MemoryStream to save the document
            MemoryStream ms = new MemoryStream();
            BugRequest.Save(ms);
            ms.Position = 0;

            // Save the document
            file.CheckOut();
            file.SaveBinary(ms);
            file.CheckIn("Updated by BigDays workflow " + DateTime.Now.ToString());
        }

        public string GetDocumentProperty(string propName)
        {
            XmlNamespaceManager BugRequestNsMgr;
            BugRequestNsMgr = new XmlNamespaceManager(BugRequest.NameTable);
            BugRequestNsMgr.AddNamespace(
                    "mstns",
                    "http://tempuri.org/BugRequest.xsd"
            );

            XmlNode node = BugRequest.SelectSingleNode("//mstns:" + propName, BugRequestNsMgr);
            return node.InnerText;
        }

        public void UpdateDocumentProperty(string propName, string propValue)
        {
            XmlNamespaceManager BugRequestNsMgr;
            BugRequestNsMgr = new XmlNamespaceManager(BugRequest.NameTable);
            BugRequestNsMgr.AddNamespace(
                    "mstns",
                    "http://tempuri.org/BugRequest.xsd"
            );

            XmlNode node = BugRequest.SelectSingleNode("//mstns:" + propName, BugRequestNsMgr);
            node.InnerText = propValue;
        }

        #endregion
	}

}
