using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

/// <summary>
/// Summary description for BugSummaryMessages
/// </summary>
namespace BigDaysBugService.Impl
{
    public class BugSummaryResponse
    {
        public BugSummary[] Bugs;
    }

    public class BugSummary
    {
        public int Month = 0;
        public int LowCount = 0;
        public int MediumCount = 0;
        public int HighCount = 0;
        public int CriticalCount = 0;
        public int OpenCount = 0;
        public int ClosedCount = 0;
    }
}