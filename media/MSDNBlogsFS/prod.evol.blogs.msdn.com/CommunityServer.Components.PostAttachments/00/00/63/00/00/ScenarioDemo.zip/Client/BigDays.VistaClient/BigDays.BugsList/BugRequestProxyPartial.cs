using System;
using System.IO;
using System.Reflection;
using System.Resources;
using System.Collections.Generic;

namespace BigDaysOfficeClient.BugRequestsProxy
{
    using System.Xml;
    using System.Xml.Serialization;
    using System.Windows.Media;
    using System.Windows.Media.Imaging;

    [System.Xml.Serialization.XmlRootAttribute(Namespace = "http://tempuri.org/BugRequest.xsd", IsNullable = false)]
    public partial class BugDetailsResponseDetails
    {
        public string FixedDateString 
        {
            get
            {
                return this.FixedDate.ToString("yyyy-MM-dd");
            }
        }

        public string SubmissionDateString
        {
            get
            {
                return this.SubmissionDate.ToString("yyyy-MM-dd");
            }
        }
    }

    [System.Xml.Serialization.XmlRootAttribute(Namespace = "http://tempuri.org/BugRequest.xsd", IsNullable = false)]
    public partial class BugDetailsResponseDetailsReproSteps
    {
    }

    public partial class BugSummary
    {
        private BitmapImage WpfImage = null;
        private string[] MonthNames = {"January", "February", "March", "April",
                                       "May", "June", "July", "August",
                                       "September", "October", "November", "December"};

        public string MonthName
        {
            get
            {
                return MonthNames[this.Month - 1];
            }
        }

        public BitmapImage SummaryImage
        {
            get
            {
                if (WpfImage == null)
                {
                    byte[] ImageBytes;
                    MemoryStream ImageBytesStream;

                    if (OpenCount > 0)
                    {
                        if (CriticalCount > 0)
                        {
                            ImageBytes = GetImageResource("Critical");
                        }
                        else
                        {
                            ImageBytes = GetImageResource("Open");
                        }
                    }
                    else
                    {
                        ImageBytes = GetImageResource("Closed");
                    }

                    ImageBytesStream = new MemoryStream(ImageBytes);

                    BitmapImage bi = new BitmapImage();
                    bi.BeginInit();
                    bi.CacheOption = BitmapCacheOption.OnLoad;
                    bi.CreateOptions = BitmapCreateOptions.DelayCreation;
                    bi.StreamSource = ImageBytesStream;
                    bi.EndInit();

                    WpfImage = bi;
                }

                return WpfImage;
            }
        }

        private byte[] GetImageResource(string name)
        {
            byte[] ret = null;
            string ResourceName = string.Format("BigDays.BugsList.Resources.{0}.ico", name);

            Assembly MyAssembly = Assembly.GetExecutingAssembly();
            using (Stream s = MyAssembly.GetManifestResourceStream(ResourceName))
            {
                ret = new byte[s.Length];
                s.Read(ret, 0, ret.Length);
            }

            return ret;
        }
    }
}