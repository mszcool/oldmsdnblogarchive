using System;
using System.Collections.Generic;
using System.Text;
using System.Runtime.InteropServices;

namespace BigDaysOfficeClient.TaskPanes
{
    [Guid("97FC166F-2265-4130-B4EB-778BDD3159F0")]
    public interface IBugListControl
    {
        void LoadBugLists(int month);
    }
}
