using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

using BigDaysOfficeClient.BugRequestsProxy;

namespace BigDays.BugsList
{
    /// <summary>
    /// Interaction logic for BugDetailsControl.xaml
    /// </summary>

    public partial class BugDetailsControl : UserControl
    {
        private BugDetailsResponse Details;

        public BugDetailsControl()
        {
            InitializeComponent();
        }

        public void InitializeBugDetails(BugDetailsResponse details)
        {
            this.Details = details;
        }

        protected void BugDetailsControl_Loaded(object sender, RoutedEventArgs e)
        {
            RootGrid.DataContext = this.Details.Details;
        }

        protected void PlayAgainCommand_Button(object sender, RoutedEventArgs e)
        {
            RequestAttachmentMediaElement.Play();
        }
    }
}