using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;
using BigDaysOfficeClient.BugRequestsProxy;

namespace BigDaysOfficeClient.TaskPanes
{
    public partial class BugListControl : UserControl, IBugListControl
    {
        private int Month = 0;
        private Service svc;

        public BugListControl()
        {
            InitializeComponent();

            svc = new Service();
            svc.Credentials = System.Net.CredentialCache.DefaultCredentials;
        }

        public void LoadBugLists(int month)
        {
            this.Month = month;

            // Get the bug list
            BugListRequest request = new BugListRequest();
            if (EveryMonthCheck.Checked)
                request.Month = 0;
            else
                request.Month = this.Month;

            if (OnlyMyCheck.Checked)
                request.Employee = System.Security.Principal.WindowsIdentity.GetCurrent().Name;
            else
                request.Employee = string.Empty;

            // Execute the request and fill the list
            BugListResponse response = svc.GetBugList(request);
            BugsListListView.Items.Clear();
            foreach (BugListEntry entry in response.Entries)
            {
                ListViewItem itm = new ListViewItem();
                itm.ImageIndex = 0;
                itm.Text = entry.Title;
                itm.SubItems.Add(entry.Priority);
                itm.SubItems.Add(entry.SubmissionDate.ToShortDateString());
                itm.Tag = entry;

                BugsListListView.Items.Add(itm);
            }
        }

        private void OnlyMyCheck_CheckedChanged(object sender, EventArgs e)
        {
            LoadBugLists(this.Month);
        }

        private void EveryMonthCheck_CheckedChanged(object sender, EventArgs e)
        {
            LoadBugLists(this.Month);
        }
    }
}
