using System;
using System.ComponentModel;
using System.ComponentModel.Design;
using System.Collections;
using System.Drawing;
using System.Reflection;
using System.Workflow.ComponentModel.Compiler;
using System.Workflow.ComponentModel.Serialization;
using System.Workflow.ComponentModel;
using System.Workflow.ComponentModel.Design;
using System.Workflow.Runtime;
using System.Workflow.Activities;
using System.Workflow.Activities.Rules;

namespace BigDays.BugsWorkflow
{
	public sealed partial class BugWorkflow
	{
		#region Designer generated code
		
		/// <summary> 
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
            this.CanModifyActivities = true;
            System.Workflow.Runtime.CorrelationToken correlationtoken1 = new System.Workflow.Runtime.CorrelationToken();
            System.Workflow.ComponentModel.ActivityBind activitybind1 = new System.Workflow.ComponentModel.ActivityBind();
            System.Workflow.ComponentModel.ActivityBind activitybind2 = new System.Workflow.ComponentModel.ActivityBind();
            System.Workflow.ComponentModel.ActivityBind activitybind3 = new System.Workflow.ComponentModel.ActivityBind();
            System.Workflow.ComponentModel.ActivityBind activitybind4 = new System.Workflow.ComponentModel.ActivityBind();
            System.Workflow.ComponentModel.ActivityBind activitybind5 = new System.Workflow.ComponentModel.ActivityBind();
            System.Workflow.ComponentModel.ActivityBind activitybind6 = new System.Workflow.ComponentModel.ActivityBind();
            System.Workflow.ComponentModel.ActivityBind activitybind7 = new System.Workflow.ComponentModel.ActivityBind();
            System.Workflow.Activities.Rules.RuleConditionReference ruleconditionreference1 = new System.Workflow.Activities.Rules.RuleConditionReference();
            System.Workflow.Runtime.CorrelationToken correlationtoken2 = new System.Workflow.Runtime.CorrelationToken();
            System.Workflow.ComponentModel.ActivityBind activitybind8 = new System.Workflow.ComponentModel.ActivityBind();
            System.Workflow.ComponentModel.ActivityBind activitybind9 = new System.Workflow.ComponentModel.ActivityBind();
            System.Workflow.ComponentModel.ActivityBind activitybind10 = new System.Workflow.ComponentModel.ActivityBind();
            System.Workflow.ComponentModel.ActivityBind activitybind11 = new System.Workflow.ComponentModel.ActivityBind();
            System.Workflow.ComponentModel.ActivityBind activitybind12 = new System.Workflow.ComponentModel.ActivityBind();
            System.Workflow.ComponentModel.ActivityBind activitybind13 = new System.Workflow.ComponentModel.ActivityBind();
            System.Workflow.ComponentModel.ActivityBind activitybind14 = new System.Workflow.ComponentModel.ActivityBind();
            System.Workflow.Runtime.CorrelationToken correlationtoken3 = new System.Workflow.Runtime.CorrelationToken();
            System.Workflow.ComponentModel.ActivityBind activitybind15 = new System.Workflow.ComponentModel.ActivityBind();
            System.Workflow.ComponentModel.ActivityBind activitybind16 = new System.Workflow.ComponentModel.ActivityBind();
            this.CompleteCompletedTask = new Microsoft.SharePoint.WorkflowActions.CompleteTask();
            this.OnCompletedTaskChanged = new Microsoft.SharePoint.WorkflowActions.OnTaskChanged();
            this.CreateCompletedTask = new Microsoft.SharePoint.WorkflowActions.CreateTask();
            this.UpdateBugDocument = new System.Workflow.Activities.CodeActivity();
            this.BugPostponedAction = new System.Workflow.Activities.CodeActivity();
            this.ifElseBranchActivity2 = new System.Workflow.Activities.IfElseBranchActivity();
            this.ifElseBranchActivity1 = new System.Workflow.Activities.IfElseBranchActivity();
            this.CompleteApprovalTask = new Microsoft.SharePoint.WorkflowActions.CompleteTask();
            this.IfBugPostponed = new System.Workflow.Activities.IfElseActivity();
            this.OnApprovalTaskChanged = new Microsoft.SharePoint.WorkflowActions.OnTaskChanged();
            this.CreateApprovalTask = new Microsoft.SharePoint.WorkflowActions.CreateTask();
            this.OnBugWorkflowActivated = new Microsoft.SharePoint.WorkflowActions.OnWorkflowActivated();
            // 
            // CompleteCompletedTask
            // 
            correlationtoken1.Name = "CompletionTask";
            correlationtoken1.OwnerActivityName = "BugWorkflow";
            this.CompleteCompletedTask.CorrelationToken = correlationtoken1;
            this.CompleteCompletedTask.Name = "CompleteCompletedTask";
            activitybind1.Name = "BugWorkflow";
            activitybind1.Path = "CompleteTaskID";
            activitybind2.Name = "BugWorkflow";
            activitybind2.Path = "CompletionComments";
            this.CompleteCompletedTask.MethodInvoking += new System.EventHandler(this.CompleteCompletedTask_MethodInvoking);
            this.CompleteCompletedTask.SetBinding(Microsoft.SharePoint.WorkflowActions.CompleteTask.TaskIdProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind1)));
            this.CompleteCompletedTask.SetBinding(Microsoft.SharePoint.WorkflowActions.CompleteTask.TaskOutcomeProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind2)));
            // 
            // OnCompletedTaskChanged
            // 
            activitybind3.Name = "BugWorkflow";
            activitybind3.Path = "CompleteTaskAfterProps";
            activitybind4.Name = "BugWorkflow";
            activitybind4.Path = "CompleteTaskBeforeProps";
            this.OnCompletedTaskChanged.CorrelationToken = correlationtoken1;
            this.OnCompletedTaskChanged.Executor = null;
            this.OnCompletedTaskChanged.Name = "OnCompletedTaskChanged";
            activitybind5.Name = "BugWorkflow";
            activitybind5.Path = "CompleteTaskID";
            this.OnCompletedTaskChanged.Invoked += new System.EventHandler<System.Workflow.Activities.ExternalDataEventArgs>(this.OnCompletedTaskChanged_Invoked);
            this.OnCompletedTaskChanged.SetBinding(Microsoft.SharePoint.WorkflowActions.OnTaskChanged.TaskIdProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind5)));
            this.OnCompletedTaskChanged.SetBinding(Microsoft.SharePoint.WorkflowActions.OnTaskChanged.BeforePropertiesProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind4)));
            this.OnCompletedTaskChanged.SetBinding(Microsoft.SharePoint.WorkflowActions.OnTaskChanged.AfterPropertiesProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind3)));
            // 
            // CreateCompletedTask
            // 
            this.CreateCompletedTask.CorrelationToken = correlationtoken1;
            this.CreateCompletedTask.Name = "CreateCompletedTask";
            this.CreateCompletedTask.SpecialPermissions = null;
            activitybind6.Name = "BugWorkflow";
            activitybind6.Path = "CompleteTaskID";
            activitybind7.Name = "BugWorkflow";
            activitybind7.Path = "CompleteTaskProps";
            this.CreateCompletedTask.MethodInvoking += new System.EventHandler(this.CreateCompletedTask_MethodInvoking);
            this.CreateCompletedTask.SetBinding(Microsoft.SharePoint.WorkflowActions.CreateTask.TaskIdProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind6)));
            this.CreateCompletedTask.SetBinding(Microsoft.SharePoint.WorkflowActions.CreateTask.TaskPropertiesProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind7)));
            // 
            // UpdateBugDocument
            // 
            this.UpdateBugDocument.Name = "UpdateBugDocument";
            this.UpdateBugDocument.ExecuteCode += new System.EventHandler(this.UpdateBugDocument_ExecuteCode);
            // 
            // BugPostponedAction
            // 
            this.BugPostponedAction.Name = "BugPostponedAction";
            this.BugPostponedAction.ExecuteCode += new System.EventHandler(this.BugPostponedAction_ExecuteCode);
            // 
            // ifElseBranchActivity2
            // 
            this.ifElseBranchActivity2.Activities.Add(this.UpdateBugDocument);
            this.ifElseBranchActivity2.Activities.Add(this.CreateCompletedTask);
            this.ifElseBranchActivity2.Activities.Add(this.OnCompletedTaskChanged);
            this.ifElseBranchActivity2.Activities.Add(this.CompleteCompletedTask);
            this.ifElseBranchActivity2.Name = "ifElseBranchActivity2";
            // 
            // ifElseBranchActivity1
            // 
            this.ifElseBranchActivity1.Activities.Add(this.BugPostponedAction);
            ruleconditionreference1.ConditionName = "Condition1";
            this.ifElseBranchActivity1.Condition = ruleconditionreference1;
            this.ifElseBranchActivity1.Name = "ifElseBranchActivity1";
            // 
            // CompleteApprovalTask
            // 
            correlationtoken2.Name = "ApprovalTask";
            correlationtoken2.OwnerActivityName = "BugWorkflow";
            this.CompleteApprovalTask.CorrelationToken = correlationtoken2;
            this.CompleteApprovalTask.Name = "CompleteApprovalTask";
            activitybind8.Name = "BugWorkflow";
            activitybind8.Path = "ApprovalTaskID";
            activitybind9.Name = "BugWorkflow";
            activitybind9.Path = "ApprovalComments";
            this.CompleteApprovalTask.SetBinding(Microsoft.SharePoint.WorkflowActions.CompleteTask.TaskIdProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind8)));
            this.CompleteApprovalTask.SetBinding(Microsoft.SharePoint.WorkflowActions.CompleteTask.TaskOutcomeProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind9)));
            // 
            // IfBugPostponed
            // 
            this.IfBugPostponed.Activities.Add(this.ifElseBranchActivity1);
            this.IfBugPostponed.Activities.Add(this.ifElseBranchActivity2);
            this.IfBugPostponed.Name = "IfBugPostponed";
            // 
            // OnApprovalTaskChanged
            // 
            activitybind10.Name = "BugWorkflow";
            activitybind10.Path = "ApprovalTaskAfterProps";
            activitybind11.Name = "BugWorkflow";
            activitybind11.Path = "ApprovalTaskBeforeProps";
            this.OnApprovalTaskChanged.CorrelationToken = correlationtoken2;
            this.OnApprovalTaskChanged.Executor = null;
            this.OnApprovalTaskChanged.Name = "OnApprovalTaskChanged";
            activitybind12.Name = "BugWorkflow";
            activitybind12.Path = "ApprovalTaskID";
            this.OnApprovalTaskChanged.Invoked += new System.EventHandler<System.Workflow.Activities.ExternalDataEventArgs>(this.OnApprovalTaskChanged_Invoked);
            this.OnApprovalTaskChanged.SetBinding(Microsoft.SharePoint.WorkflowActions.OnTaskChanged.TaskIdProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind12)));
            this.OnApprovalTaskChanged.SetBinding(Microsoft.SharePoint.WorkflowActions.OnTaskChanged.BeforePropertiesProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind11)));
            this.OnApprovalTaskChanged.SetBinding(Microsoft.SharePoint.WorkflowActions.OnTaskChanged.AfterPropertiesProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind10)));
            // 
            // CreateApprovalTask
            // 
            this.CreateApprovalTask.CorrelationToken = correlationtoken2;
            this.CreateApprovalTask.Name = "CreateApprovalTask";
            this.CreateApprovalTask.SpecialPermissions = null;
            activitybind13.Name = "BugWorkflow";
            activitybind13.Path = "ApprovalTaskID";
            activitybind14.Name = "BugWorkflow";
            activitybind14.Path = "ApprovalTaskProps";
            this.CreateApprovalTask.MethodInvoking += new System.EventHandler(this.CreateApprovalTask_MethodInvoking);
            this.CreateApprovalTask.SetBinding(Microsoft.SharePoint.WorkflowActions.CreateTask.TaskIdProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind13)));
            this.CreateApprovalTask.SetBinding(Microsoft.SharePoint.WorkflowActions.CreateTask.TaskPropertiesProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind14)));
            // 
            // OnBugWorkflowActivated
            // 
            correlationtoken3.Name = "workflowToken";
            correlationtoken3.OwnerActivityName = "BugWorkflow";
            this.OnBugWorkflowActivated.CorrelationToken = correlationtoken3;
            this.OnBugWorkflowActivated.EventName = "OnWorkflowActivated";
            this.OnBugWorkflowActivated.Name = "OnBugWorkflowActivated";
            activitybind15.Name = "BugWorkflow";
            activitybind15.Path = "workflowId";
            activitybind16.Name = "BugWorkflow";
            activitybind16.Path = "workflowProperties";
            this.OnBugWorkflowActivated.Invoked += new System.EventHandler<System.Workflow.Activities.ExternalDataEventArgs>(this.OnBugWorkflowActivated_Invoked);
            this.OnBugWorkflowActivated.SetBinding(Microsoft.SharePoint.WorkflowActions.OnWorkflowActivated.WorkflowIdProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind15)));
            this.OnBugWorkflowActivated.SetBinding(Microsoft.SharePoint.WorkflowActions.OnWorkflowActivated.WorkflowPropertiesProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind16)));
            // 
            // BugWorkflow
            // 
            this.Activities.Add(this.OnBugWorkflowActivated);
            this.Activities.Add(this.CreateApprovalTask);
            this.Activities.Add(this.OnApprovalTaskChanged);
            this.Activities.Add(this.IfBugPostponed);
            this.Activities.Add(this.CompleteApprovalTask);
            this.Name = "BugWorkflow";
            this.Completed += new System.EventHandler(this.CreateApprovalTask_MethodInvoking);
            this.CanModifyActivities = false;

		}

		#endregion

        private Microsoft.SharePoint.WorkflowActions.CreateTask CreateApprovalTask;
        private Microsoft.SharePoint.WorkflowActions.OnTaskChanged OnApprovalTaskChanged;
        private IfElseBranchActivity ifElseBranchActivity2;
        private IfElseBranchActivity ifElseBranchActivity1;
        private IfElseActivity IfBugPostponed;
        private CodeActivity BugPostponedAction;
        private CodeActivity UpdateBugDocument;
        private Microsoft.SharePoint.WorkflowActions.CreateTask CreateCompletedTask;
        private Microsoft.SharePoint.WorkflowActions.OnTaskChanged OnCompletedTaskChanged;
        private Microsoft.SharePoint.WorkflowActions.CompleteTask CompleteCompletedTask;
        private Microsoft.SharePoint.WorkflowActions.CompleteTask CompleteApprovalTask;
        private Microsoft.SharePoint.WorkflowActions.OnWorkflowActivated OnBugWorkflowActivated;







































    }
}
