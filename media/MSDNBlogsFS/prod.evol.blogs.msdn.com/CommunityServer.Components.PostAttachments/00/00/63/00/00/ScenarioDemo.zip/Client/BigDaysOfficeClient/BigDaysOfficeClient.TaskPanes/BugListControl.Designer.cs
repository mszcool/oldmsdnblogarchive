namespace BigDaysOfficeClient.TaskPanes
{
    partial class BugListControl
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(BugListControl));
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.BugsListListView = new System.Windows.Forms.ListView();
            this.PrioHeader = new System.Windows.Forms.ColumnHeader();
            this.SubmittedHeader = new System.Windows.Forms.ColumnHeader();
            this.TitleHeader = new System.Windows.Forms.ColumnHeader();
            this.OnlyMyCheck = new System.Windows.Forms.CheckBox();
            this.EveryMonthCheck = new System.Windows.Forms.CheckBox();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(6, 13);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(83, 82);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.label1.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(103, 13);
            this.label1.Margin = new System.Windows.Forms.Padding(0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(115, 25);
            this.label1.TabIndex = 1;
            this.label1.Text = "Bug Lists";
            // 
            // label2
            // 
            this.label2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.label2.Font = new System.Drawing.Font("Verdana", 8F);
            this.label2.Location = new System.Drawing.Point(103, 38);
            this.label2.Margin = new System.Windows.Forms.Padding(0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(142, 111);
            this.label2.TabIndex = 2;
            this.label2.Text = "Please select bugs from this list for more details. These details will then be di" +
                "splayed in a separate task pane.";
            // 
            // BugsListListView
            // 
            this.BugsListListView.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.BugsListListView.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.TitleHeader,
            this.PrioHeader,
            this.SubmittedHeader});
            this.BugsListListView.LargeImageList = this.imageList1;
            this.BugsListListView.Location = new System.Drawing.Point(5, 149);
            this.BugsListListView.Margin = new System.Windows.Forms.Padding(0);
            this.BugsListListView.Name = "BugsListListView";
            this.BugsListListView.Size = new System.Drawing.Size(243, 197);
            this.BugsListListView.SmallImageList = this.imageList1;
            this.BugsListListView.TabIndex = 3;
            this.BugsListListView.UseCompatibleStateImageBehavior = false;
            this.BugsListListView.View = System.Windows.Forms.View.Details;
            // 
            // PrioHeader
            // 
            this.PrioHeader.Text = "Priority";
            this.PrioHeader.Width = 55;
            // 
            // SubmittedHeader
            // 
            this.SubmittedHeader.Text = "Submitted";
            this.SubmittedHeader.Width = 83;
            // 
            // TitleHeader
            // 
            this.TitleHeader.Text = "Title";
            this.TitleHeader.Width = 99;
            // 
            // OnlyMyCheck
            // 
            this.OnlyMyCheck.AutoSize = true;
            this.OnlyMyCheck.Location = new System.Drawing.Point(5, 129);
            this.OnlyMyCheck.Name = "OnlyMyCheck";
            this.OnlyMyCheck.Size = new System.Drawing.Size(95, 17);
            this.OnlyMyCheck.TabIndex = 4;
            this.OnlyMyCheck.Text = "My Bugs, only!";
            this.OnlyMyCheck.UseVisualStyleBackColor = true;
            this.OnlyMyCheck.CheckedChanged += new System.EventHandler(this.OnlyMyCheck_CheckedChanged);
            // 
            // EveryMonthCheck
            // 
            this.EveryMonthCheck.AutoSize = true;
            this.EveryMonthCheck.Location = new System.Drawing.Point(5, 106);
            this.EveryMonthCheck.Name = "EveryMonthCheck";
            this.EveryMonthCheck.Size = new System.Drawing.Size(84, 17);
            this.EveryMonthCheck.TabIndex = 5;
            this.EveryMonthCheck.Text = "Each Month";
            this.EveryMonthCheck.UseVisualStyleBackColor = true;
            this.EveryMonthCheck.CheckedChanged += new System.EventHandler(this.EveryMonthCheck_CheckedChanged);
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList1.Images.SetKeyName(0, "BugLists.JPG");
            // 
            // BugListControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.EveryMonthCheck);
            this.Controls.Add(this.OnlyMyCheck);
            this.Controls.Add(this.BugsListListView);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox1);
            this.Margin = new System.Windows.Forms.Padding(0);
            this.Name = "BugListControl";
            this.Padding = new System.Windows.Forms.Padding(5);
            this.Size = new System.Drawing.Size(253, 351);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ListView BugsListListView;
        private System.Windows.Forms.ColumnHeader TitleHeader;
        private System.Windows.Forms.ColumnHeader PrioHeader;
        private System.Windows.Forms.ColumnHeader SubmittedHeader;
        private System.Windows.Forms.CheckBox OnlyMyCheck;
        private System.Windows.Forms.CheckBox EveryMonthCheck;
        private System.Windows.Forms.ImageList imageList1;
    }
}
