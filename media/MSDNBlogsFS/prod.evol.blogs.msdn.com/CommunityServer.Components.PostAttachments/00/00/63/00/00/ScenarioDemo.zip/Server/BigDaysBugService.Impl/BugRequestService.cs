using System;
using System.Web;
using System.Web.Services;
using System.Web.Services.Protocols;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;
using System.Collections.Generic;
using System.IO;
using System.Xml;
using System.Xml.Serialization;

using BigDays.Data.Entities;

namespace BigDaysBugService.Impl
{
    [WebService(Namespace = "Microsoft.Austria.BigDays2006.KeyNote")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    public class Service : System.Web.Services.WebService
    {
        private string DocLibUrl = "/Bug Requests";

        public Service()
        {

            //Uncomment the following line if using designed components 
            //InitializeComponent(); 
        }

        [WebMethod]
        public BugSummaryResponse GetBugSummary()
        {
            try
            {
                Dictionary<int, BugSummary> Bugs = new Dictionary<int, BugSummary>();

                SPWeb web = SPControl.GetContextWeb(Context);
                SPList LibList = web.GetList(DocLibUrl);

                foreach (SPListItem item in LibList.Items)
                {
                    // For every item create or update the entry
                    BugSummary sum;
                    DateTime dt = DateTime.Parse(item["Submission Date"].ToString());
                    if (Bugs.ContainsKey(dt.Month))
                    {
                        sum = Bugs[dt.Month];
                    }
                    else
                    {
                        sum = new BugSummary();
                        sum.Month = dt.Month;
                        Bugs.Add(dt.Month, sum);
                    }

                    if (string.Compare(item["State"].ToString(), "Open", true) == 0)
                    {
                        sum.OpenCount++;
                    }
                    else
                    {
                        sum.ClosedCount++;
                    }

                    switch (item["Bug Priority"].ToString())
                    {
                        case "Low":
                            sum.LowCount++;
                            break;
                        case "Medium":
                            sum.MediumCount++;
                            break;
                        case "High":
                            sum.HighCount++;
                            break;
                        case "Critical":
                            sum.CriticalCount++;
                            break;
                    }
                }

                // Create the response message
                BugSummaryResponse response = new BugSummaryResponse();
                response.Bugs = new BugSummary[Bugs.Count];
                Bugs.Values.CopyTo(response.Bugs, 0);
                return response;
            }
            catch
            {
                return null;
            }
        }

        [WebMethod]
        public BugListResponse GetBugList(BugListRequest request)
        {
            BugListResponse response = new BugListResponse();

            try
            {
                List<BugListEntry> entries = new List<BugListEntry>();

                SPWeb web = SPControl.GetContextWeb(Context);
                SPList LibList = web.GetList(DocLibUrl);

                foreach (SPListItem item in LibList.Items)
                {
                    bool TakeIt = true;
                    DateTime dt = DateTime.Parse(item["Submission Date"].ToString());

                    if (request.Month > 0)
                    {
                        TakeIt = (TakeIt & (dt.Month == request.Month));
                    }

                    if ((request.Employee != null) && (request.Employee.Length > 0))
                    {
                        XmlDocument BugsDoc = OpenBugsDocument(item.File);
                        string AssignedTo = GetDocumentProperty("AssignedTo", BugsDoc);
                        if (string.Compare(AssignedTo, request.Employee, true) == 0)
                            TakeIt = (TakeIt & true);
                        else
                            TakeIt = false;
                    }

                    if (TakeIt)
                    {
                        BugListEntry entry = new BugListEntry();
                        entry.FileUrl = item.File.Url;
                        entry.Priority = item["Bug Priority"].ToString();
                        entry.SubmissionDate = dt;
                        entry.Title = item["Bug Title"].ToString();
                        entries.Add(entry);
                    }
                }

                response.Entries = entries.ToArray();
            }
            catch
            {
                return null;
            }

            return response;
        }

        [WebMethod]
        public BugDetailsResponse GetBugDetails(BugDetailsRequest request)
        {
            try
            {
                SPWeb web = SPControl.GetContextWeb(Context);
                SPFile file = web.GetFile(request.FileUrl);

                BugDetailsResponse response = new BugDetailsResponse();

                using (Stream s = file.OpenBinaryStream())
                {
                    XmlSerializer ser = new XmlSerializer(typeof(BugRequest));
                    response.Details = (BugRequest)ser.Deserialize(s);
                }

                return response;
            }
            catch
            {
                return null;
            }
        }

        #region Document Helper methods

        public XmlDocument OpenBugsDocument(string itemUrl, SPWeb web)
        {
            SPFile file = web.GetFile(itemUrl);
            return OpenBugsDocument(file);
        }

        public XmlDocument OpenBugsDocument(SPFile file)
        {
            XmlDocument doc = new XmlDocument();
            using (Stream s = file.OpenBinaryStream())
            {
                doc.Load(s);
            }
            return doc;
        }

        public string GetDocumentProperty(string propName, XmlDocument doc)
        {
            XmlNamespaceManager BugRequestNsMgr;
            BugRequestNsMgr = new XmlNamespaceManager(doc.NameTable);
            BugRequestNsMgr.AddNamespace(
                    "mstns",
                    "http://tempuri.org/BugRequest.xsd"
            );

            XmlNode node = doc.SelectSingleNode("//mstns:" + propName, BugRequestNsMgr);
            return node.InnerText;
        }

        #endregion
    }
}