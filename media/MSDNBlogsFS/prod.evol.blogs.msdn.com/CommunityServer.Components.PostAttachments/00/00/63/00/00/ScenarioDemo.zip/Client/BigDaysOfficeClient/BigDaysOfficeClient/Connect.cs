namespace BigDaysOfficeClient
{
    using stdole;
    using System;
    using System.IO;
    using System.Xml;
    using System.Resources;
    using System.Reflection;
    using System.Drawing;
    using System.Drawing.Imaging;
    using System.Windows.Forms;
    using Extensibility;
    using System.Runtime.InteropServices;

    using Word = Microsoft.Office.Interop.Word;
    using Excel = Microsoft.Office.Interop.Excel;
    using PowerPoint = Microsoft.Office.Interop.PowerPoint;
    using Microsoft.Office.Core;

    using BigDaysOfficeClient.BugRequestsProxy;
using BigDaysOfficeClient.TaskPanes;

    #region Read me for Add-in installation and setup information.
    // When run, the Add-in wizard prepared the registry for the Add-in.
    // At a later time, if the Add-in becomes unavailable for reasons such as:
    //   1) You moved this project to a computer other than which is was originally created on.
    //   2) You chose 'Yes' when presented with a message asking if you wish to remove the Add-in.
    //   3) Registry corruption.
    // you will need to re-register the Add-in by building the BigDaysOfficeClientSetup project, 
    // right click the project in the Solution Explorer, then choose install.
    #endregion

    /// <summary>
    ///   The object for implementing an Add-in.
    /// </summary>
    /// <seealso class='IDTExtensibility2' />
    [GuidAttribute("F643182E-2C2E-4FB3-99EE-1011B7B22158"), ProgId("BigDaysOfficeClient.Connect")]
    public class Connect : Object, Extensibility.IDTExtensibility2, IRibbonExtensibility, ICustomTaskPaneConsumer
    {
        private CustomTaskPane BugListPane;
        private IBugListControl BugListControl;

        private string[] Employees;
        private string[] Months = {"January", "February", "March", 
                                   "Arpil", "May", "June",
                                   "July", "August", "September",
                                   "October", "November", "December"};
        private string[] BugStates = { "Open", "Closed", "Low", "Medium", "High", "Critical" };

        /// <summary>
        ///		Implements the constructor for the Add-in object.
        ///		Place your initialization code within this method.
        /// </summary>
        public Connect()
        {
            // Create the months array
            Employees = new string[7];
            Employees[0] = "Harald Leitenm�ller";
            Employees[1] = "Robert John";
            Employees[2] = "Andreas Erlacher";
            Employees[3] = "Andreas Schabus";
            Employees[4] = "Mario Szpuszta";
            Employees[5] = "Michele Berger";
            Employees[6] = "Miroslava Stanic";

        }

        #region IDTExtensibility

        /// <summary>
        ///      Implements the OnConnection method of the IDTExtensibility2 interface.
        ///      Receives notification that the Add-in is being loaded.
        /// </summary>
        /// <param term='application'>
        ///      Root object of the host application.
        /// </param>
        /// <param term='connectMode'>
        ///      Describes how the Add-in is being loaded.
        /// </param>
        /// <param term='addInInst'>
        ///      Object representing this Add-in.
        /// </param>
        /// <seealso class='IDTExtensibility2' />
        public void OnConnection(object application, Extensibility.ext_ConnectMode connectMode, object addInInst, ref System.Array custom)
        {
            applicationObject = application;
            addInInstance = addInInst;
        }

        /// <summary>
        ///     Implements the OnDisconnection method of the IDTExtensibility2 interface.
        ///     Receives notification that the Add-in is being unloaded.
        /// </summary>
        /// <param term='disconnectMode'>
        ///      Describes how the Add-in is being unloaded.
        /// </param>
        /// <param term='custom'>
        ///      Array of parameters that are host application specific.
        /// </param>
        /// <seealso class='IDTExtensibility2' />
        public void OnDisconnection(Extensibility.ext_DisconnectMode disconnectMode, ref System.Array custom)
        {
        }

        /// <summary>
        ///      Implements the OnAddInsUpdate method of the IDTExtensibility2 interface.
        ///      Receives notification that the collection of Add-ins has changed.
        /// </summary>
        /// <param term='custom'>
        ///      Array of parameters that are host application specific.
        /// </param>
        /// <seealso class='IDTExtensibility2' />
        public void OnAddInsUpdate(ref System.Array custom)
        {
        }

        /// <summary>
        ///      Implements the OnStartupComplete method of the IDTExtensibility2 interface.
        ///      Receives notification that the host application has completed loading.
        /// </summary>
        /// <param term='custom'>
        ///      Array of parameters that are host application specific.
        /// </param>
        /// <seealso class='IDTExtensibility2' />
        public void OnStartupComplete(ref System.Array custom)
        {
        }

        /// <summary>
        ///      Implements the OnBeginShutdown method of the IDTExtensibility2 interface.
        ///      Receives notification that the host application is being unloaded.
        /// </summary>
        /// <param term='custom'>
        ///      Array of parameters that are host application specific.
        /// </param>
        /// <seealso class='IDTExtensibility2' />
        public void OnBeginShutdown(ref System.Array custom)
        {
        }

        private object applicationObject;
        private object addInInstance;

        #endregion

        #region IRibbonExtensibility Members

        public string GetCustomUI(string ribbonId)
        {
            Assembly myAss = Assembly.GetExecutingAssembly();

            using (Stream rbStream = myAss.GetManifestResourceStream
                                    ("BigDaysOfficeClient.Resources.RibbonXML.xml"))
            {
                XmlDocument doc = new XmlDocument();
                doc.Load(rbStream);
                return doc.OuterXml;
            }
        }

        #endregion

        #region My Ribbon Functions

        public IPictureDisp getImage(IRibbonControl control)
        {
            string id = control.Id;

            if ((id.Equals("HR")) || (id.Equals("BugDetails")) || id.Equals("BugLists") || id.Equals("BugSummary"))
            {
                Image img = GetImageFromResources(id);
                return MyAxHostHelper.GetIPictureDispFromPicture(img);
            }

            return null;
        }

        private Image GetImageFromResources(string id)
        {
            string resString =
                string.Format("BigDaysOfficeClient.Resources.{0}.JPG", id);

            Image img = null;
            Assembly myAss = Assembly.GetExecutingAssembly();
            using (Stream s = myAss.GetManifestResourceStream(resString))
            {
                img = Image.FromStream(s);
            }
            return img;
        }

        public void ImportBugSummary(IRibbonControl control)
        {
            // Get the bug summary from the web service
            Service svc = new Service();
            svc.Credentials = System.Net.CredentialCache.DefaultCredentials;
            BugSummaryResponse Response = svc.GetBugSummary();

            if (this.applicationObject is Excel.Application)
                InsertExcelBugSummary(Response, this.applicationObject as Excel.Application);
            else if (this.applicationObject is Word.Application)
                InsertWordBugSummary(Response, this.applicationObject as Word.Application);
        }

        public int getItemCount(IRibbonControl control)
        {
            if (control.Id.Equals("BugLists"))
            {
                return 12;
            }
            else if (control.Id.Equals("HR"))
            {
                return Employees.Length;
            }

            return 0;
        }

        public string getItemLabel(IRibbonControl control, int index)
        {
            if (control.Id.Equals("BugLists"))
            {
                return Months[index];
            }
            else if (control.Id.Equals("HR"))
            {
                return Employees[index];
            }

            return string.Empty;
        }

        public IPictureDisp getItemImage(IRibbonControl control, int index)
        {
            Image img = null;
            if (control.Id.Equals("BugLists"))
            {
                img = GetImageFromResources("Month");
            }
            else if (control.Id.Equals("HR"))
            {
                img = GetImageFromResources("HR");
            }
            return MyAxHostHelper.GetIPictureDispFromPicture(img);
        }

        public void BugListsAction(IRibbonControl control, string selectedItemId, int selectedItemIndex)
        {
            BugListPane.Visible = true;
            BugListControl.LoadBugLists(selectedItemIndex + 1);
        }

        public void ShowBugList(IRibbonControl control)
        {
            BugListPane.Visible = !BugListPane.Visible;
        }

        #endregion

        #region Bug Summary Application Methods

        private Word.Table WordTable = null;
        private int ExcelRowStart = 0;
        private Excel.Worksheet Sheet = null;
        private object missing = System.Type.Missing;

        private void InsertExcelBugSummary(BugSummaryResponse response, Excel.Application app)
        {
            bool IsNew = (Sheet == null);

            // Get the currently selected sel
            object row, column;
            Excel.Range rng;
            Sheet = app.ActiveSheet as Excel.Worksheet;
            Excel.Range StartSelection = app.Selection as Excel.Range;

            if (IsNew)
            {
                Sheet.SelectionChange += new Microsoft.Office.Interop.Excel.DocEvents_SelectionChangeEventHandler(Sheet_SelectionChange);
            }
            
            // Build the month-list top-down
            ExcelRowStart = StartSelection.Row;
            column = StartSelection.Column;
            for (int i = 1; i <= 12; i++)
            {
                row = StartSelection.Row + i;
                rng = Sheet.Cells[row, column] as Excel.Range;
                rng.Value2 = Months[i - 1];
            }

            // Build the bug states
            for (int i = 0; i < BugStates.Length; i++)
            {
                column = StartSelection.Column + (i + 1);
                rng = Sheet.Cells[StartSelection.Row, column] as Excel.Range;
                rng.Value2 = BugStates[i];
            }

            // Now go through the bug responses and insert them
            foreach (BugSummary summary in response.Bugs)
            {
                row = StartSelection.Row + summary.Month;

                column = StartSelection.Column + 1;
                rng = Sheet.Cells[row, column] as Excel.Range;
                rng.Value2 = summary.OpenCount.ToString();

                column = (int)column + 1;
                rng = Sheet.Cells[row, column] as Excel.Range;
                rng.Value2 = summary.ClosedCount.ToString();

                column = (int)column + 1;
                rng = Sheet.Cells[row, column] as Excel.Range;
                rng.Value2 = summary.LowCount.ToString();

                column = (int)column + 1;
                rng = Sheet.Cells[row, column] as Excel.Range;
                rng.Value2 = summary.MediumCount.ToString();

                column = (int)column + 1;
                rng = Sheet.Cells[row, column] as Excel.Range;
                rng.Value2 = summary.HighCount.ToString();

                column = (int)column + 1;
                rng = Sheet.Cells[row, column] as Excel.Range;
                rng.Value2 = summary.CriticalCount.ToString();
            }
        }

        void Sheet_SelectionChange(Microsoft.Office.Interop.Excel.Range Target)
        {
            if (BugListPane.Visible)
            {
                if ((Target.Row > ExcelRowStart) && (Target.Row <= (ExcelRowStart + 12)))
                {
                    int month = Target.Row - ExcelRowStart;
                    BugListControl.LoadBugLists(month);
                }
            }
        }

        private void InsertWordBugSummary(BugSummaryResponse response, Word.Application app)
        {
            // Insert a table into the document
            Word.Table table = app.ActiveDocument.Tables.Add(app.Selection.Range, 13, 7, ref missing, ref missing);
            if(WordTable == null)
                app.WindowSelectionChange += new Microsoft.Office.Interop.Word.ApplicationEvents4_WindowSelectionChangeEventHandler(app_WindowSelectionChange);
            WordTable = table;
            WordTable.ID = Guid.NewGuid().ToString();

            // Insert the months into the table
            for (int i = 1; i <= 12; i++)
            {
                table.Cell(i + 1, 1).Select();
                app.Selection.TypeText(Months[i - 1]);
            }

            // Insert the bug states
            for (int i = 0; i < BugStates.Length; i++)
            {
                table.Cell(1, 2 + i).Select();
                app.Selection.TypeText(BugStates[i]);
            }

            // Now insert the real information
            foreach (BugSummary summary in response.Bugs)
            {
                int m = summary.Month;

                table.Cell(1 + m, 2).Select();
                app.Selection.TypeText(summary.OpenCount.ToString());

                table.Cell(1 + m, 3).Select();
                app.Selection.TypeText(summary.ClosedCount.ToString());

                table.Cell(1 + m, 4).Select();
                app.Selection.TypeText(summary.LowCount.ToString());

                table.Cell(1 + m, 5).Select();
                app.Selection.TypeText(summary.MediumCount.ToString());

                table.Cell(1 + m, 6).Select();
                app.Selection.TypeText(summary.HighCount.ToString());

                table.Cell(1 + m, 7).Select();
                app.Selection.TypeText(summary.CriticalCount.ToString());
            }
        }

        void app_WindowSelectionChange(Microsoft.Office.Interop.Word.Selection Sel)
        {
            if (BugListPane.Visible)
            {
                if (Sel.Tables.Count > 0)
                {
                    foreach (Word.Table t in Sel.Tables)
                    {
                        if (WordTable.ID.Equals(t.ID))
                        {
                            int month = Sel.Cells[1].Row.Index - 1;
                            BugListControl.LoadBugLists(month);
                        }
                    }
                }
            }
        }

        #endregion

        #region ICustomTaskPaneConsumer Members

        public void CTPFactoryAvailable(ICTPFactory CTPFactoryInst)
        {
            CustomTaskPane ctp = CTPFactoryInst.CreateCTP("BigDaysOfficeClient.TaskPanes.BugListControl", "Bug Lists", missing);
            if (ctp.ContentControl is BigDaysOfficeClient.TaskPanes.IBugListControl)
            {
                BugListPane = ctp;
                BugListControl = (BigDaysOfficeClient.TaskPanes.IBugListControl)ctp.ContentControl;
            }
        }

        #endregion
    }

    public class MyAxHostHelper : AxHost
    {
        public MyAxHostHelper()
            : base(null)
        { }

        public new static IPictureDisp GetIPictureDispFromPicture(Image image)
        {
            return (IPictureDisp)AxHost.GetIPictureDispFromPicture(image);
        }
    }
}