using System;
using System.Collections.Generic;
using System.Text;

namespace BigDays.Test.BugService
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                if (args.Length < 1)
                {
                    Console.WriteLine("Usage: BigDays.Test.BugService summary|list|details");
                    return;
                }

                localhost.Service svc = new BigDays.Test.BugService.localhost.Service();
                Console.WriteLine("Service URL: " + svc.Url);
                svc.Credentials = System.Net.CredentialCache.DefaultCredentials;

                switch (args[0])
                {
                    case "summary":
                        localhost.BugSummaryResponse summary = svc.GetBugSummary();
                        Console.WriteLine("Got Summary:");
                        foreach (localhost.BugSummary sum in summary.Bugs)
                        {
                            Console.WriteLine("-) Month: {0}", sum.Month);
                            Console.WriteLine("   -) Open: {0}, Closed: {1}", sum.OpenCount, sum.ClosedCount);
                            Console.WriteLine("   -) Critical: {0}", sum.CriticalCount);
                        }
                        break;

                    case "list":
                        localhost.BugListRequest request = new BigDays.Test.BugService.localhost.BugListRequest();
                        request.Month = Int32.Parse(args[1]);
                        if (args.Length == 3)
                            request.Employee = args[2];
                        localhost.BugListResponse list = svc.GetBugList(request);
                        foreach (localhost.BugListEntry entry in list.Entries)
                        {
                            Console.WriteLine("Found Entry");
                            Console.WriteLine("-) {0} {1} {2}", entry.Title, entry.SubmissionDate, entry.Priority);
                            Console.WriteLine("   {0}", entry.FileUrl);
                        }
                        break;

                    case "details":
                        localhost.BugDetailsRequest GetDetails = new BigDays.Test.BugService.localhost.BugDetailsRequest();
                        GetDetails.FileUrl = args[1];
                        localhost.BugDetailsResponse details = svc.GetBugDetails(GetDetails);
                        Console.WriteLine("Got the details!");
                        Console.WriteLine("{0}", details.Details.BugTitle);
                        Console.WriteLine("{0}", details.Details.Description);
                        Console.WriteLine("{0}", details.Details.SubmissionDate);
                        Console.WriteLine("{0}", details.Details.BugPriority);
                        foreach (localhost.BugDetailsResponseDetailsReproSteps repro in details.Details.ReproSteps)
                        {
                            Console.WriteLine("-) Repro {0}: {1}",
                                repro.StepNr, repro.StepDescription);
                        }
                        break;
                }
            }
            catch
            {
            }
        }
    }
}

namespace BigDays.Test.BugService.localhost
{
    using System.Xml;
    using System.Xml.Serialization;

    [System.Xml.Serialization.XmlRootAttribute(Namespace = "http://tempuri.org/BugRequest.xsd", IsNullable = false)]
    public partial class BugDetailsResponseDetails
    {
    }

    [System.Xml.Serialization.XmlRootAttribute(Namespace = "http://tempuri.org/BugRequest.xsd", IsNullable = false)]
    public partial class BugDetailsResponseDetailsReproSteps
    {
    }
}