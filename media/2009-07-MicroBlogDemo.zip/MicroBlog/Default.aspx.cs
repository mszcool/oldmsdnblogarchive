﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MicroBlogModel;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        string categoryFilter = Request.QueryString["categoryName"];
        if (categoryFilter != null)
        {
            MicroBlogEntities DataContext = new MicroBlogEntities();
            var Category = (from c in DataContext.Category
                            where c.CategoryName.StartsWith(categoryFilter)
                            select c).FirstOrDefault();

            if (Category != null)
            {
                PostsDataSource.Where = "it.Category.CategoryId == " + Category.CategoryId;
            }
        }
    }
}
