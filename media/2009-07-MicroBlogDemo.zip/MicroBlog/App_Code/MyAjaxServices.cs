﻿using System;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Activation;
using System.ServiceModel.Web;
using MicroBlogModel;
using System.Diagnostics;

[ServiceContract(Namespace = "")]
[AspNetCompatibilityRequirements(RequirementsMode = AspNetCompatibilityRequirementsMode.Allowed)]
public class MyAjaxServices
{
	// Add [WebGet] attribute to use HTTP GET
	[OperationContract]
	public string[] GetCategories(string prefixText, int count)
	{
        MicroBlogEntities DataContext = new MicroBlogEntities();

        var Categories = from c in DataContext.Category
                         where c.CategoryName.StartsWith(prefixText)
                         select c.CategoryName;

        return Categories.ToArray();
	}

    [OperationContract]
    public CategoryAddResponse AddCategory(string categoryName)
    {
        try
        {
            MicroBlogEntities DataContext = new MicroBlogEntities();

            Category NewCategory = new Category()
            {
                CategoryName = categoryName
            };
            DataContext.AddToCategory(NewCategory);
            DataContext.SaveChanges();

            return new CategoryAddResponse()
            {
                CategoryId = NewCategory.CategoryId,
                Message = "Successfully added your new category!"
            };
        }
        catch (Exception ex)
        {
            EventLog.WriteEntry
                (
                    "Application",
                    string.Format("Failed adding a new category due to the following error: {0}{1}{2}",
                                  ex.Message, Environment.NewLine, ex.StackTrace)
                );

            return new CategoryAddResponse()
            {
                CategoryId = -1,
                Message = "Unable to add a new category, please contact your administrator!"
            };
        }
    }
}

[DataContract]
public class CategoryAddResponse
{
    [DataMember]
    public int CategoryId { get; set; }
    [DataMember]
    public string Message { get; set; }
}
