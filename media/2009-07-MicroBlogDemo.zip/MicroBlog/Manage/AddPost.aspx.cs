﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Diagnostics;
using MicroBlogModel;

public partial class Manage_AddPost : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void AddPostCommand_Click(object sender, EventArgs e)
    {
        try
        {
            MicroBlogEntities DataContext = new MicroBlogEntities();

            // Try to find the category
            Category PostCategory = (from c in DataContext.Category
                                     where c.CategoryName == CategoryText.Text
                                     select c).FirstOrDefault();
            if (PostCategory == null)
            {
                // No category specified
                MessagesLabel.Text = "The category you have specified is invalid! Please click 'Add Category' if you want to add a new category!";
                return;
            }

            Post NewPost = new Post()
            {
                Title = TitleText.Text,
                PostDate = DateTime.Now,
                Owner = User.Identity.Name,
                Category = PostCategory,
                Text = PostsEditor.Content
            };
            DataContext.AddToPost(NewPost);
            DataContext.SaveChanges();

            Server.Transfer("~/Default.aspx");
        }
        catch (Exception ex)
        {
            EventLog.WriteEntry(
                "Application",
                string.Format(
                    "Unable to submit post to database due to the following exception: {0}{1}{2}",
                    ex.Message, Environment.NewLine, ex.StackTrace
                )
            );
            throw;

            
        }
    }

    protected void CancelCommand_Click(object sender, EventArgs e)
    {
        Server.Transfer("~/Default.aspx");
    }
}
