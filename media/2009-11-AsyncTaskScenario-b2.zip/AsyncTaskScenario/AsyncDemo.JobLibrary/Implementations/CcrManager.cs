﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Ccr.Core;

namespace AsyncDemo.JobLibrary.Implementations
{
    class CcrManager : IJobManager
    {
        private Port<IJob> JobQueue;

        internal CcrManager()
        {
            JobQueue = new Port<IJob>();
            DispatcherQueue Queue = new DispatcherQueue();

            Arbiter.Activate
            (
                Queue, 
                Arbiter.Receive<IJob>
                (
                    true, JobQueue, 
                    Job => Job.Execute()
                )
            );
        }

        #region IJobManager Members

        public void EnqueJob(params IJob[] jobToEnqueue)
        {
            foreach (var j in jobToEnqueue)
            {
                JobQueue.Post(j);
            }
        }

        #endregion
    }
}
