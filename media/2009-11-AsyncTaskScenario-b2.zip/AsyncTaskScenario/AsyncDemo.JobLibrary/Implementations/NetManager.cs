﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AsyncDemo.JobLibrary.Implementations
{
    class NetManager : IJobManager
    {
        #region IJobManager Members

        public void EnqueJob(params IJob[] jobToEnqueue)
        {
            throw new NotImplementedException();
        }

        #endregion
    }
}
