﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AsyncDemo.JobLibrary
{
    public interface IJob
    {
        void Execute();
    }

    public abstract class Job<T> : IJob
    {
        private T _Parameter;
        protected T Parameter
        {
            get { return _Parameter; }
        }

        public Job(T parameter)
        {
            _Parameter = parameter;
        }

        public abstract void Execute();
    }

    public abstract class Job<T, TResult> : Job<T>
    {
        private Action<TResult> _NotificationCallback;
        protected Action<TResult> NotificationCallback
        {
            get { return _NotificationCallback; }
        }

        public Job(T parameter, Action<TResult> notifyCallback)
            :base(parameter)
        {
            _NotificationCallback = notifyCallback;
        }
    }
}
