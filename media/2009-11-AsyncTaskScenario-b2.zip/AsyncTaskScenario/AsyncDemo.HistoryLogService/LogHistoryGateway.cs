﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using AsyncDemo.ServiceInterfaces;
using System.ServiceModel;
using AsyncDemo.JobLibrary;

namespace AsyncDemo.HistoryLogService
{
    //[ServiceBehavior(InstanceContextMode = InstanceContextMode.Single)]
    public class LogHistoryGateway : ILogMessageService
    {
        private IJobManager _JobManager;

        public LogHistoryGateway()
        {
            _JobManager = JobManagerFactory.CreateJobManager();
        }

        #region ILogMessageService Members

        public void LogMessage(LogEntity entity)
        {
            try
            {
                // Enqueue all required jobs
                _JobManager.EnqueJob
                    (
                        new Jobs.WriteToDbJob(entity, this.ExceptionCallback)
                    );
                _JobManager.EnqueJob
                    (
                        new Jobs.WriteToConsoleJob(entity, this.ExceptionCallback)
                    );
            }
            catch (Exception)
            {
                // TODO: add exception handling here
            }
        }

        #endregion

        #region Callback Delegates

        private void ExceptionCallback(Exception ex)
        {
            _JobManager.EnqueJob
                (
                    new Jobs.CallbackJob
                    (
                        new LogEntity()
                        {
                            LogId = Guid.NewGuid(),
                            Message = "Unable to store message in log history: " + ex.Message,
                            Severity = LogSeverity.Critical,
                            MessageType = "LogErrorMessage"
                        }, 
                        this.ExceptionCallback
                    )
                );
        }

        #endregion
    }
}
