﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;
using AsyncDemo.ServiceInterfaces;
using System.Configuration;

namespace AsyncDemo.HistoryLogService
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("----------------------------");
            Console.WriteLine("Database Log History Service");
            Console.WriteLine("----------------------------");
            Console.WriteLine();

            Console.WriteLine("Starting...");
            using (ServiceHost Host = new ServiceHost(typeof(LogHistoryGateway)))
            {
                Console.WriteLine("Opening...");
                Host.Open();
                Console.WriteLine("Open, waiting for requests!");

                bool IsPeer = false;
                string IsPeerSetting = ConfigurationManager.AppSettings["IsPeer"];
                if (!string.IsNullOrEmpty(IsPeerSetting))
                {
                    IsPeer = bool.Parse(IsPeerSetting);
                }

                if (!IsPeer)
                {
                    Console.WriteLine("-- Setup Service Bus Subscription...");
                    IServiceBus Bus = new ChannelFactory<IServiceBus>("PubSubEndPoint").CreateChannel();
                    Bus.Subscribe(new SubscriptionRequest()
                    {
                        ContractTypeName = ServiceInterfaceList.ShipMovementService,
                        EndPointAddress = "net.tcp://localhost:9082/asyncdemo/shipmove"
                    });
                    Console.WriteLine("-- Subscription added!");
                }

                Console.WriteLine("Press ENTER to quit!");
                Console.ReadLine();
                Host.Close();
            }
            Console.WriteLine();
            Console.WriteLine("Database log history service shut down!");
        }
    }
}
