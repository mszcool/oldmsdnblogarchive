﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using AsyncDemo.ServiceInterfaces;
using AsyncDemo.JobLibrary;
using System.Diagnostics;

namespace AsyncDemo.HistoryLogService.Jobs
{
    public class CallbackJob : Job<LogEntity, Exception>
    {
        public CallbackJob(LogEntity parameter, Action<Exception> callback)
            : base(parameter, callback)
        {
        }

        public override void Execute()
        {
            Debug.WriteLine
                (
                    string.Format("--- {0} --- Call-back job called with message {1}!",
                                  DateTime.Now.ToLongTimeString(), Parameter.Message)
                );
        }
    }
}
