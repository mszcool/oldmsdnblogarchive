﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using AsyncDemo.ServiceInterfaces;
using AsyncDemo.JobLibrary;

namespace AsyncDemo.HistoryLogService.Jobs
{
    class WriteToConsoleJob : Job<LogEntity, Exception>
    {
        public WriteToConsoleJob(LogEntity parameter, Action<Exception> callback)
            : base(parameter, callback)
        {
        }

        public override void Execute()
        {
            try
            {
                Console.WriteLine("--- {0} --- Received log message", DateTime.Now.ToLongTimeString());
                Console.WriteLine("--- {1} {0}---{2} {0}---{3}",
                                  Environment.NewLine,
                                  Parameter.Message,
                                  Parameter.Severity,
                                  Parameter.LogId);
                Console.WriteLine();
            }
            catch (Exception ex)
            {
                base.NotificationCallback(ex);
            }
        }
    }
}
