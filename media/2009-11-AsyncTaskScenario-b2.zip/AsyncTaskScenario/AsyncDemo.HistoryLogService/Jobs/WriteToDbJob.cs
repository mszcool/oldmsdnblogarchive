﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using AsyncDemo.ServiceInterfaces;
using AsyncDemo.JobLibrary;
using AsyncDemo.HistoryLogService.Data;

namespace AsyncDemo.HistoryLogService.Jobs
{
    public class WriteToDbJob : Job<LogEntity, Exception>
    {
        public WriteToDbJob(LogEntity parameter, Action<Exception> callback)
            : base(parameter, callback)
        {
        }

        public override void Execute()
        {
            try
            {
                AsyncHistoryEntities Context = new AsyncHistoryEntities();
                LogEntry Entry = new LogEntry()
                {
                    LogId = base.Parameter.LogId,
                    LogMessage = base.Parameter.Message,
                    Severity = base.Parameter.Severity.ToString(),
                    LogDate = DateTime.Now
                };
                Context.AddToLogEntry(Entry);
                Context.SaveChanges();
            }
            catch (Exception ex)
            {
                base.NotificationCallback(ex);
            }
        }
    }
}
