﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;
using System.Runtime.Serialization;

namespace AsyncDemo.ServiceInterfaces
{
    [ServiceContract]
    public interface IServiceBus
    {
        [OperationContract]
        SubscriptionResponse Subscribe(SubscriptionRequest request);
        [OperationContract]
        void Unsubscribe(UnsubscribeRequest request);
    }

    [DataContract]
    public class SubscriptionRequest
    {
        [DataMember]
        public string ContractTypeName { get; set; }
        [DataMember]
        public string EndPointAddress { get; set; }
    }

    [DataContract]
    public class SubscriptionResponse
    {
        [DataMember]
        public bool Accepted { get; set; }
        [DataMember]
        public Guid SubscriptionId { get; set; }
    }

    [DataContract]
    public class UnsubscribeRequest
    {
        [DataMember]
        public Guid SubscriptionId { get; set; }
    }
}
