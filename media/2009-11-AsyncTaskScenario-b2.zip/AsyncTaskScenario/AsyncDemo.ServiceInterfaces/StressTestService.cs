﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;
using System.Runtime.Serialization;

namespace AsyncDemo.ServiceInterfaces
{
    [ServiceContract]
    public interface IStressTestService
    {
        [OperationContract(IsOneWay = true)]
        void AcceptMessage(SomeRequestMessage message);
    }

    [DataContract]
    public class SomeRequestMessage
    {
        [DataMember]
        public int IntValue { get; set; }
        [DataMember]
        public string StringValue { get; set; }
        [DataMember]
        public DateTime TimeValue { get; set; }
        [DataMember]
        public decimal DecimalValue { get; set; }
    }
}
