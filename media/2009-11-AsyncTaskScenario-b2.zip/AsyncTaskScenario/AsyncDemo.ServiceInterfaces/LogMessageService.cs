﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;
using System.Runtime.Serialization;

namespace AsyncDemo.ServiceInterfaces
{
    [DataContract]
    public class LogEntity : MessageBase
    {
        [DataMember]
        public Guid LogId { get; set; }
        [DataMember]
        public LogSeverity Severity { get; set; }
        [DataMember]
        public string Message { get; set; }
    }

    public enum LogSeverity
    {
        Information,
        Warning, 
        Critical
    }

    [ServiceContract]
    public interface ILogMessageService
    {
        [OperationContract(IsOneWay = true)]
        void LogMessage(LogEntity entity);
    }
}
