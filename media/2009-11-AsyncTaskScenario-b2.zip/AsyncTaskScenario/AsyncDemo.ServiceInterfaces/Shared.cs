﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace AsyncDemo.ServiceInterfaces
{
    [DataContract]
    public class MessageBase
    {
        [DataMember]
        public Guid TrnId { get; set; }
        [DataMember]
        public string MessageType { get; set; }
    }

    [DataContract]
    public class MessageResponse
    {
        [DataMember]
        public Guid TrnId { get; set; }
        [DataMember]
        public bool Accepted { get; set; }
    }

    public static class ServiceInterfaceList
    {
        public const string LogMessageService = "AsyncDemo.ServiceInterfaces.ILogMessageService";
        public const string ShipMovementService = "AsyncDemo.ServiceInterfaces.IShipMovementService";
        public const string ShipMovementResponseService = "AsyncDemo.ServiceInterfaces.IShipMovementResponseService";

        public const string StressTestService = "AsyncDemo.ServiceInterfaces.IStressTestService";
    }
}
