﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;
using System.ServiceModel;

namespace AsyncDemo.ServiceInterfaces
{
    [DataContract]
    public class MovementMessage : MessageBase
    {
        [DataMember]
        public int X { get; set; }
        [DataMember]
        public int Y { get; set; }
        [DataMember]
        public decimal Speed { get; set; }
    }

    [DataContract]
    public class MovementResponseMessage : MessageBase
    {
        [DataMember]
        public string ShipResponse { get; set; }
        [DataMember]
        public DateTime ShipAckTime { get; set; }
    }

    [ServiceContract]
    public interface IShipMovementService
    {
        [OperationContract(IsOneWay = true)]
        void Move(MovementMessage command);
    }

    [ServiceContract]
    public interface IShipMovementResponseService
    {
        [OperationContract(IsOneWay = true)]        
        void MovementResponse(MovementResponseMessage response);
    }
}
