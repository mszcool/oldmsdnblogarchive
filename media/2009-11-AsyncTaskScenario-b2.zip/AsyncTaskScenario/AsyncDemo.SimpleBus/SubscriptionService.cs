﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using AsyncDemo.ServiceInterfaces;
using System.ServiceModel;

namespace AsyncDemo.SimpleBus
{
    public class SubscriptionService : IServiceBus
    {
        #region IServiceBus Members

        public SubscriptionResponse Subscribe(SubscriptionRequest request)
        {
            Guid NewSubId = Guid.NewGuid();

            Console.WriteLine("Adding subscription {0} for {1} / {2}", NewSubId, request.ContractTypeName, request.EndPointAddress);

            lock (Program.Subscriptions)
            {
                switch (request.ContractTypeName)
                {
                    case ServiceInterfaceList.LogMessageService:
                        Program.Subscriptions.Add
                            (
                                NewSubId,
                                (new ChannelFactory<ILogMessageService>("LogEndPoint")).CreateChannel(new EndpointAddress(request.EndPointAddress))
                            );
                        break;
                    case ServiceInterfaceList.ShipMovementService:
                        Program.Subscriptions.Add
                            (
                                NewSubId,
                                (new ChannelFactory<IShipMovementService>("ShipEndPoint")).CreateChannel(new EndpointAddress(request.EndPointAddress))
                            );
                        break;
                    case ServiceInterfaceList.ShipMovementResponseService:
                        Program.Subscriptions.Add
                            (
                                NewSubId,
                                (new ChannelFactory<IShipMovementResponseService>("ShipResponseEndPoint")).CreateChannel(new EndpointAddress(request.EndPointAddress))
                            );
                        break;
                    case ServiceInterfaceList.StressTestService:
                        Program.Subscriptions.Add
                            (
                                NewSubId,
                                (new ChannelFactory<IStressTestService>("StressResponseEndPoint")).CreateChannel(new EndpointAddress(request.EndPointAddress))
                            );
                        break;
                }
            }

            return new SubscriptionResponse() 
            {
                Accepted = true,
                SubscriptionId = NewSubId
            };
        }

        public void Unsubscribe(UnsubscribeRequest request)
        {
            lock (Program.Subscriptions)
            {
                if (Program.Subscriptions.ContainsKey(request.SubscriptionId))
                {
                    Program.Subscriptions.Remove(request.SubscriptionId);
                }
            }
        }

        #endregion
    }
}
