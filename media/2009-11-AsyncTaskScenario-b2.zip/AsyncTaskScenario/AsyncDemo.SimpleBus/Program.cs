﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;
using AsyncDemo.ServiceInterfaces;

namespace AsyncDemo.SimpleBus
{
    class Program
    {
        public static Dictionary<Guid, object> Subscriptions;

        static void Main(string[] args)
        {
            Subscriptions = new Dictionary<Guid, object>();

            Console.WriteLine("--------------------------");
            Console.WriteLine("Simple Service Bus Service");
            Console.WriteLine("--------------------------");
            Console.WriteLine();

            Console.WriteLine("Starting...");
            using (ServiceHost Host = new ServiceHost(typeof(SubscriptionService)))
            {
                Console.WriteLine("Opening...");
                Host.Open();
                Console.WriteLine("Open, waiting for requests!");

                Console.WriteLine("-- Starting bus service...");
                ServiceHost BusHost = new ServiceHost(typeof(BusServices));
                BusHost.Open();

                Console.WriteLine("Press ENTER to quit!");
                Console.ReadLine();

                BusHost.Close();
                Host.Close();
            }
            Console.WriteLine();
            Console.WriteLine("Service bus service shut down!");
        }
    }
}
