﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using AsyncDemo.ServiceInterfaces;
using System.Diagnostics;
using System.ServiceModel;

namespace AsyncDemo.SimpleBus
{
    public class BusServices : ILogMessageService, IShipMovementService, IShipMovementResponseService, IStressTestService
    {
        #region ILogMessageService Members

        public void LogMessage(LogEntity entity)
        {
            Console.WriteLine("");
            Console.WriteLine("---");
            Console.WriteLine("Log Message arrived...");
            
            // Try to find all subscribers
            var Results = from e in Program.Subscriptions.Values
                          where e is ILogMessageService
                          select e;
            foreach (ILogMessageService Proxy in Results)
            {
                try
                {
                    Console.WriteLine("   Calling Service...");
                    Proxy.LogMessage(entity);
                    Console.WriteLine("   Called Service!");
                }
                catch (Exception ex)
                {
                    Console.WriteLine("    Error calling log message service: " + ex.Message); 
                }
            }

            // ---
            Console.WriteLine("---");
        }

        #endregion

        #region IShipMovementService Members

        public void Move(MovementMessage command)
        {
            Console.WriteLine("");
            Console.WriteLine("---");
            Console.WriteLine("Movement Message arrived...");

            // Try to find all subscribers
            var Results = from e in Program.Subscriptions.Values
                          where e is IShipMovementService
                          select e;
            foreach (IShipMovementService Proxy in Results)
            {
                try
                {
                    Console.WriteLine("   Calling Service...");
                    Proxy.Move(command);
                    Console.WriteLine("   Called Service!");
                }
                catch (Exception ex)
                {
                    Console.WriteLine("    Error calling log message service: " + ex.Message);
                }
            }

            // ---
            Console.WriteLine("---");
        }

        #endregion

        #region IShipMovementResponseService Members

        public void MovementResponse(MovementResponseMessage response)
        {
            Console.WriteLine("");
            Console.WriteLine("---");
            Console.WriteLine("Movement Response Message arrived...");

            // Try to find all subscribers
            var Results = from e in Program.Subscriptions.Values
                          where e is IShipMovementResponseService
                          select e;
            foreach (IShipMovementResponseService Proxy in Results)
            {
                try
                {
                    Console.WriteLine("   Calling Service...");
                    Proxy.MovementResponse(response);
                    Console.WriteLine("   Called Service!");
                }
                catch (Exception ex)
                {
                    Console.WriteLine("    Error calling log message service: " + ex.Message);
                }
            }

            // ---
            Console.WriteLine("---");
        }

        #endregion

        #region IStressTestService Members

        public void AcceptMessage(SomeRequestMessage message)
        {
            //Console.Write(".");

            // Try to find all subscribers
            var Results = from e in Program.Subscriptions.Values
                          where e is IStressTestService
                          select e;
            foreach (IStressTestService Proxy in Results)
            {
                try
                {
                    Proxy.AcceptMessage(message);
                }
                catch (Exception ex)
                {
                    Console.WriteLine("    Error calling log message service: " + ex.Message);
                }
            }
        }

        #endregion
    }
}
