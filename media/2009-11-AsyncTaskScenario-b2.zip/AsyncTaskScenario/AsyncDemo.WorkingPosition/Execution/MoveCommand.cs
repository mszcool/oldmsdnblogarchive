﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Input;
using AsyncDemo.JobLibrary;
using AsyncDemo.ServiceInterfaces;
using AsyncDemo.WorkingPosition.Execution.Jobs;
using AsyncDemo.WorkingPosition.UI.ViewModels;

namespace AsyncDemo.WorkingPosition.Execution
{
    public class MoveCommand : ICommand
    {
        private IJobManager _JobManager;
        private Action<Exception> _MoveCallback;
        private Action<string> _LogCallback;

        public MoveCommand(IJobManager jobManager, Action<Exception> callback, Action<string> logCallback)
        {
            _JobManager = jobManager;
            _MoveCallback = callback;
            _LogCallback = logCallback;
        }

        #region ICommand Members

        public bool CanExecute(object parameter)
        {
            return true;
        }

        public event EventHandler CanExecuteChanged;

        public void Execute(object parameter)
        {
            //
            // Parameter is the view model
            //
            ShipMovementViewModel Model = parameter as ShipMovementViewModel;

            //
            // Create entity for logging
            //
            LogEntity LogEntry = new LogEntity()
            {
                LogId = Guid.NewGuid(),
                Message = string.Format("Requested ship movement {0}/{1} at speed {2}!",
                                         Model.ShipMovement.X, Model.ShipMovement.Y, Model.ShipMovement.Speed),
                MessageType = "Log Entry",
                Severity = LogSeverity.Information,
            };

            //
            // Schedule a job for requesting the ship  movement
            //
            _JobManager.EnqueJob
                (
                    new MovementRequestJob(Model.ShipMovement, _MoveCallback),
                    new LogToServiceJob(LogEntry, _LogCallback),
                    new LogToEventLogJob(LogEntry, _LogCallback)
                );
        }

        #endregion
    }
}
