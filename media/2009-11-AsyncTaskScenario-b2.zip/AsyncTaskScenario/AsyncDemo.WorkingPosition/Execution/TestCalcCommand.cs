﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Input;
using AsyncDemo.JobLibrary;
using AsyncDemo.WorkingPosition.UI.ViewModels;
using AsyncDemo.WorkingPosition.Execution.Jobs;

namespace AsyncDemo.WorkingPosition.Execution
{
    public class TestCalcCommand : ICommand
    {
        private IJobManager _JobManager;
        private Action<long> _NotifyCallback;

        public TestCalcCommand(IJobManager jobManager, Action<long> notifyCallback, Action startTimerCallback)
        {
            _JobManager = jobManager;
            _NotifyCallback = notifyCallback;
        }

        #region ICommand Members

        public bool CanExecute(object parameter)
        {
            return true;
        }

        public event EventHandler CanExecuteChanged;

        public void Execute(object parameter)
        {
            ((TestCalcViewModel)parameter).Results.Clear();
            _JobManager.EnqueJob
                (
                    new TestCalcEnqueueJob(_JobManager, (TestCalcViewModel)parameter, _NotifyCallback)
                );
        }

        #endregion
    }
}
