﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using AsyncDemo.ServiceInterfaces;
using AsyncDemo.JobLibrary;
using System.ServiceModel;

namespace AsyncDemo.WorkingPosition.Execution.Jobs
{
    public class MovementRequestJob : Job<MovementMessage, Exception>
    {
        public MovementRequestJob(MovementMessage parameter, Action<Exception> callback)
            : base(parameter, callback)
        {
        }

        public override void Execute()
        {
            try
            {
                //
                // Call the ship service to send a movement request to the ship
                //
                ChannelFactory<IShipMovementService> MoveFactory =
                    new ChannelFactory<IShipMovementService>("ShipEndPoint");
                IShipMovementService MoveProxy = MoveFactory.CreateChannel();
                MoveProxy.Move(Parameter);
            }
            catch (Exception ex)
            {
                NotificationCallback(ex);
            }
        }
    }

}
