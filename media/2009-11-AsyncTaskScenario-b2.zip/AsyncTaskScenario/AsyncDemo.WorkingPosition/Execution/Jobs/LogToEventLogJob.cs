﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using AsyncDemo.JobLibrary;
using AsyncDemo.ServiceInterfaces;
using System.Diagnostics;

namespace AsyncDemo.WorkingPosition.Execution.Jobs
{
    public class LogToEventLogJob : Job<LogEntity, string>
    {
        public LogToEventLogJob(LogEntity p, Action<string> callback)
            : base(p, callback)
        {
        }

        #region IJob<string,string> Members

        public override void Execute()
        {
            EventLogEntryType EntryType = EventLogEntryType.Information;
            switch (base.Parameter.Severity)
            {
                case LogSeverity.Critical:
                    EntryType = EventLogEntryType.Error;
                    break;
                case LogSeverity.Information:
                    EntryType = EventLogEntryType.Information;
                    break;
                case LogSeverity.Warning:
                    EntryType = EventLogEntryType.Warning;
                    break;
            }

            try
            {
                EventLog.WriteEntry
                    (
                        "Application", base.Parameter.Message, EntryType
                    );
            }
            catch (Exception ex)
            {
                NotificationCallback
                    (
                        string.Format("Log message not accepted by event log: {0}!!", ex.Message)
                    );
            }
        }

        #endregion
    }
}
