﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using AsyncDemo.ServiceInterfaces;
using AsyncDemo.JobLibrary;
using System.ServiceModel;

namespace AsyncDemo.WorkingPosition.Execution.Jobs
{
    public class LogToServiceJob : Job<LogEntity, string>
    {
        public LogToServiceJob(LogEntity p, Action<string> callback)
            : base(p, callback)
        {
        }
  
        #region IJob<LogEntity,string> Members

        public override void Execute()
        {
            try
            {
                ChannelFactory<ILogMessageService> LogProxyFactory = 
                    new ChannelFactory<ILogMessageService>("LogEndPoint");
                ILogMessageService ServiceProxy = LogProxyFactory.CreateChannel();

                ServiceProxy.LogMessage(base.Parameter);

                base.NotificationCallback("Log message accepted by history service!");
            }
            catch (Exception ex)
            {
                base.NotificationCallback("Error occured while calling log message service: " + ex.Message);
            }
        }

        #endregion
    }
}
