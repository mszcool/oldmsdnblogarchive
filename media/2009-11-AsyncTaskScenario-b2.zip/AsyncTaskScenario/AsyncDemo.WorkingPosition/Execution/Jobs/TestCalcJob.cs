﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using AsyncDemo.WorkingPosition.UI.ViewModels;
using AsyncDemo.JobLibrary;
using AsyncDemo.ServiceInterfaces;
using System.ServiceModel;
using AsyncDemo.WorkingPosition.Services;
using System.Diagnostics;

namespace AsyncDemo.WorkingPosition.Execution.Jobs
{
    public class TestCalcJob : Job<int, long>
    {
        public TestCalcJob(int m, Action<long> c)
            : base(m, c)
        {
        }

        public override void Execute()
        {
            long result = 1;
            for (int i = 2; i <= Parameter; i++)
            {
                result += i;
            }
            //System.Threading.Thread.Sleep(1000);
            NotificationCallback(result);
        }
    }

    public class TestCalcEnqueueJob : Job<TestCalcViewModel, long>
    {
        private IJobManager _JobManager;

        public TestCalcEnqueueJob(IJobManager jobManager, TestCalcViewModel m, Action<long> c)
            : base(m, c)
        {
            _JobManager = jobManager;
        }

        public override void Execute()
        {
            bool Continue = true;

            Parameter.ThroughPutTimer.Elapsed += (sender, eventArgs) => Continue = false;
            Parameter.StartThroughPutTimer();

            int i = Parameter.MinNumber;
            while (Continue)
            {
                if (Parameter.IsAsync)
                {
                    Debug.WriteLine(string.Format("{0} --- Scheduling...", DateTime.Now.ToLongTimeString()));
                    _JobManager.EnqueJob
                        (
                            new TestCalcJob(i, NotificationCallback)
                        );
                }
                else
                {
                    new TestCalcJob(i, NotificationCallback).Execute();
                }

                i++;
                if (i > Parameter.MaxNumber) i = Parameter.MinNumber;
            }
        }
    }

}
