﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using AsyncDemo.ServiceInterfaces;
using System.Diagnostics;
using System.ServiceModel;
using System.Threading;

namespace AsyncDemo.WorkingPosition.UI.Controls
{
    /// <summary>
    /// Interaction logic for BusPerfTest.xaml
    /// </summary>
    public partial class BusPerfTest : UserControl
    {
        private bool Done = false;
        private int MessagesReceived = 0;

        public BusPerfTest()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            int CallCount = int.Parse(CountTextBox.Text);

            Mouse.OverrideCursor = Cursors.Wait;

            Done = false;
            MessagesReceived = 0;

            Thread TestThread = new Thread(new ThreadStart(delegate()
            {
                // Create the proxy
                ChannelFactory<IStressTestService> Factory = new ChannelFactory<IStressTestService>("StressEndPoint");
                IStressTestService Service = Factory.CreateChannel();

                Stopwatch watch = new Stopwatch();
                watch.Start();
                for (int i = 0; i < CallCount; i++)
                {
                    Service.AcceptMessage
                        (
                            new SomeRequestMessage()
                            {
                                TimeValue = DateTime.Now,
                                StringValue = string.Format("Value {0}", i),
                                DecimalValue = 2387628.23M,
                                IntValue = 236583
                            }
                        );
                }
                watch.Stop();

                long MillSecs = watch.ElapsedMilliseconds;

                Dispatcher.Invoke
                    (
                        new Action(delegate()
                        {
                            Done = true;
                            Mouse.OverrideCursor = Cursors.Arrow;
                            ResultsTextBlock.Text = string.Format("Took me {0} milliseconds for {1} calls, received messages: {2}", MillSecs, CallCount, MessagesReceived);
                        })
                    );

            }));
            TestThread.Start();
        }

        internal void AddMessageToList(SomeRequestMessage message)
        {
            if(!Done) MessagesReceived++;

            Dispatcher.Invoke
                (
                    new Action<SomeRequestMessage>
                    (
                        a => ReceivedItemsList.Items.Add
                             (
                                string.Format("{0} {1} {2} {3}",
                                    message.TimeValue.ToLongTimeString(), message.IntValue, message.DecimalValue, message.StringValue)
                             )
                    ), message
                );
        }
    }
}
