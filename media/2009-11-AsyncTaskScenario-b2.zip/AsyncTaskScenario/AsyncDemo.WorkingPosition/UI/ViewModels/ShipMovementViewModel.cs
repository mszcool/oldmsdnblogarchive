﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using AsyncDemo.JobLibrary;
using System.Windows.Threading;
using AsyncDemo.ServiceInterfaces;
using AsyncDemo.WorkingPosition.Execution;
using System.Collections.ObjectModel;
using AsyncDemo.WorkingPosition.Execution.Jobs;
using System.Diagnostics;

namespace AsyncDemo.WorkingPosition.UI.ViewModels
{
    public class ShipMovementViewModel
    {
        private IJobManager _JobManager;
        private Dispatcher _OwningDispatcher;

        public ShipMovementViewModel(IJobManager jobManager, Dispatcher owningDispatcher, Action<string> logCallback)
        {
            _JobManager = jobManager;
            _OwningDispatcher = owningDispatcher;

            ShipMovement = new MovementMessage() { TrnId = Guid.NewGuid() };
            MoveCommand = new MoveCommand(jobManager, new Action<Exception>(ExceptionCallback), logCallback);
            OwningResponses = new ObservableCollection<MovementResponseMessage>();
            OtherResponses = new ObservableCollection<MovementResponseMessage>();
        }

        public MovementMessage ShipMovement { get; set; }
        public MoveCommand MoveCommand { get; set; }

        public ObservableCollection<MovementResponseMessage> OwningResponses { get; set; }
        public ObservableCollection<MovementResponseMessage> OtherResponses { get; set; }

        internal void MovementReceived(MovementResponseMessage message)
        {
            _OwningDispatcher.Invoke
            (
                new Action(delegate()
                        {
                            if (message.TrnId == ShipMovement.TrnId)
                                OwningResponses.Add(message);
                            else
                                OtherResponses.Add(message);
                        })
            );
        }

        private void ExceptionCallback(Exception ex)
        {
            LogEntity Entity = new LogEntity();
            Entity.LogId = Guid.NewGuid();
            Entity.Message = "Exception occured while requesting ship movement: " + ex.Message;
            Entity.MessageType = "Log Error Message";
            Entity.Severity = LogSeverity.Critical;

            Action<string> LogCallback = new Action<string>(ExceptionCallbackLogCallback);

            LogToEventLogJob LogEvJob = new LogToEventLogJob(Entity, LogCallback);
            LogToServiceJob LogSvcJob = new LogToServiceJob(Entity, LogCallback);

            _JobManager.EnqueJob(LogEvJob);
            _JobManager.EnqueJob(LogSvcJob);
        }

        private void ExceptionCallbackLogCallback(string message)
        {
            Debug.WriteLine("Log response: " + message);
        }
    }
}
