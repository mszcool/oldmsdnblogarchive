﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using AsyncDemo.ServiceInterfaces;
using System.Collections.ObjectModel;
using AsyncDemo.WorkingPosition.Execution;
using AsyncDemo.JobLibrary;
using System.Diagnostics;
using System.Windows.Threading;

namespace AsyncDemo.WorkingPosition.UI.ViewModels
{
    public class LogViewModel
    {
        private Dispatcher _Dispatcher;

        public LogViewModel(IJobManager jobManager, Dispatcher owningDispatcher)
        {
            _Dispatcher = owningDispatcher;

            NewEntity = new LogEntity()
            {
                LogId = Guid.NewGuid(),
                MessageType = "LogMessage"
            };
            PublishedEntities = new ObservableCollection<LogEntity>();
            ReceivedEntities = new ObservableCollection<LogEntity>();
            CallbackMessages = new ObservableCollection<string>();

            LogCommand = new LogCommand(jobManager, LogMessageNotification);
        }

        public LogEntity NewEntity { get; set; }
        public ObservableCollection<LogEntity> PublishedEntities { get; set; }
        public ObservableCollection<LogEntity> ReceivedEntities { get; set; }

        public LogCommand LogCommand { get; set; }
        public MoveCommand MoveCommand { get; set; }

        public ObservableCollection<string> CallbackMessages { get; set; }

        internal void LogMessageNotification(string message)
        {
            _Dispatcher.Invoke
                (
                    new Action
                        (
                            delegate 
                            { 
                                CallbackMessages.Add(message); 
                            }
                        )
                );
            Debug.WriteLine("----");
            Debug.WriteLine(message);
        }
    }
}
