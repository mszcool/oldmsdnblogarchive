﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using AsyncDemo.ServiceInterfaces;
using System.ServiceModel;
using System.Windows.Threading;

namespace AsyncDemo.WorkingPosition.Services
{
    [ServiceBehavior(InstanceContextMode = InstanceContextMode.Single)]
    public class ShipMovementResponseService : IShipMovementResponseService
    {
        private Dispatcher _UIDispatcher;
        private Action<MovementResponseMessage> _ResponseCallback;

        public ShipMovementResponseService(Dispatcher dispatcher, Action<MovementResponseMessage> responseCallback)
        {
            _UIDispatcher = dispatcher;
            _ResponseCallback = responseCallback;
        }

        #region IShipMovementResponseService Members

        public void MovementResponse(MovementResponseMessage response)
        {
            _UIDispatcher.Invoke
                (
                    _ResponseCallback, response
                );
        }

        #endregion
    }
}
