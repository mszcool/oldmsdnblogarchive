﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using AsyncDemo.ServiceInterfaces;
using System.ServiceModel;

namespace AsyncDemo.WorkingPosition.Services
{
    [ServiceBehavior(InstanceContextMode = InstanceContextMode.Single)]
    public class StressTestService : IStressTestService
    {
        private Action<SomeRequestMessage> _UICallback;

        public StressTestService(Action<SomeRequestMessage> callback)
        {
            _UICallback = callback;
        }

        #region IStressTestService Members

        public void AcceptMessage(SomeRequestMessage message)
        {
            _UICallback(message);
        }

        #endregion
    }
}
