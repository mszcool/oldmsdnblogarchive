﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using AsyncDemo.ServiceInterfaces;
using System.Windows.Threading;
using System.ServiceModel;

namespace AsyncDemo.WorkingPosition.Services
{
    [ServiceBehavior(InstanceContextMode = InstanceContextMode.Single)]
    public class LogMessageService : ILogMessageService
    {
        private Action<LogEntity> _CallbackOnReceive;
        private Dispatcher _ClientDispatcher;

        public LogMessageService(Dispatcher dispatcher, Action<LogEntity> callback)
        {
            _ClientDispatcher = dispatcher;
            _CallbackOnReceive = callback;
        }

        #region ILogMessageService Members

        public void LogMessage(LogEntity entity)
        {
            _ClientDispatcher.Invoke
                (
                    _CallbackOnReceive, entity
                );
        }

        #endregion
    }
}
