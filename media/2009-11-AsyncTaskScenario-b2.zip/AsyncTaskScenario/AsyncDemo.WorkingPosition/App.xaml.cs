﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Windows;

namespace AsyncDemo.WorkingPosition
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
        public int Port;

        protected override void OnStartup(StartupEventArgs e)
        {
            if (e.Args.Length > 0)
            {
                if (!Int32.TryParse(e.Args[0], out Port))
                    Port = (new Random()).Next(9020, 9050);
            }
            else
            {
                Port = (new Random()).Next(9020, 9050);
            }
            base.OnStartup(e);
        }
    }
}
