﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using AsyncDemo.ServiceInterfaces;
using AsyncDemo.JobLibrary;
using System.ServiceModel;

namespace AsyncDemo.ShipService.Jobs
{
    public class MoveShipResponseJob : Job<MovementResponseMessage>
    {
        public MoveShipResponseJob(MovementResponseMessage message)
            : base(message)
        {
        }

        public override void Execute()
        {
            //
            // Try calling the ship response serivce callback service(s)
            //
            try
            {
                ChannelFactory<IShipMovementResponseService> ResponseServiceFactory =
                    new ChannelFactory<IShipMovementResponseService>("ShipRespEndPoint");
                IShipMovementResponseService ResponseProxy = ResponseServiceFactory.CreateChannel();
                ResponseProxy.MovementResponse(Parameter);

                Console.WriteLine("Response service called!");
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error calling response serivce: " + ex.Message);
            }
        }
    }
}
