﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using AsyncDemo.ServiceInterfaces;

namespace AsyncDemo.ShipService.Jobs
{
    /// <summary>
    /// Interaction logic for MoveShipJobUI.xaml
    /// </summary>
    public partial class MoveShipJobUI : Window
    {
        private static readonly Color[] MyColors = { Colors.AliceBlue, 
                                                     Colors.LightGreen, 
                                                     Colors.Yellow, 
                                                     Colors.SeaGreen, 
                                                     Colors.Pink, 
                                                     Colors.Plum,
                                                     Colors.PowderBlue, 
                                                     Colors.PeachPuff,
                                                     Colors.PapayaWhip,
                                                     Colors.LightGray };

        public MoveShipJobUI(MovementMessage message)
        {
            InitializeComponent();

            Movement = message;
            this.Loaded += new RoutedEventHandler(MoveShipJobUI_Loaded);
        }

        void MoveShipJobUI_Loaded(object sender, RoutedEventArgs e)
        {
            DataContext = Movement;

            int Height = System.Windows.Forms.Screen.PrimaryScreen.WorkingArea.Height;
            int Width = System.Windows.Forms.Screen.PrimaryScreen.WorkingArea.Width;

            this.Left = Width - this.Width;
            this.Top = Height - this.Height;

            Random rnd = new Random((int)DateTime.Now.Ticks);
            int ColorIdx = rnd.Next(0, 9);
            this.Background = new SolidColorBrush(MyColors[ColorIdx]);
        }

        public MovementMessage Movement { get; set; }
        public MovementResponseMessage MovementResponse { get; set; }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            // Accept
            MovementResponse = new MovementResponseMessage()
            {
                TrnId = Movement.TrnId,
                ShipResponse = "Accepted!",
                ShipAckTime = DateTime.Now,
                MessageType = "Ship Movement Response"
            };

            // Close Window
            this.Close();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            // Decline
            MovementResponse = new MovementResponseMessage()
            {
                TrnId = Movement.TrnId,
                ShipResponse = "NOT accepted!",
                ShipAckTime = DateTime.Now,
                MessageType = "Ship Movement Response"
            };

            // Close Window
            this.Close();
        }
    }
}
