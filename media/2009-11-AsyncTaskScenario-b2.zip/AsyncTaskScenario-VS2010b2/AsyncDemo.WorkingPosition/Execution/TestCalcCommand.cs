﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Input;
using AsyncDemo.JobLibrary;
using AsyncDemo.WorkingPosition.UI.ViewModels;
using AsyncDemo.WorkingPosition.Execution.Jobs;
using System.Diagnostics;

namespace AsyncDemo.WorkingPosition.Execution
{
    public class TestCalcCommand : ICommand
    {
        private IJobManager _JobManager;
        private Action<double> _NotifyCallback;

        public TestCalcCommand(IJobManager jobManager, Action<double> notifyCallback)
        {
            _JobManager = jobManager;
            _NotifyCallback = notifyCallback;
        }

        #region ICommand Members

        public bool CanExecute(object parameter)
        {
            return true;
        }

        public event EventHandler CanExecuteChanged;

        public void Execute(object p)
        {
            TestCalcViewModel Parameter = p as TestCalcViewModel;
            Parameter.Results.Clear();

            if (Parameter.IsAsync)
            {
                _JobManager.EnqueJob
                    (
                        new SimpleTestJob(_JobManager, Parameter, 
                            Parameter.AddToResults)
                    );
            }
            else
            {
                Stopwatch watch = new Stopwatch();
                watch.Start();
                bool Continue = true;
                int i = Parameter.MinNumber;
                while (Continue)
                {
                    Debug.WriteLine(string.Format("{0} --- Scheduling...", DateTime.Now.ToLongTimeString()));

                    double result = 1;
                    for (int x = 2; x <= i; x++)
                    {
                        if (Math.Floor(result) % 2 == 0)
                            result += Math.Cos(x % 360);
                        else if (x % 3 == 0)
                            result -= Math.Log(x);
                        else if (DateTime.Now.Ticks % 5 == 0)
                            result -= Math.Sin(x % 360);
                        else
                            result += Math.Tan(x % 360);
                    }
                    _NotifyCallback(result);

                    i++;
                    if (i > Parameter.MaxNumber) i = Parameter.MinNumber;
                    if (watch.ElapsedMilliseconds >= Parameter.SecondsToRun * 1000)
                        Continue = false;
                }
                Parameter.StopThroughPutCount();
                watch.Stop();
            }
        }

        #endregion
    }
}
