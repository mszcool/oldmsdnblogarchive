﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Input;
using AsyncDemo.JobLibrary;
using AsyncDemo.ServiceInterfaces;
using AsyncDemo.WorkingPosition.Execution.Jobs;
using AsyncDemo.WorkingPosition.UI.ViewModels;

namespace AsyncDemo.WorkingPosition.Execution
{
    public class LogCommand : ICommand
    {
        private IJobManager _JobManager;
        private Action<string> _NotifyCallback;

        public LogCommand(IJobManager jobManager, Action<string> callback)
        {
            _JobManager = jobManager;
            _NotifyCallback = callback;
        }

        #region ICommand Members

        public bool CanExecute(object parameter)
        {
            LogViewModel lvm = parameter as LogViewModel;
            if (lvm != null)
            {
                if ((lvm.NewEntity.Message != null) && (lvm.NewEntity.Message.Length > 0))
                {
                    return true;
                }
            }
            return false;
        }

        //public event EventHandler CanExecuteChanged;
        public event EventHandler CanExecuteChanged
        {
            add { CommandManager.RequerySuggested += value; }
            remove { CommandManager.RequerySuggested -= value; }
        }

        public void Execute(object parameter)
        {
            // View-Model passed as parameter
            LogViewModel ViewModel = (LogViewModel)parameter;
            ViewModel.NewEntity.LogId = Guid.NewGuid();
            ViewModel.PublishedEntities.Add
                (
                    new LogEntity() 
                    { 
                        LogId = ViewModel.NewEntity.LogId, 
                        Message = ViewModel.NewEntity.Message,
                        MessageType = ViewModel.NewEntity.MessageType,
                        Severity = ViewModel.NewEntity.Severity
                    }
                );

            // Enqueue job for sending log to service bus
            _JobManager.EnqueJob
                (
                    new LogToEventLogJob(ViewModel.NewEntity, _NotifyCallback),
                    new LogToServiceJob(ViewModel.NewEntity, _NotifyCallback)
                );
            // Hand control back to the UI
            return;
        }

        #endregion
    }
}
