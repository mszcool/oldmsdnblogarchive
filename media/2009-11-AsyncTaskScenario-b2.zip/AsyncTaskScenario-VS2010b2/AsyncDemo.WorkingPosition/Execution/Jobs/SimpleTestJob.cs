﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using AsyncDemo.JobLibrary;
using AsyncDemo.WorkingPosition.UI.ViewModels;
using System.Diagnostics;

namespace AsyncDemo.WorkingPosition.Execution.Jobs
{
    public class SimpleTestJobDetail : Job<int, double>
    {
        public SimpleTestJobDetail(int p, Action<double> callback)
            : base(p, callback)
        {
        }

        public override void Execute()
        {
            double result = 1;
            for (int x = 2; x <= base.Parameter; x++)
            {
                if (Math.Floor(result) % 2 == 0)
                    result += Math.Cos(x % 360);
                else if (x % 3 == 0)
                    result -= Math.Log(x);
                else if (DateTime.Now.Ticks % 5 == 0)
                    result -= Math.Sin(x % 360);
                else
                    result += Math.Tan(x % 360);
            }
            base.NotificationCallback(result);
        }
    }

    public class SimpleTestJob : JobLibrary.Job<TestCalcViewModel, double>
    {
        private IJobManager _JobManager;
        private Action<double> _JobCallback;

        public SimpleTestJob(IJobManager jobManager,
            TestCalcViewModel m, Action<double> c)
            : base(m, c)
        {
            _JobManager = jobManager;
            _JobCallback = c;
        }

        public override void Execute()
        {
            Stopwatch watch = new Stopwatch();
            watch.Start();
            bool Continue = true;
            int i = Parameter.MinNumber;
            while (Continue)
            {
                Debug.WriteLine(string.Format("{0} --- Scheduling...", DateTime.Now.ToLongTimeString()));

                _JobManager.EnqueJobsAndWait
                    (
                       new SimpleTestJobDetail(i, base.NotificationCallback),
                       new SimpleTestJobDetail(i+1, base.NotificationCallback)
                    );

                i+=2;
                if (i > Parameter.MaxNumber) i = Parameter.MinNumber;
                if (watch.ElapsedMilliseconds >= Parameter.SecondsToRun * 1000)
                    Continue = false;
            }
            Parameter.StopThroughPutCount();
            watch.Stop();
        }
    }
}
