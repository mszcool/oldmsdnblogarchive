﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using AsyncDemo.WorkingPosition.UI.ViewModels;
using AsyncDemo.JobLibrary;
using AsyncDemo.ServiceInterfaces;
using System.ServiceModel;
using AsyncDemo.WorkingPosition.Services;
using System.Diagnostics;
using System.Threading.Tasks;

namespace AsyncDemo.WorkingPosition.Execution.Jobs
{
    public class TestCalcJob : Job<int, double>
    {
        public TestCalcJob(int m, Action<double> c)
            : base(m, c)
        {
        }

        public override void Execute()
        {
            double result = 1;
            for (int x = 2; x <= Parameter; x++)
            {
                if (Math.Floor(result) % 2 == 0)
                    result += Math.Cos(x % 360);
                else if (x % 3 == 0)
                    result -= Math.Log(x);
                else if (DateTime.Now.Ticks % 5 == 0)
                    result -= Math.Sin(x % 360);
                else
                    result += Math.Tan(x % 360);
            }
            NotificationCallback(result);
        }
    }

    public class TestCalcEnqueueJob : Job<TestCalcViewModel, double>
    {
        private IJobManager _JobManager;
        private Action<double> _JobCallback;
        private Action _CompletedCallback;

        public TestCalcEnqueueJob(IJobManager jobManager, TestCalcViewModel m, Action<double> c, Action cr)
            : base(m, c)
        {
            _JobManager = jobManager;
            _JobCallback = c;
            _CompletedCallback = cr;
        }

        public override void Execute()
        {
            Stopwatch watch = new Stopwatch();
            watch.Start();
            bool Continue = true;
            int i = Parameter.MinNumber;
            while (Continue)
            {
                Debug.WriteLine(string.Format("{0} --- Scheduling...", DateTime.Now.ToLongTimeString()));

                _JobManager.EnqueJobsAndWait
                    (
                        new TestCalcJob(i, _JobCallback),
                        new TestCalcJob(i + 1, _JobCallback)
                    );

                i += 2;
                if (i > Parameter.MaxNumber) i = Parameter.MinNumber;
                if (watch.ElapsedMilliseconds >= Parameter.SecondsToRun * 1000)
                    Continue = false;
            }
            _CompletedCallback();
            watch.Stop();
        }
    }

}
