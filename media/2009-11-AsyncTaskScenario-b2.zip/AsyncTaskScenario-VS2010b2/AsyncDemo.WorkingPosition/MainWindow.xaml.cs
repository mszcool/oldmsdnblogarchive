﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using AsyncDemo.WorkingPosition.UI.ViewModels;
using AsyncDemo.ServiceInterfaces;
using AsyncDemo.JobLibrary;
using System.ServiceModel;
using AsyncDemo.WorkingPosition.Services;
using System.Configuration;
using System.Diagnostics;

namespace AsyncDemo.WorkingPosition
{
    /// <summary>
    /// Interaction logic for Window1.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private IJobManager MainJobManager;

        private LogViewModel LogPresentationModel;
        private ShipMovementViewModel ShipMovePresentationModel;
        private TestCalcViewModel CalcPresentationModel;

        private bool IsPeer;
        private int Port;
        private Guid InstanceId;

        private ServiceHost LogServiceHost;
        private ILogMessageService LogMessageService;

        private ServiceHost ShipServiceHost;
        private IShipMovementResponseService ShipMessageService;

        private ServiceHost StressServiceHost;
        private IStressTestService StressTestService;

        public MainWindow()
        {
            InitializeComponent();

            //
            // Create the job manager responsible for processing queues of jobs
            //
            MainJobManager = JobManagerFactory.CreateJobManager();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            //
            // Are we peer2peer?
            //
            IsPeer = false;
            string IsPeerSetting = ConfigurationManager.AppSettings["IsPeer"];
            if (!string.IsNullOrEmpty(IsPeerSetting))
            {
                IsPeer = bool.Parse(IsPeerSetting);
            }

            //
            // Use an instance ID for unique URLs
            //
            Port = ((AsyncDemo.WorkingPosition.App)App.Current).Port;
            InstanceId = Guid.NewGuid();

            //
            // Setup all the infrastructure
            //
            SetupPresentationModels();
            SetupCallbackServices();
            if(!IsPeer) SetupSubscriptions();
        }

        private void SetupCallbackServices()
        {
            //
            // Log Message Service
            //
            try
            {
                string LogUri = string.Empty;
                if (IsPeer)
                    LogUri = "net.p2p://localhost/asyncdemo/p2pmesh";
                else
                    LogUri = string.Format(ConfigurationManager.AppSettings["logServiceUrl"], InstanceId, Port);
                
                LogMessageService = new Services.LogMessageService(Dispatcher,
                                            e => LogPresentationModel.ReceivedEntities.Add(e));
                LogServiceHost = new ServiceHost(LogMessageService,
                                            new Uri(LogUri));
                LogServiceHost.Open();
            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex.ToString());
                MessageBox.Show("Unable to start log-callback: " + ex.Message);
                App.Current.Shutdown();
            }

            //
            // Ship Response Service
            //
            try
            {
                string ShipUri = string.Empty;
                if (IsPeer)
                    ShipUri = "net.p2p://localhost/asyncdemo/p2pmesh";
                else
                    ShipUri = string.Format(ConfigurationManager.AppSettings["shipRespServiceUrl"], InstanceId, Port);

                ShipMessageService = new Services.ShipMovementResponseService(Dispatcher,
                                                e => ShipMovePresentationModel.MovementReceived(e));
                ShipServiceHost = new ServiceHost(ShipMessageService, 
                                                new Uri(ShipUri));
                ShipServiceHost.Open();
            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex.ToString());
                MessageBox.Show("Unable to start ship-movement-callback: " + ex.Message);
            }

            //
            // Stress test Service
            //
            try
            {
                string StressUri = string.Empty;
                if (IsPeer)
                    StressUri = "net.p2p://localhost/asyncdemo/p2pmesh";
                else
                    StressUri = string.Format(ConfigurationManager.AppSettings["stressServiceUrl"], InstanceId, Port);

                StressTestService = new Services.StressTestService(BusPerfControl.AddMessageToList);
                StressServiceHost = new ServiceHost(StressTestService,
                                            new Uri(StressUri));
                StressServiceHost.Open();
            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex.ToString());
                MessageBox.Show("Unable to start stress-test callback: " + ex.Message);
            }
        }

        private void SetupSubscriptions()
        {
            ChannelFactory<IServiceBus> BusFactory = new ChannelFactory<IServiceBus>("PubSubEndPoint");
            IServiceBus Bus = BusFactory.CreateChannel();

            Bus.Subscribe(
                new SubscriptionRequest()
                {
                    ContractTypeName = ServiceInterfaceList.LogMessageService,
                    EndPointAddress = string.Format(ConfigurationManager.AppSettings["logServiceUrl"], InstanceId, Port)
                }
            );

            Bus.Subscribe(
                new SubscriptionRequest()
                {
                    ContractTypeName = ServiceInterfaceList.StressTestService,
                    EndPointAddress = string.Format(ConfigurationManager.AppSettings["stressServiceUrl"], InstanceId, Port)
                }
            );

            Bus.Subscribe(
                new SubscriptionRequest()
                {
                    ContractTypeName = ServiceInterfaceList.ShipMovementResponseService,
                    EndPointAddress = string.Format(ConfigurationManager.AppSettings["shipRespServiceUrl"], InstanceId, Port)
                }
            );

            BusFactory.Close();
        }

        private void SetupPresentationModels()
        {
            //
            // Log Messages presentation model
            //
            LogPresentationModel = new LogViewModel(MainJobManager, this.Dispatcher);
            LogControl.DataContext = LogPresentationModel;

            //
            // Ship Movement presentation model
            //
            ShipMovePresentationModel = new ShipMovementViewModel(
                MainJobManager, this.Dispatcher, LogPresentationModel.LogMessageNotification);
            ShipControl.DataContext = ShipMovePresentationModel;

            //
            // Test Calculation presentation model
            //
            CalcPresentationModel = new TestCalcViewModel(MainJobManager, this.Dispatcher);
            CalcControl.DataContext = CalcPresentationModel;
        }

        private void Window_Unloaded(object sender, RoutedEventArgs e)
        {
            try
            {
                LogServiceHost.Close();
                StressServiceHost.Close();
                ShipServiceHost.Close();
            }
            catch { }
        }
    }
}
