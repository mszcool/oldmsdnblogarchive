﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using AsyncDemo.WorkingPosition.Execution;
using System.Collections.ObjectModel;
using AsyncDemo.JobLibrary;
using System.Windows.Threading;
using System.Timers;

namespace AsyncDemo.WorkingPosition.UI.ViewModels
{
    public class TestCalcViewModel
    {
        private IJobManager _JobManager;
        private Dispatcher _OwningDispatcher;

        public TestCalcViewModel(IJobManager jobManager, Dispatcher dispatcher)
        {
            _JobManager = jobManager;
            _OwningDispatcher = dispatcher;

            Results = new ObservableCollection<double>();
            ThroughPutResults = new ObservableCollection<string>();

            TestCalcCommand = new TestCalcCommand(_JobManager, AddToResults);
        }

        public int MinNumber { get; set; }
        public int MaxNumber { get; set; }
        public int SecondsToRun { get; set; }

        public bool IsAsync { get; set; }

        public ObservableCollection<double> Results { get; set; }
        public ObservableCollection<string> ThroughPutResults { get; set; }

        public TestCalcCommand TestCalcCommand { get; set; }

        internal void AddToResults(double result)
        {
            _OwningDispatcher.Invoke
                (
                    new Action
                    (
                        delegate()
                        {
                            Results.Add(result);
                        }
                    )
                );
        }

        #region Timer Management Function

        internal void StopThroughPutCount()
        {
            _OwningDispatcher.Invoke(
                new Action(delegate()
            {
                string value = string.Format("--- {0} --- {1}",
                            DateTime.Now.ToLongTimeString(),
                            Results.Count);
                ThroughPutResults.Add(value);
            }));
        }

        #endregion
    }
}
