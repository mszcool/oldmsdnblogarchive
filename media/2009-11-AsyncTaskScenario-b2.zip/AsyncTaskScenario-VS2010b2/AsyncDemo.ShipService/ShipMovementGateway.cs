﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using AsyncDemo.ServiceInterfaces;
using AsyncDemo.JobLibrary;

namespace AsyncDemo.ShipService
{
    public class ShipMovementGateway : IShipMovementService
    {
        IJobManager _JobManager;

        public ShipMovementGateway()
        {
            _JobManager = JobManagerFactory.CreateJobManager();
        }

        #region IShipMovementService Members

        public void Move(MovementMessage command)
        {
            //
            // Enqueue a job for doing the ship movement
            //
            _JobManager.EnqueJob
                (
                    new Jobs.MoveShipJob(command, 
                        new Action<MovementResponseMessage>(EnqueueCallShipResponseService))
                );
        }

        #endregion

        private void EnqueueCallShipResponseService(MovementResponseMessage message)
        {
            _JobManager.EnqueJob
                (
                    new Jobs.MoveShipResponseJob(message)
                );
        }
    }
}
