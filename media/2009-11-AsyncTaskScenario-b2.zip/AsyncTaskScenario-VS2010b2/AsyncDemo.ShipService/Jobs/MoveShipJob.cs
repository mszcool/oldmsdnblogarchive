﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using AsyncDemo.ServiceInterfaces;
using AsyncDemo.JobLibrary;
using System.Threading;

namespace AsyncDemo.ShipService.Jobs
{
    public class MoveShipJob : Job<MovementMessage, MovementResponseMessage>
    {
        public MoveShipJob(MovementMessage p, 
            Action<MovementResponseMessage> callback)
            : base(p, callback)
        {
        }

        public override void Execute()
        {
            //
            // Simulate a "long-running" ship movement process
            // by starting a UI and wait until the UI is ready
            //
            MovementResponseMessage Response = ShowUISynchronous();

            //
            // After the job has done its hard work, notify gateway through callback
            //
            NotificationCallback(Response);
        }

        private MovementResponseMessage ShowUISynchronous()
        {
            MovementResponseMessage Response = null;
            Thread t = new Thread(delegate()
            {
                MoveShipJobUI JobUI = new MoveShipJobUI(Parameter);
                JobUI.ShowDialog();
                Response = JobUI.MovementResponse;
            });
            t.SetApartmentState(ApartmentState.STA);
            t.Start();
            t.Join();
            return Response;
        }
    }
}
