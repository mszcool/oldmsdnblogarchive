﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AsyncDemo.JobLibrary
{
    public static class JobManagerFactory
    {
        public static IJobManager CreateJobManager()
        {
            //return new Implementations.CcrManager();
            return new Implementations.NetManager();
        }
    }
}
