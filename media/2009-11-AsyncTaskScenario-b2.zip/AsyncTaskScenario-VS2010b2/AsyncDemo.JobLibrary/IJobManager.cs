﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AsyncDemo.JobLibrary
{
    public interface IJobManager
    {
        void EnqueJob(params IJob[] jobToEnqueue);
        void EnqueJobsAndWait(params IJob[] jobToEnqueue);
    }
}
