﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Collections.Concurrent;

namespace AsyncDemo.JobLibrary.Implementations
{
    class NetManager : IJobManager
    {
        #region IJobManager Members

        public void EnqueJob(params IJob[] jobToEnqueue)
        {
            //
            // Queue is managed by task manager
            //
            //Parallel.ForEach(jobToEnqueue, delegate(IJob j)
            //{
            //    j.Execute();
            //});

            foreach (var j in jobToEnqueue)
            {
                Task t = new Task(j.Execute);
                t.Start();
            }

            //Task First, Current, Previous;
            //First = Current = Previous = null;
            //foreach (var j in jobToEnqueue)
            //{
            //    Current = new Task(j.Execute);
            //    if (First == null)
            //        First = Current;
            //    if (Previous != null)
            //        Previous.ContinueWith(t => Current.Start());
            //    Previous = Current;
            //}
            //First.Start();
        }

        public void EnqueJobsAndWait(params IJob[] jobToEnqueue)
        {
            Task[] Tasks = new Task[jobToEnqueue.Length];
            for (int i = 0; i < jobToEnqueue.Length; i++)
            {
                Tasks[i] = new Task(jobToEnqueue[i].Execute);
                Tasks[i].Start();
            }
            Task.WaitAll(Tasks);
        }

        #endregion
    }
}
