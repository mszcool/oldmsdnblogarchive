﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Ccr.Core;
using System.Diagnostics;

namespace AsyncDemo.JobLibrary.Implementations
{
    class CcrManager : IJobManager
    {
        private Port<IJob> JobQueue;
        private DispatcherQueue Queue;

        internal CcrManager()
        {
            JobQueue = new Port<IJob>();
            Queue = new DispatcherQueue();

            Arbiter.Activate
            (
                Queue,
                Arbiter.Receive<IJob>
                (
                    true, JobQueue,
                    Job => Job.Execute()
                )
            );
        }

        #region IJobManager Members

        public void EnqueJob(params IJob[] jobToEnqueue)
        {
            foreach (var j in jobToEnqueue)
            {
                JobQueue.Post(j);
            }

            Arbiter.ExecuteNow
                (
                    Queue,
                    Arbiter.Receive<IJob>
                    (
                        true, JobQueue,
                        Job => Job.Execute()
                    )
                );
        }

        public void EnqueJobsAndWait(params IJob[] jobToEnqueue)
        {
            Port<IJob> WaitJobs = new Port<IJob>();
            Port<byte> ResponsePort = new Port<byte>();

            var Done = new System.Threading.ManualResetEvent(false);

            foreach (var j in jobToEnqueue)
            {
                WaitJobs.Post(j);
            }

            Arbiter.Activate
                (
                    Queue,
                    Arbiter.Receive<IJob>
                    (
                        true, WaitJobs,
                        delegate(IJob j)
                        {
                            j.Execute();
                            ResponsePort.Post(0);
                        }
                    )
                );

            Arbiter.Activate
                (
                    Queue,
                    Arbiter.MultipleItemReceive<byte>
                    (
                        true, ResponsePort, jobToEnqueue.Length,
                        b => Done.Set()
                    )
                );

            Done.WaitOne();

        }

        #endregion
    }
}
